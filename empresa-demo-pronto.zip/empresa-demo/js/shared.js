/* ============================================================
   SHARED — componentes de página reutilizados pelas vistas
   ============================================================ */
(function () {
  "use strict";

  function head(title, subtitle, actions, backTo) {
    return '<div class="page-head"><div class="titles">' +
      (backTo ? '<button class="pill-note" data-nav="' + backTo + '" style="margin-bottom:8px">' + UI.icon("chevron-left", 14) + " Voltar</button>" : "") +
      '<div class="h1">' + UI.esc(title) + "</div>" +
      (subtitle ? '<div class="sub">' + subtitle + "</div>" : "") +
      "</div>" + (actions ? '<div class="btn-row">' + actions + "</div>" : "") + "</div>";
  }

  function money(v, opts) { return Store.money(v, opts); }

  function saleStatus(t) {
    if (t.status === "Cancelada") return '<span class="chip red">Cancelada</span>';
    if (t.status === "Paga") return '<span class="chip green">Paga</span>';
    if (t.overdueDays > 0) return '<span class="chip red">Em atraso</span>';
    return '<span class="chip orange">Pendente</span>';
  }

  function stockStatus(st) {
    if (st.situation === "SEM STOCK") return '<span class="chip red">Sem stock</span>';
    if (st.situation === "REPOR") return '<span class="chip orange">Repor</span>';
    return '<span class="chip green">OK</span>';
  }

  function saleRow(s) {
    var db = Store.db();
    var t = Engine.saleTotals(s);
    var client = db.clients.find(function (c) { return c.id === s.clientId; });
    var item = s.items && s.items[0];
    var iconName = item && item.typeId ? "package" : "receipt";
    var typeName = item && item.typeId ? Store.listName("itemType", item.typeId) : "";
    return '<a class="row" href="#/vendas/' + s.id + '">' +
      '<div class="tile">' + UI.icon(typeName === "Serviço" || typeName === "Subscrição" ? "file-text" : "package", 19) + "</div>" +
      '<div class="body"><div class="name">' + UI.esc(Engine.saleLabel(s)) + "</div>" +
      '<div class="meta">' + UI.esc(client ? client.name : "Consumidor final") + " · " + Store.dateShort(s.date) +
      (t.overdueDays > 0 ? " · <span style=\"color:var(--red)\">" + t.overdueDays + " dias</span>" : "") + "</div></div>" +
      '<div class="end"><div class="amount' + (t.status === "Cancelada" ? " muted" : "") + '">' + money(t.total) + "</div>" +
      saleStatus(t) + "</div></a>";
  }

  function categoryName(id) { return Store.listName("expenseCategory", id, "Outras"); }

  function kpi(label, value, cls, sub, iconName) {
    return '<div class="stat ' + (cls || "") + '"><div class="k">' +
      (iconName ? UI.icon(iconName, 13) : "") + UI.esc(label) + "</div>" +
      '<div class="v">' + value + "</div>" + (sub ? '<div class="d">' + sub + "</div>" : "") + "</div>";
  }

  function progressPct(v) {
    var p = Math.max(0, Math.min(100, v * 100));
    var cls = v >= 1 ? "green" : v >= 0.6 ? "" : "orange";
    return '<div class="bar ' + cls + '" style="flex:1;min-width:44px"><i style="width:' + p.toFixed(1) + '%"></i></div>';
  }

  function avatar(name) {
    return (name || "?").split(/\s+/).slice(0, 2).map(function (w) { return w[0]; }).join("").toUpperCase();
  }

  function itemOptions() {
    var db = Store.db();
    return db.catalog.filter(function (c) { return c.active !== false; }).map(function (c) {
      return { id: c.id, name: c.name + " · " + Store.money(c.price) };
    });
  }

  function clientOptions() {
    var db = Store.db();
    return db.clients.filter(function (c) { return c.state !== "Inativo"; })
      .sort(function (a, b) { return a.name.localeCompare(b.name); })
      .map(function (c) { return { id: c.id, name: c.name }; });
  }

  function employeeOptions(filterActive) {
    return Store.db().employees.filter(function (e) { return !filterActive || e.state !== "Inativo"; })
      .map(function (e) { return { id: e.id, name: e.name }; });
  }

  function paidBadge(state) {
    return state === "Paga" ? '<span class="chip green">Paga</span>' : '<span class="chip orange">Pendente</span>';
  }

  /* -------- cartões de seleção (usado em várias listas) -------- */
  function selectPill(name, options, value, attrs) {
    return '<select class="select" name="' + name + '" ' + (attrs || "") + ">" + options.map(function (o) {
      var id = typeof o === "string" ? o : o.id, nm = typeof o === "string" ? o : o.name;
      return '<option value="' + UI.esc(id) + '"' + (String(id) === String(value) ? " selected" : "") + ">" + UI.esc(nm) + "</option>";
    }).join("") + "</select>";
  }

  window.Actions = window.Actions || {};

  window.V = {
    head: head, money: money, saleStatus: saleStatus, stockStatus: stockStatus,
    saleRow: saleRow, categoryName: categoryName, kpi: kpi, progressPct: progressPct,
    avatar: avatar, itemOptions: itemOptions, clientOptions: clientOptions,
    employeeOptions: employeeOptions, paidBadge: paidBadge, selectPill: selectPill
  };
})();
