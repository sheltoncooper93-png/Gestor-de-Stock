/* ============================================================
   VIEWS — Início, Dashboard e menu Mais
   ============================================================ */
(function () {
  "use strict";

  var money = Store.money;

  /* ------------------------------------------------------------------
     INÍCIO
  ------------------------------------------------------------------ */
  function home() {
    var db = Store.db(), cfg = db.config;
    var now = new Date();
    var year = cfg.refYear;
    var ys = Engine.yearStats(year);
    var thisMonth = now.getMonth() + 1;
    var thisYear = now.getFullYear();
    var snap = Engine.monthSnapshot(thisYear, thisMonth);
    var mr = Engine.monthRows(thisYear)[thisMonth - 1];

    var period = App.homePeriod || "year";
    var isMonth = period === "month";

    var inMonth = db.sales.filter(function (s) {
      if (s.state === "Cancelada" || !s.date) return false;
      var d = new Date(s.date + "T00:00:00");
      return d.getFullYear() === thisYear && d.getMonth() + 1 === thisMonth;
    });
    var monthRevenue = inMonth.reduce(function (a, s) { return a + Engine.saleTotals(s).net; }, 0);
    var monthCost = inMonth.reduce(function (a, s) { return a + Engine.saleTotals(s).cost; }, 0);

    var k = isMonth ? {
      revenue: snap.revenue, cost: monthCost, gross: snap.gross,
      expenses: snap.expenses, payroll: snap.payroll, result: snap.result,
      salesCount: inMonth.length, avgTicket: inMonth.length ? snap.revenue / inMonth.length : 0,
      grossMargin: snap.revenue ? snap.gross / snap.revenue : 0,
      resultMargin: snap.revenue ? snap.result / snap.revenue : 0,
      receivable: snap.receivable, overdue: snap.overdue, payable: ys.payable - (0),
      stockValue: snap.stockValue, restockCount: ys.restockCount,
      vatDue: ys.vatDue, activeClients: ys.activeClients, openTasks: ys.openTasks
    } : ys;

    var alerts = Engine.alerts();
    var alertCount = alerts.salesOverdue.length + alerts.purchasesOverdue.length +
      alerts.stockNegative.length + alerts.restock.length + alerts.tasksLate.length + alerts.tasksSoon.length;

    /* -------- hero -------- */
    var hero = '<div class="hero">' +
      '<div class="seg" role="group" aria-label="Período">' +
      '<button data-act="home-period" data-id="month" aria-pressed="' + (isMonth ? "true" : "false") + '">Este mês</button>' +
      '<button data-act="home-period" data-id="year" aria-pressed="' + (isMonth ? "false" : "true") + '">Este ano</button>' +
      "</div>" +
      '<div class="label">Resultado' + (isMonth ? " de " + Store.MONTHS_LONG[thisMonth - 1] : " de " + year) + " (receita − custos − despesas − pessoal)</div>" +
      '<div class="value">' + money(k.result) + "</div>" +
      '<div class="foot"><span>' + money(k.revenue) + " receita</span><span>" + money(k.gross) + " lucro bruto</span>" +
      "<span>" + money(k.expenses + k.payroll) + " custos fixos</span></div></div>";

    /* -------- KPIs -------- */
    var kpis = '<div class="grid cols-2">' +
      V.kpi("Receita s/IVA", money(k.revenue), "accent-lime") +
      V.kpi("Custo das vendas", money(k.cost), "", "custos directos") +
      V.kpi("Lucro bruto", money(k.gross), "accent-green", "margem " + Store.pct(k.grossMargin)) +
      V.kpi("Despesas", money(k.expenses), "accent-orange", "operacionais") +
      V.kpi("Custo com pessoal", money(k.payroll), "") +
      KpiResult(k) +
      V.kpi("Valores a receber", money(k.receivable), "", "com IVA") +
      V.kpi("Valores em atraso", money(k.overdue), "accent-red", "com IVA") +
      V.kpi("Valores a pagar", money(k.payable), "accent-orange", "compras + despesas") +
      V.kpi("Valor total do stock", money(k.stockValue), "accent-blue") +
      V.kpi("Itens a repor", String(k.restockCount), k.restockCount ? "accent-orange" : "") +
      V.kpi("IVA estimado a entregar", money(k.vatDue), "") +
      V.kpi("Número de vendas", String(k.salesCount), "") +
      V.kpi("Ticket médio", money(k.avgTicket), "") +
      V.kpi("Margem bruta", Store.pct(k.grossMargin), "accent-green") +
      V.kpi("Margem do resultado", Store.pct(k.resultMargin), k.resultMargin >= 0 ? "accent-green" : "accent-red") +
      V.kpi("Clientes ativos", String(k.activeClients), "") +
      V.kpi("Tarefas em aberto", String(k.openTasks), k.openTasks ? "accent-orange" : "") +
      "</div>";

    function KpiResult(kk) {
      return V.kpi("Resultado", money(kk.result), kk.result >= 0 ? "accent-green" : "accent-red", "após pessoal e despesas");
    }

    /* -------- gráfico 6 meses -------- */
    var rows = Engine.monthRows(thisYear).slice(0, thisMonth).slice(-6).map(function (r) {
      return { revenue: r.revenue, expenses: r.expenses + r.payroll, label: r.label, cap: String(r.month).padStart(2, "0") + "/" + String(thisYear).slice(2) };
    });
    var chart = '<div class="card"><div class="card-head"><div class="title">Últimos ' + rows.length + " meses</div>" +
      '<div class="legend"><span><i style="background:var(--lime)"></i>Receita</span><span><i style="background:var(--orange)"></i>Custos fixos</span></div></div>' +
      (rows.length ? UI.sparkBars(rows) : UI.emptyState("bar-chart", "Sem dados para mostrar.")) + "</div>";

    /* -------- atalhos -------- */
    var shortcuts = [
      ["sale-new", "Nova venda", "receipt"],
      ["purchase-new", "Nova compra", "shopping-bag"],
      ["expense-new", "Nova despesa", "wallet"],
      ["client-new", "Novo cliente", "user-plus"],
      ["catalog-new", "Novo produto", "tag"],
      ["movement-new", "Movimento de stock", "layers"],
      ["task-new", "Nova tarefa", "clipboard-list"]
    ];
    var quick = '<div class="section-head"><div class="h2">Acesso rápido</div></div>' +
      '<div class="grid cols-2">' +
      shortcuts.map(function (s) {
        return '<button class="menu-item" style="text-align:left" data-act="' + s[0] + '">' +
          '<div class="tile">' + UI.icon(s[2], 18) + "</div>" +
          '<div class="body"><div class="nm">' + s[1] + "</div></div>" +
          '<div class="go">' + UI.icon("chevron-right", 16) + "</div></button>";
      }).join("") + "</div>";

    /* -------- alertas -------- */
    var al = "";
    alerts.salesOverdue.slice(0, 2).forEach(function (x) {
      var c = db.clients.find(function (c2) { return c2.id === x.sale.clientId; });
      al += alertRow("danger", "Venda " + x.sale.id + " em atraso há " + x.totals.overdueDays + " dias" +
        (c ? " — " + c.name : "") + ". Saldo " + money(x.totals.balance) + ".", "#/vendas/" + x.sale.id);
    });
    alerts.purchasesOverdue.slice(0, 1).forEach(function (x) {
      al += alertRow("warn", "Compra " + x.purchase.id + " vencida há " + x.days + " dias — " + money(Engine.purchaseTotals(x.purchase).total) + ".", "#/compras/" + x.purchase.id);
    });
    alerts.stockNegative.slice(0, 1).forEach(function (x) {
      al += alertRow("danger", "Stock negativo: " + x.item.name + " (" + x.stat.qty + ").", "#/stock/" + x.item.id);
    });
    alerts.restock.slice(0, 2).forEach(function (x) {
      al += alertRow("warn", "Repor " + x.item.name + " — sugerido " + x.stat.suggested + " " + Store.listName("unit", x.item.unitId) + ".", "#/stock/" + x.item.id);
    });
    alerts.tasksLate.slice(0, 2).forEach(function (x) {
      al += alertRow("danger", "Tarefa atrasada: " + x.task.title + ".", "#/tarefas");
    });
    alerts.tasksSoon.slice(0, 1).forEach(function (x) {
      al += alertRow("blue", "Prazo próximo: " + x.task.title + " (" + x.status.days + " dias).", "#/tarefas");
    });
    if (!al) al = '<div class="alert blue">' + UI.icon("check-circle", 18) + '<div class="txt"><b>Tudo em ordem.</b> Sem atrasos, stock negativo ou tarefas vencidas.</div></div>';

    var alertsBlock = '<div class="section-head"><div class="h2">Alertas</div>' +
      (alertCount ? '<span class="chip orange">' + alertCount + "</span>" : "") + "</div>" + al;

    return '<div class="view">' + hero + kpis + chart + quick + alertsBlock + "</div>";
  }

  function alertRow(kind, text, href) {
    return '<a class="alert ' + kind + '" href="' + href + '">' + UI.icon(kind === "danger" ? "alert-triangle" : kind === "blue" ? "clock" : "alert-triangle", 18) +
      '<div class="txt">' + text + "</div>" + UI.icon("chevron-right", 16) + "</a>";
  }

  /* ------------------------------------------------------------------
     DASHBOARD
  ------------------------------------------------------------------ */
  function dashboard() {
    var db = Store.db(), cfg = db.config;
    var years = {};
    db.sales.forEach(function (s) { if (s.date) years[s.date.slice(0, 4)] = 1; });
    db.expenses.forEach(function (s) { if (s.date) years[s.date.slice(0, 4)] = 1; });
    years[String(cfg.refYear)] = 1;
    years[String(new Date().getFullYear())] = 1;
    var yearList = Object.keys(years).sort();
    var year = Number(App.dashYear || cfg.refYear);
    if (yearList.indexOf(String(year)) < 0) yearList.push(String(year));
    yearList.sort();

    var ys = Engine.yearStats(year);
    var rows = Engine.monthRows(year);
    var cat = Engine.expensesByCategory(year);
    var topClients = Engine.topClients(5);
    var topItems = Engine.topItems(5);
    var stockStats = Engine.stockStats();
    var restock = db.stock.filter(function (it) { return stockStats[it.id] && stockStats[it.id].situation !== "OK"; })
      .sort(function (a, b) { return stockStats[a.id].qty - stockStats[b.id].qty; });

    var yearSel = '<select class="select" style="width:auto;min-height:40px;border-radius:999px" data-act="set-year">' +
      yearList.map(function (y) { return '<option value="' + y + '"' + (Number(y) === year ? " selected" : "") + ">" + y + "</option>"; }).join("") +
      "</select>";

    var head = V.head("Dashboard", "Ano " + year + " · valores em " + UI.esc(cfg.currency) + " · receitas e custos sem IVA", yearSel, "#/mais");

    var kpis = '<div class="grid cols-3">' +
      V.kpi("Receita s/IVA", money(ys.revenue), "accent-lime", ys.salesCount + " vendas") +
      V.kpi("Custo das vendas", money(ys.cost), "", "custos directos") +
      V.kpi("Lucro bruto", money(ys.gross), "accent-green", Store.pct(ys.grossMargin) + " de margem") +
      V.kpi("Despesas", money(ys.expenses), "accent-orange") +
      V.kpi("Pessoal", money(ys.payroll), "", "salários + encargos") +
      V.kpi("Resultado", money(ys.result), ys.result >= 0 ? "accent-green" : "accent-red", Store.pct(ys.resultMargin)) +
      V.kpi("Nº de vendas", String(ys.salesCount)) +
      V.kpi("Ticket médio", money(ys.avgTicket)) +
      V.kpi("Margem bruta", Store.pct(ys.grossMargin), "accent-green") +
      V.kpi("Margem do resultado", Store.pct(ys.resultMargin), ys.resultMargin >= 0 ? "accent-green" : "accent-red") +
      V.kpi("Clientes ativos", String(ys.activeClients)) +
      V.kpi("Tarefas em aberto", String(ys.openTasks), ys.openTasks ? "accent-orange" : "") +
      V.kpi("A receber c/IVA", money(ys.receivable), "", "saldo pendente") +
      V.kpi("Em atraso c/IVA", money(ys.overdue), "accent-red") +
      V.kpi("A pagar c/IVA", money(ys.payable), "accent-orange") +
      V.kpi("Valor em stock", money(ys.stockValue), "accent-blue") +
      V.kpi("Itens a repor", String(ys.restockCount), ys.restockCount ? "accent-orange" : "") +
      V.kpi("IVA estimado a entregar", money(ys.vatDue), "", "vendas − compras − despesas") +
      "</div>";

    /* tabela mensal */
    var table = '<div class="card" style="padding:18px 12px 8px"><div class="card-head" style="padding:0 6px">' +
      '<div class="title">Evolução mensal — ' + year + '</div><span class="pill-note">meta ' + money(cfg.monthlyTarget) + "/mês</span></div>" +
      '<div class="table-wrap"><table class="data"><thead><tr>' +
      "<th>Mês</th><th class=\"num\">Receita</th><th class=\"num\">Custo</th><th class=\"num\">Despesas</th><th class=\"num\">Pessoal</th><th class=\"num\">Resultado</th><th class=\"num\">Meta</th><th style=\"min-width:80px\">% meta</th></tr></thead><tbody>" +
      rows.map(function (r) {
        return "<tr><td><b>" + r.label + "</b></td>" +
          '<td class="num">' + money(r.revenue) + "</td>" +
          '<td class="num muted">' + money(r.cost) + "</td>" +
          '<td class="num">' + money(r.expenses) + "</td>" +
          '<td class="num muted">' + money(r.payroll) + "</td>" +
          '<td class="num" style="color:' + (r.result >= 0 ? "var(--green)" : "var(--red)") + ';font-weight:650">' + money(r.result) + "</td>" +
          '<td class="num muted">' + money(r.target) + "</td>" +
          '<td><div class="hstack"><span class="tiny">' + Store.pct(r.targetPct, 0) + "</span>" + V.progressPct(r.targetPct) + "</div></td></tr>";
      }).join("") +
      '<tr class="total"><td>Total</td><td class="num">' + money(ys.revenue) + '</td><td class="num">' + money(ys.cost) +
      '</td><td class="num">' + money(ys.expenses) + '</td><td class="num">' + money(ys.payroll) +
      '</td><td class="num">' + money(ys.result) + '</td><td class="num">' + money(cfg.monthlyTarget * 12) +
      '</td><td>' + Store.pct(ys.revenue / (num(cfg.monthlyTarget) * 12 || 1), 0) + "</td></tr>" +
      "</tbody></table></div></div>";

    /* despesas por categoria */
    var palette = ["#b9fc01", "#6b8cff", "#f5a94a", "#4ade80", "#ff7a7a", "#a78bfa", "#38bdf8", "#f472b6"];
    var catCard = '<div class="card"><div class="card-head"><div class="title">Despesas por categoria — ' + year + "</div>" +
      '<span class="pill-note">' + money(cat.total) + "</span></div>" +
      (cat.rows.length ? UI.donut(cat.rows.map(function (r, i) { return { name: r.name, value: r.value, color: palette[i % palette.length] }; }), cat.total, "total " + year, Store.money0(cat.total)) +
        '<div class="chart-legend" style="margin-top:14px">' + cat.rows.map(function (r, i) {
          return '<div class="li"><i style="background:' + palette[i % palette.length] + '"></i>' +
            '<span class="nm" style="flex:1">' + UI.esc(r.name) + '</span><span class="vl">' + money(r.value) + " · " + Store.pct(r.pct) + "</span></div>";
        }).join("") + "</div>" : UI.emptyState("pie-chart", "Sem despesas registadas neste ano.")) + "</div>";

    /* rankings */
    function rankCard(title, rows, isClient) {
      return '<div class="card"><div class="card-head"><div class="title">' + title + "</div>" +
        '<span class="pill-note">acumulado</span></div>' +
        (rows.length ? '<div class="rows">' + rows.map(function (r, i) {
          var nm = isClient ? r.client.name : r.item.name;
          var sub = isClient ? (r.stat.sales + " vendas") : (r.stat.qtySold + " un. vendidas");
          return '<div class="row" style="padding:9px 0">' +
            '<div class="tile" style="width:30px;height:30px;border-radius:9px;font-size:12px;font-weight:700">' + (i + 1) + "</div>" +
            '<div class="body"><div class="name">' + UI.esc(nm) + '</div><div class="meta">' + sub + "</div></div>" +
            '<div class="end"><div class="amount sm">' + money(r.stat.revenue) + "</div></div></div>";
        }).join("") + "</div>" : UI.emptyState("star", "Sem faturação registada.")) + "</div>";
    }

    var rankings = '<div class="two-col"><div class="col">' + rankCard("Top 5 clientes", topClients, true) + "</div>" +
      '<div class="col">' + rankCard("Top 5 serviços e produtos", topItems, false) + "</div></div>";

    /* stock a repor */
    var restockCard = '<div class="card"><div class="card-head"><div class="title">Stock a repor</div>' +
      '<span class="pill-note">' + restock.length + " itens</span></div>" +
      (restock.length ? '<div class="rows">' + restock.map(function (it) {
        var st = stockStats[it.id];
        return '<a class="row" href="#/stock/' + it.id + '">' +
          '<div class="tile orange">' + UI.icon("package", 18) + "</div>" +
          '<div class="body"><div class="name">' + UI.esc(it.name) + '</div><div class="meta">atual ' + st.qty + " · mínimo " + it.minStock + "</div></div>" +
          '<div class="end"><div class="amount sm orange">+' + st.suggested + "</div>" + V.stockStatus(st) + "</div></a>";
      }).join("") + "</div>" : UI.emptyState("package", "Inventário em níveis saudáveis.")) + "</div>";

    return '<div class="view">' + head + kpis + table +
      '<div class="section-head"><div class="h2">Análise</div></div>' +
      '<div class="two-col"><div class="col">' + catCard + "</div><div class=\"col\">" + restockCard + "</div></div>" +
      '<div class="section-head"><div class="h2">Rankings</div></div>' + rankings + "</div>";
  }

  function num(v) { return Number(v) || 0; }

  /* ------------------------------------------------------------------
     MAIS
  ------------------------------------------------------------------ */
  function more() {
    var db = Store.db(), cfg = db.config;
    var user = App.currentUser();
    var items = [
      ["Clientes", "Quem compra e quem deve", "users", "#/clientes", "clients"],
      ["Serviços e produtos", "Catálogo, preços, custos e margem", "tag", "#/catalogo", "catalog"],
      ["Compras", "Entradas de stock e custos médios", "shopping-bag", "#/compras", "purchases"],
      ["Fornecedores", "Contactos e valores em dívida", "truck", "#/fornecedores", "suppliers"],
      ["Movimentos de stock", "Ajustes, perdas e devoluções", "layers", "#/movimentos", "movements"],
      ["Caixa / POS", "Venda rápida com carrinho", "printer", "#/pdv", "pos"],
      ["Tarefas", "Projetos e prazos da equipa", "clipboard-list", "#/tarefas", "tasks"],
      ["Funcionários", "Equipa, salários e permissões", "user", "#/funcionarios", "employees"],
      ["Dashboard", "Todos os indicadores do ano", "bar-chart", "#/dashboard"],
      ["Listas editáveis", "Opções de todos os menus", "sliders", "#/listas"],
      ["Configuração", "Empresa, moeda, IVA e módulos", "settings", "#/config"]
    ].filter(function (it) { return !it[4] || cfg.modules[it[4]] !== false; });
    var menu = '<div class="menu-list">' + items.map(function (it) {
      return '<a class="menu-item" href="' + it[3] + '"><div class="tile">' + UI.icon(it[2], 18) + "</div>" +
        '<div class="body"><div class="nm">' + it[0] + '</div><div class="ds">' + it[1] + "</div></div>" +
        '<div class="go">' + UI.icon("chevron-right", 16) + "</div></a>";
    }).join("") + "</div>";

    var alerts = Engine.alerts();
    var alertTotal = alerts.salesOverdue.length + alerts.purchasesOverdue.length + alerts.restock.length +
      alerts.stockNegative.length + alerts.tasksLate.length + alerts.tasksSoon.length;

    var dados = '<div class="section-head"><div class="h2">Dados</div></div><div class="menu-list">' +
      '<button class="menu-item" data-act="backup-download"><div class="tile">' + UI.icon("download", 18) + "</div>" +
      '<div class="body"><div class="nm">Guardar cópia de segurança</div><div class="ds">Descarrega um ficheiro com todos os dados</div></div>' +
      '<div class="go">' + UI.icon("chevron-right", 16) + "</div></button>" +
      '<button class="menu-item" data-act="backup-restore"><div class="tile">' + UI.icon("upload", 18) + "</div>" +
      '<div class="body"><div class="nm">Restaurar cópia</div><div class="ds">Carrega um ficheiro guardado antes</div></div>' +
      '<div class="go">' + UI.icon("chevron-right", 16) + "</div></button>" +
      '<button class="menu-item" data-act="seed-reset"><div class="tile">' + UI.icon("refresh", 18) + "</div>" +
      '<div class="body"><div class="nm">Recarregar dados de exemplo</div><div class="ds">Volta aos dados da planilha original</div></div>' +
      '<div class="go">' + UI.icon("chevron-right", 16) + "</div></button>" +
      '<button class="menu-item" data-act="wipe"><div class="tile red">' + UI.icon("trash", 18) + "</div>" +
      '<div class="body"><div class="nm" style="color:var(--red)">Apagar tudo</div><div class="ds">Começar do zero, sem dados</div></div>' +
      '<div class="go">' + UI.icon("chevron-right", 16) + "</div></button></div>";

    var userCard = '<div class="card" style="margin-top:16px"><div class="card-head"><div class="title">Sessão e permissões</div></div>' +
      '<div class="kv"><div class="it"><span class="k">Operador ativo</span><span class="v">' + UI.esc(user ? user.name : "—") + "</span></div>" +
      '<div class="it"><span class="k">Perfil</span><span class="v">' + (App.isAdmin() ? "Administrador" : "Operador de caixa") + "</span></div>" +
      '<div class="it"><span class="k">Dispositivo</span><span class="v">' + (navigator.onLine ? "Online" : "Offline") + "</span></div>" +
      '<div class="it"><span class="k">Guardado</span><span class="v">' + (Store.isMemoryOnly() ? "Apenas nesta sessão" : "Neste dispositivo") + "</span></div></div>" +
      '<div class="btn-row" style="margin-top:14px"><button class="btn ghost" data-act="switch-operator">' + UI.icon("users", 16) + " Trocar operador</button>" +
      (alertTotal ? '<button class="btn ghost" data-nav="#/tarefas">' + alertTotal + " alertas</button>" : "") + "</div></div>";

    return '<div class="view">' + V.head("Mais", "Todos os módulos da empresa num só lugar", "") +
      menu + dados + userCard +
      '<p class="tiny muted" style="text-align:center;margin:22px 0 8px">' + UI.esc(cfg.company) + " · " + UI.esc(cfg.nif) +
      " · dados guardados no dispositivo</p></div>";
  }

  /* ------------------------------------------------------------------ */
  window.Views = window.Views || {};
  window.Views.home = home;
  window.Views.dashboard = dashboard;
  window.Views.more = more;
  window.Views.notFound = function () {
    return V.head("Ecrã não encontrado", "Verifique o endereço ou volte ao início",
      '<button class="btn primary" data-nav="#/inicio">Início</button>', "#/mais") +
      UI.emptyState("help", "Este ecrã não existe nesta aplicação.");
  };

  /* -------- ações globais -------- */
  Actions["alerts"] = function () {
    var db = Store.db();
    var a = Engine.alerts();
    function block(title, iconName, rows, cls) {
      if (!rows.length) return "";
      return '<div class="card tight" style="margin-bottom:10px"><div class="card-head" style="margin-bottom:6px">' +
        '<div class="title" style="display:flex;align-items:center;gap:8px">' + UI.icon(iconName, 15) + title + "</div>" +
        '<span class="chip ' + (cls || "") + '">' + rows.length + "</span></div>" +
        '<div class="rows">' + rows.join("") + "</div></div>";
    }
    var sales = a.salesOverdue.map(function (x) {
      var c = db.clients.find(function (k) { return k.id === x.sale.clientId; });
      return '<a class="row" href="#/vendas/' + x.sale.id + '"><div class="tile red">' + UI.icon("receipt", 16) + "</div>" +
        '<div class="body"><div class="name">' + x.sale.id + " · " + money(x.totals.balance) + '</div>' +
        '<div class="meta">' + UI.esc(c ? c.name : "Consumidor final") + " · " + x.totals.overdueDays + " dias de atraso</div></div>" +
        '<div class="end">' + UI.icon("chevron-right", 15) + "</div></a>";
    });
    var purchases = a.purchasesOverdue.map(function (x) {
      return '<a class="row" href="#/compras/' + x.purchase.id + '"><div class="tile orange">' + UI.icon("shopping-bag", 16) + "</div>" +
        '<div class="body"><div class="name">' + x.purchase.id + " · " + money(Engine.purchaseTotals(x.purchase).total) + '</div>' +
        '<div class="meta">compra vencida há ' + x.days + " dias</div></div>" +
        '<div class="end">' + UI.icon("chevron-right", 15) + "</div></a>";
    });
    var stock = a.stockNegative.concat(a.restock).map(function (x) {
      return '<a class="row" href="#/stock/' + x.item.id + '"><div class="tile orange">' + UI.icon("package", 16) + "</div>" +
        '<div class="body"><div class="name">' + UI.esc(x.item.name) + '</div>' +
        '<div class="meta">' + (x.stat.qty < 0 ? "stock negativo: " + x.stat.qty : "a repor · sugerido " + x.stat.suggested) + "</div></div>" +
        '<div class="end">' + V.stockStatus(x.stat) + "</div></a>";
    });
    var tasks = a.tasksLate.concat(a.tasksSoon).map(function (x) {
      return '<a class="row" href="#/tarefas"><div class="tile ' + (x.status.alert === "ATRASADA" ? "red" : "blue") + '">' +
        UI.icon("clipboard-list", 16) + "</div>" +
        '<div class="body"><div class="name">' + UI.esc(x.task.title) + '</div>' +
        '<div class="meta">' + (x.status.alert === "ATRASADA" ? "atrasada " + Math.abs(x.status.days) + " dias" : x.status.days + " dias para o prazo") + "</div></div>" +
        '<div class="end">' + UI.icon("chevron-right", 15) + "</div></a>";
    });
    var body = block("Vendas em atraso", "receipt", sales, "red") +
      block("Compras em atraso", "shopping-bag", purchases, "orange") +
      block("Stock", "package", stock, "orange") +
      block("Tarefas", "clipboard-list", tasks, "blue");
    if (!body) body = UI.emptyState("check-circle", "Sem alertas. Tudo em ordem.");
    var ov = UI.openSheet('<div class="sheet-head"><div class="ttl"><h2>Notificações</h2><p>Alertas calculados a partir dos dados atuais.</p></div>' +
      '<button class="icon-btn ghost" data-x="1">' + UI.icon("x", 18) + "</button></div><div class=\"sheet-body\">" + body + "</div>", "");
    ov.querySelector("[data-x]").onclick = UI.closeSheet;
    ov.querySelectorAll(".row").forEach(function (r) {
      r.addEventListener("click", function () { UI.closeSheet(); });
    });
  };

  Actions["home-period"] = function (id) {
    App.homePeriod = id;
    App.render();
  };
  Actions["set-year"] = function () { };

  document.addEventListener("change", function (e) {
    if (e.target && e.target.getAttribute("data-act") === "set-year") {
      App.dashYear = Number(e.target.value);
      App.render();
    }
  });

  Actions["switch-operator"] = function () {
    var db = Store.db();
    var active = App.currentUser();
    var body = '<div class="vstack">' + db.employees.filter(function (e) { return e.state !== "Inativo"; }).map(function (e) {
      return '<button class="menu-item" data-pick="' + e.id + '"><div class="tile">' + UI.icon("user", 18) + "</div>" +
        '<div class="body"><div class="nm">' + UI.esc(e.name) + '</div><div class="ds">' +
        (e.permission === "admin" ? "Administrador" : "Operador de caixa") + " · " + UI.esc(Store.listName("role", e.roleId)) + "</div></div>" +
        (active && active.id === e.id ? '<span class="chip lime">Ativo</span>' : "") + "</button>";
    }).join("") + "</div>";
    var ov = UI.openSheet('<div class="sheet-head"><div class="ttl"><h2>Trocar operador</h2><p>Escolha quem está a usar a aplicação agora.</p></div>' +
      '<button class="icon-btn ghost" data-x="1">' + UI.icon("x", 18) + "</button></div><div class=\"sheet-body\">" + body + "</div>", "");
    function done() { UI.closeSheet(); }
    ov.querySelector("[data-x]").onclick = done;
    ov.querySelectorAll("[data-pick]").forEach(function (b) {
      b.onclick = function () {
        var id = b.getAttribute("data-pick");
        var emp = db.employees.find(function (e) { return e.id === id; });
        if (emp.pin) {
          askPin(emp, function () {
            App.session = { employeeId: id, since: new Date().toISOString() };
            App.saveSession(); UI.closeSheet(); App.render(); UI.toast("Operador: " + emp.name);
          });
        } else {
          App.session = { employeeId: id, since: new Date().toISOString() };
          App.saveSession(); UI.closeSheet(); App.render(); UI.toast("Operador: " + emp.name);
        }
      };
    });
  };

  function askPin(emp, onOk) {
    var entered = "";
    var ov = UI.openSheet('<div class="sheet-head"><div class="ttl"><h2>PIN de ' + UI.esc(emp.name.split(" ")[0]) + "</h2><p>Introduza o PIN de 4 algarismos.</p></div>" +
      '<button class="icon-btn ghost" data-x="1">' + UI.icon("x", 18) + "</button></div>" +
      '<div class="sheet-body"><div class="pin-dots" id="pinDots"><i></i><i></i><i></i><i></i></div>' +
      '<div class="pin-pad">' + [1, 2, 3, 4, 5, 6, 7, 8, 9].map(function (n) { return "<button data-k=\"" + n + "\">" + n + "</button>"; }).join("") +
      '<button data-k="del" style="font-size:14px">Apagar</button><button data-k="0">0</button><button data-k="ok" class="chip lime" style="height:58px;border-radius:18px">OK</button>' +
      "</div></div>", "");
    function paint() {
      ov.querySelectorAll("#pinDots i").forEach(function (d, i) { d.className = i < entered.length ? "on" : ""; });
    }
    function check() {
      if (entered === emp.pin) { UI.closeSheet(); onOk(); }
      else { UI.toast("PIN incorreto.", "err"); entered = ""; paint(); }
    }
    ov.querySelector("[data-x]").onclick = function () { UI.closeSheet(); };
    ov.querySelectorAll("[data-k]").forEach(function (b) {
      b.onclick = function () {
        var k = b.getAttribute("data-k");
        if (k === "del") entered = entered.slice(0, -1);
        else if (k === "ok") { check(); return; }
        else if (entered.length < 4) entered += k;
        paint();
        if (entered.length === 4) setTimeout(check, 140);
      };
    });
  }
  window.askPin = askPin;
})();
