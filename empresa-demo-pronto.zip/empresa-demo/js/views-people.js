/* ============================================================
   VIEWS — Clientes, funcionários e tarefas
   ============================================================ */
(function () {
  "use strict";

  var money = Store.money;

  function client(id) { return Store.db().clients.find(function (c) { return c.id === id; }); }
  function employee(id) { return Store.db().employees.find(function (e) { return e.id === id; }); }

  /* ==================================================================
     CLIENTES
  ================================================================== */
  function clients() {
    var db = Store.db();
    var f = App.clientFilter || (App.clientFilter = { q: "", state: "" });
    var stats = Engine.clientStats();
    var list = db.clients.slice();
    if (f.q) {
      var q = f.q.toLowerCase();
      list = list.filter(function (c) {
        return (c.name + " " + (c.nuit || "") + " " + (c.email || "") + " " + (c.city || "")).toLowerCase().indexOf(q) >= 0;
      });
    }
    if (f.state) list = list.filter(function (c) { return c.state === f.state; });
    list.sort(function (a, b) {
      var ra = (stats[a.id] || {}).revenue || 0, rb = (stats[b.id] || {}).revenue || 0;
      return rb - ra;
    });

    var totalRevenue = 0, totalDebt = 0, active = 0;
    db.clients.forEach(function (c) {
      var st = stats[c.id] || { revenue: 0, debt: 0 };
      totalRevenue += st.revenue; totalDebt += st.debt;
      if (c.state === "Ativo") active++;
    });

    var head = V.head("Clientes", active + " ativos · " + money(totalRevenue) + " faturado s/IVA",
      '<button class="btn primary" data-act="client-new">' + UI.icon("user-plus", 17) + " Novo cliente</button>");

    var summary = '<div class="grid cols-3" style="margin-bottom:14px">' +
      V.kpi("Clientes", String(db.clients.length), "accent-lime") +
      V.kpi("Ativos", String(active)) +
      V.kpi("Em dívida", money(totalDebt), totalDebt ? "accent-orange" : "") + "</div>";

    var filterBar = '<div class="hstack" style="margin-bottom:12px">' +
      '<div class="search" style="flex:1;min-width:120px;height:42px">' + UI.icon("search", 17) +
      '<input placeholder="Pesquisar cliente, NUIT, cidade" data-act="client-search" value="' + UI.esc(f.q) + '"></div>' +
      '<select class="select" data-act="client-state" style="width:auto;height:42px;min-height:42px;border-radius:999px;font-size:12.5px;padding:8px 32px 8px 13px">' +
      '<option value="">Estados</option>' + ["Ativo", "Potencial", "Inativo"].map(function (s) {
        return '<option value="' + s + '"' + (f.state === s ? " selected" : "") + ">" + s + "</option>";
      }).join("") + "</select></div>";

    var rows = list.length ? '<div class="group">' + list.map(function (c) {
      var st = stats[c.id] || { sales: 0, revenue: 0, debt: 0, rank: null };
      return '<a class="row" href="#/clientes/' + c.id + '">' +
        '<div class="tile" style="font-weight:700;font-size:12px;color:' + (c.state === "Ativo" ? "var(--lime)" : c.state === "Potencial" ? "var(--orange)" : "var(--text-3)") + '">' +
        UI.esc(V.avatar(c.name)) + "</div>" +
        '<div class="body"><div class="name">' + UI.esc(c.name) + "</div>" +
        '<div class="meta">' + UI.esc(Store.listName("clientType", c.typeId, "—")) + " · " + UI.esc(c.city || "—") +
        " · " + st.sales + " vendas" + (st.rank ? " · #" + st.rank : "") + "</div></div>" +
        '<div class="end"><div class="amount sm">' + money(st.revenue) + "</div>" +
        (st.debt > 0 ? '<span class="chip orange">' + money(st.debt) + "</span>" :
          '<span class="chip ' + (c.state === "Ativo" ? "green" : c.state === "Potencial" ? "orange" : "red") + '">' + UI.esc(c.state) + "</span>") + "</div></a>";
    }).join("") + "</div>" : UI.emptyState("users", "Sem clientes neste filtro.",
      '<button class="btn primary" data-act="client-new">Criar cliente</button>');

    App.afterRender = function () {
      var i = document.querySelector('[data-act="client-search"]');
      if (i) i.addEventListener("input", UI.debounce(function () {
        f.q = i.value; App.render();
        var a = document.querySelector('[data-act="client-search"]');
        if (a) { a.focus(); a.setSelectionRange(a.value.length, a.value.length); }
      }, 240));
    };

    return '<div class="view">' + head + summary + filterBar + rows + "</div>";
  }

  function clientDetail(id) {
    var db = Store.db();
    var c = client(id);
    if (!c) return Views.notFound();
    var st = Engine.clientInfo(id);
    var sales = db.sales.filter(function (s) { return s.clientId === id; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    var pays = [];
    sales.forEach(function (s) {
      db.payments.filter(function (p) { return p.saleId === s.id; }).forEach(function (p) { pays.push({ p: p, s: s }); });
    });
    pays.sort(function (a, b) { return a.p.date < b.p.date ? 1 : -1; });
    var tasks = db.tasks.filter(function (t) { return t.clientId === id; });

    var head = '<div class="page-head"><div class="titles">' +
      '<button class="pill-note" data-nav="#/clientes" style="margin-bottom:8px">' + UI.icon("chevron-left", 14) + " Clientes</button>" +
      '<div class="h1">' + UI.esc(c.name) + '</div><div class="sub">' + c.id + " · " +
      UI.esc(Store.listName("clientType", c.typeId, "—")) + " · " + UI.esc(c.city || "—") + "</div></div>" +
      '<div class="btn-row"><button class="btn ghost" data-act="client-edit" data-id="' + c.id + '">' + UI.icon("edit", 16) + " Editar</button>" +
      '<button class="btn primary" data-act="client-sell" data-id="' + c.id + '">' + UI.icon("plus", 16) + " Nova venda</button></div></div>";

    var hero = '<div class="detail-hero"><div class="top"><div>' +
      '<div class="eyebrow">Faturado sem IVA</div><div class="amt">' + money(st.revenue) + "</div>" +
      '<div class="hstack" style="margin-top:9px">' +
      (c.state === "Ativo" ? '<span class="chip green">Ativo</span>' : c.state === "Potencial" ? '<span class="chip orange">Potencial</span>' : '<span class="chip red">Inativo</span>') +
      (st.rank ? '<span class="chip lime">#' + st.rank + " no ranking</span>" : "") + "</div></div>" +
      '<div class="right"><div class="eyebrow">Em dívida c/IVA</div><div class="amt" style="font-size:22px;color:' +
      (st.debt > 0 ? "var(--orange)" : "var(--green)") + '">' + money(st.debt) + "</div>" +
      '<div class="tiny muted">' + st.sales + " vendas</div></div></div>" +
      '<div class="divider"></div><div class="kv">' +
      row("NUIT", UI.esc(c.nuit || "—")) +
      row("Email", c.email ? '<a href="mailto:' + UI.esc(c.email) + '">' + UI.esc(c.email) + "</a>" : "—") +
      row("Telefone / WhatsApp", c.phone ? '<a href="tel:' + UI.esc(c.phone) + '">' + UI.esc(c.phone) + "</a>" : "—") +
      row("Origem", UI.esc(Store.listName("clientOrigin", c.originId, "—"))) +
      row("Data de registo", Store.dateLong(c.registeredAt)) +
      row("Última compra", st.lastSale ? Store.dateLong(st.lastSale) : "—") + "</div></div>";

    var salesCard = '<div class="card"><div class="card-head"><div class="title">Histórico de vendas</div>' +
      '<span class="pill-note">' + sales.length + "</span></div>" +
      (sales.length ? '<div class="rows">' + sales.map(function (s) { return V.saleRow(s); }).join("") + "</div>"
        : '<p class="small muted">Sem vendas registadas.</p>') + "</div>";

    var payCard = '<div class="card"><div class="card-head"><div class="title">Pagamentos</div><span class="pill-note">' + pays.length + "</span></div>" +
      (pays.length ? '<div class="rows">' + pays.slice(0, 12).map(function (x) {
        return '<div class="row"><div class="tile green">' + UI.icon("check-circle", 17) + "</div>" +
          '<div class="body"><div class="name">' + money(x.p.amount) + '</div><div class="meta">' +
          UI.esc(Store.listName("paymentMethod", x.p.method, "—")) + " · " + Store.dateShort(x.p.date) + " · " + x.s.id + "</div></div>" +
          '<div class="end"><a class="tiny" href="#/vendas/' + x.s.id + '" style="color:var(--lime)">ver</a></div></div>';
      }).join("") + "</div>" : '<p class="small muted">Sem pagamentos registados.</p>') + "</div>";

    var taskCard = '<div class="card"><div class="card-head"><div class="title">Tarefas</div>' +
      '<button class="btn sm soft" data-act="task-new" data-id="' + c.id + '">+ Tarefa</button></div>' +
      (tasks.length ? '<div class="rows">' + tasks.map(function (t) {
        var stt = Engine.taskStatus(t);
        return '<div class="row"><div class="tile">' + UI.icon("clipboard-list", 17) + "</div>" +
          '<div class="body"><div class="name">' + UI.esc(t.title) + '</div><div class="meta">' +
          UI.esc(Store.listName("priority", t.priority, "—")) + " · " + Store.dateShort(t.dueDate) + "</div></div>" +
          '<div class="end"><span class="chip ' + (t.state === "Concluída" ? "green" : stt.alert === "ATRASADA" ? "red" : "blue") + '">' +
          UI.esc(t.state === "Concluída" ? "Concluída" : stt.alert || t.state) + "</span></div></div>";
      }).join("") + "</div>" : '<p class="small muted">Sem tarefas associadas.</p>') + "</div>";

    var notes = c.notes ? '<div class="card"><div class="card-head"><div class="title">Notas</div></div><p class="small muted">' + UI.esc(c.notes) + "</p></div>" : "";

    var actions = '<div class="btn-row" style="margin-top:12px">' +
      (c.state === "Inativo" ? '<button class="btn ghost" data-act="client-activate" data-id="' + c.id + '">Reativar cliente</button>'
        : '<button class="btn ghost" data-act="client-deactivate" data-id="' + c.id + '">Inativar cliente</button>') +
      '<button class="btn danger" data-act="client-delete" data-id="' + c.id + '">' + UI.icon("trash", 16) + " Eliminar</button></div>";

    return '<div class="view">' + head + hero +
      '<div class="two-col"><div class="col">' + salesCard + notes + "</div><div class=\"col\">" + payCard + taskCard + actions + "</div></div></div>";
  }

  function openClientForm(id) {
    var db = Store.db();
    var c = id ? client(id) : null;
    var fields = [
      { k: "name", label: "Nome / Razão social", type: "text", required: true, full: true },
      { k: "typeId", label: "Tipo de cliente", type: "select", options: UI.optsFromList("clientType") },
      { k: "nuit", label: "NUIT", type: "text" },
      { k: "email", label: "Email", type: "email" },
      { k: "phone", label: "Telefone / WhatsApp", type: "tel" },
      { k: "city", label: "Cidade", type: "text" },
      { k: "originId", label: "Origem do cliente", type: "select", options: UI.optsFromList("clientOrigin") },
      { k: "state", label: "Estado", type: "select", options: ["Ativo", "Potencial", "Inativo"], blank: false },
      { k: "registeredAt", label: "Data de registo", type: "date" },
      { k: "notes", label: "Notas", type: "textarea" }
    ];
    UI.form({
      title: c ? "Editar cliente" : "Novo cliente",
      subtitle: "O ID é gerado automaticamente.",
      fields: fields,
      values: c || { state: "Ativo", registeredAt: Store.todayISO() },
      submitLabel: c ? "Guardar" : "Criar cliente",
      onSubmit: function (v) {
        if (c) Object.assign(c, v);
        else db.clients.push(Object.assign({ id: Store.nextId("client", "CLI-", 4) }, v));
        Store.save();
        App.onData(c ? "Cliente atualizado." : "Cliente criado — já pode ser usado em vendas.");
        if (!c) App.go("#/clientes"); else App.render();
      }
    });
  }

  /* ==================================================================
     FUNCIONÁRIOS
  ================================================================== */
  function employees() {
    var db = Store.db();
    var stats = Engine.employeeStats();
    var totalCost = db.employees.filter(function (e) { return e.state !== "Inativo"; }).reduce(function (a, e) {
      return a + Engine.employeeMonthlyCost(e, Store.todayISO());
    }, 0);

    var head = V.head("Funcionários", db.employees.length + " na equipa · " + money(totalCost) + " custo mensal",
      App.isAdmin() ? '<button class="btn primary" data-act="employee-new">' + UI.icon("user-plus", 17) + " Novo funcionário</button>" : "");

    var cards = db.employees.length ? '<div class="vstack">' + db.employees.map(function (e) {
      var st = stats[e.id] || { revenue: 0, sales: 0, openTasks: 0 };
      var cost = Engine.employeeMonthlyCost(e, Store.todayISO());
      return '<div class="card" style="padding:16px">' +
        '<div class="hstack" style="align-items:flex-start">' +
        '<div class="tile" style="width:44px;height:44px;border-radius:14px;background:var(--surface);display:grid;place-items:center;font-weight:700;font-size:13px;color:var(--lime)">' +
        UI.esc(V.avatar(e.name)) + "</div>" +
        '<div style="flex:1;min-width:0"><div style="font-size:15px;font-weight:650">' + UI.esc(e.name) + "</div>" +
        '<div class="tiny muted">' + UI.esc(Store.listName("role", e.roleId, "—")) + " · " + UI.esc(Store.listName("department", e.departmentId, "—")) + "</div>" +
        '<div class="hstack" style="margin-top:6px">' +
        UI.statusChip(e.state, "") +
        (e.permission === "admin" ? '<span class="chip lime">Administrador</span>' : '<span class="chip">Operador</span>') +
        (e.pin ? '<span class="chip outline">PIN</span>' : "") + "</div></div>" +
        '<div class="right"><div style="font-weight:750;font-size:15px">' + money(cost) + '</div><div class="tiny muted">custo/mês</div></div></div>' +
        '<div class="divider" style="margin:11px 0"></div>' +
        '<div class="tiny muted">' + money(e.baseSalary) + " base · encargos " +
        Store.pct(e.chargesDefault || e.chargesPct === null ? db.config.payrollPct : e.chargesPct) + "</div>" +
        '<div class="tiny muted" style="margin-top:2px">' + st.sales + " vendas · " + money(st.revenue) + " · " + st.openTasks + " tarefas em aberto</div>" +
        '<div class="btn-row" style="margin-top:12px">' +
        '<button class="btn ghost sm" data-act="employee-profile" data-id="' + e.id + '">Ficha</button>' +
        (App.isAdmin() ? '<button class="btn ghost sm" data-act="employee-edit" data-id="' + e.id + '">Editar</button>' +
          '<button class="btn ghost sm" data-act="employee-salary" data-id="' + e.id + '">Reajuste</button>' : "") +
        "</div></div>";
    }).join("") + "</div>" : UI.emptyState("user", "Sem funcionários registados.");

    return '<div class="view">' + head + cards + "</div>";
  }

  function openEmployeeForm(id) {
    var db = Store.db();
    var e = id ? employee(id) : null;
    var fields = [
      { k: "name", label: "Nome", type: "text", required: true, full: true },
      { k: "roleId", label: "Cargo", type: "select", options: UI.optsFromList("role") },
      { k: "departmentId", label: "Departamento", type: "select", options: UI.optsFromList("department") },
      { k: "hireDate", label: "Data de admissão", type: "date", required: true },
      { k: "exitDate", label: "Data de saída", type: "date", help: "Deixe vazio se ainda está ativo." },
      { k: "baseSalary", label: "Salário base mensal", type: "money", required: true },
      { k: "chargesPct", label: "Encargos % (vazio = padrão)", type: "pct", help: "Padrão da empresa: " + Store.pct(db.config.payrollPct) },
      { k: "email", label: "Email", type: "email" },
      { k: "phone", label: "Telefone / WhatsApp", type: "tel" },
      { k: "state", label: "Estado", type: "select", options: ["Ativo", "Férias", "Inativo"], blank: false },
      { k: "permission", label: "Perfil", type: "select", options: [{ id: "admin", name: "Administrador" }, { id: "operator", name: "Operador de caixa" }], blank: false },
      { k: "pin", label: "PIN (4 algarismos)", type: "text", placeholder: "Opcional", help: "Usado para trocar de operador no caixa." },
      { k: "notes", label: "Notas", type: "textarea" }
    ];
    var values = e ? Object.assign({}, e) : {
      state: "Ativo", permission: "operator", hireDate: Store.todayISO(), baseSalary: 0,
      chargesPct: "", pin: ""
    };
    if (e) values.chargesPct = e.chargesPct === null || e.chargesPct === undefined ? "" : e.chargesPct;
    UI.form({
      title: e ? "Editar funcionário" : "Novo funcionário",
      subtitle: "O custo mensal total inclui os encargos patronais.",
      fields: fields,
      values: values,
      submitLabel: e ? "Guardar" : "Criar funcionário",
      validate: function (v) {
        if (v.pin && !/^\d{4}$/.test(v.pin)) return "O PIN deve ter exatamente 4 algarismos.";
        if (v.permission === "operator" && e && e.permission === "admin") {
          var admins = db.employees.filter(function (x) { return x.permission === "admin" && x.state !== "Inativo" && x.id !== e.id; });
          if (!admins.length) return "Deve existir sempre pelo menos um administrador.";
        }
        if (v.state === "Inativo" && e && e.permission === "admin" && !v.exitDate) {
          var admins2 = db.employees.filter(function (x) { return x.permission === "admin" && x.state !== "Inativo" && x.id !== e.id; });
          if (!admins2.length) return "Deve existir sempre pelo menos um administrador ativo.";
        }
        return null;
      },
      onSubmit: function (v) {
        var data = {
          name: v.name, roleId: v.roleId, departmentId: v.departmentId,
          hireDate: v.hireDate, exitDate: v.exitDate || "",
          baseSalary: Store.round2(Store.num(v.baseSalary)),
          chargesPct: v.chargesPct === "" ? null : Store.num(v.chargesPct) / 100,
          chargesDefault: v.chargesPct === "",
          email: v.email, phone: v.phone, state: v.state,
          permission: v.permission, pin: v.pin || "", notes: v.notes
        };
        if (e) Object.assign(e, data);
        else db.employees.push(Object.assign({ id: Store.nextId("employee", "FUN-", 3), salaryHistory: [] }, data));
        Store.save();
        App.onData(e ? "Funcionário atualizado." : "Funcionário criado.");
        App.render();
      }
    });
  }

  function openEmployeeProfile(id) {
    var db = Store.db();
    var e = employee(id);
    if (!e) return;
    var st = Engine.employeeStats()[id] || { revenue: 0, sales: 0, openTasks: 0 };
    var sales = db.sales.filter(function (s) { return s.sellerId === id && s.state !== "Cancelada"; })
      .sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    var tasks = db.tasks.filter(function (t) { return t.employeeId === id; });
    var history = (e.salaryHistory || []).slice().sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    var body = '<div class="detail-hero" style="margin-bottom:12px"><div class="top"><div>' +
      '<div class="eyebrow">Custo mensal</div><div class="amt">' + money(Engine.employeeMonthlyCost(e, Store.todayISO())) + "</div>" +
      '<div class="hstack" style="margin-top:8px">' + UI.statusChip(e.state, "") +
      '<span class="chip">' + (e.permission === "admin" ? "Administrador" : "Operador") + "</span></div></div>" +
      '<div class="right"><div class="eyebrow">Vendido s/IVA</div><div class="amt" style="font-size:20px">' + money(st.revenue) + "</div>" +
      '<div class="tiny muted">' + st.sales + " vendas</div></div></div></div>" +
      '<div class="kv">' +
      row("Cargo", UI.esc(Store.listName("role", e.roleId, "—"))) +
      row("Departamento", UI.esc(Store.listName("department", e.departmentId, "—"))) +
      row("Admissão", Store.dateLong(e.hireDate)) +
      row("Saída", e.exitDate ? Store.dateLong(e.exitDate) : "—") +
      row("Salário base", money(e.baseSalary)) +
      row("Encargos", Store.pct(e.chargesDefault || e.chargesPct === null ? db.config.payrollPct : e.chargesPct)) +
      row("Email", UI.esc(e.email || "—")) +
      row("Telefone", UI.esc(e.phone || "—")) +
      row("Tarefas em aberto", String(st.openTasks)) +
      "</div>" +
      '<div class="divider"></div><div class="card-head"><div class="title">Histórico salarial</div>' +
      '<button class="btn sm soft" data-sal="1">+ Alteração</button></div>' +
      (history.length ? '<div class="rows">' + history.map(function (h) {
        return '<div class="row"><div class="tile">' + UI.icon("percent", 16) + "</div>" +
          '<div class="body"><div class="name">' + money(h.salary) + '</div><div class="meta">desde ' + Store.dateLong(h.date) + "</div></div></div>";
      }).join("") + "</div>" : '<p class="small muted">Sem alterações registadas. O salário base aplica-se desde a admissão.</p>') +
      (sales.length ? '<div class="divider"></div><div class="card-head"><div class="title">Últimas vendas</div></div><div class="rows">' +
        sales.slice(0, 6).map(function (s) {
          return '<a class="row" href="#/vendas/' + s.id + '"><div class="tile">' + UI.icon("receipt", 16) + "</div>" +
            '<div class="body"><div class="name">' + Engine.saleLabel(s) + '</div><div class="meta">' + Store.dateShort(s.date) + "</div></div>" +
            '<div class="end"><div class="amount sm">' + money(Engine.saleTotals(s).total) + "</div></div></a>";
        }).join("") + "</div>" : "") +
      (tasks.length ? '<div class="divider"></div><div class="card-head"><div class="title">Tarefas</div></div><div class="rows">' +
        tasks.slice(0, 6).map(function (t) {
          var stt = Engine.taskStatus(t);
          return '<div class="row"><div class="tile">' + UI.icon("clipboard-list", 16) + "</div>" +
            '<div class="body"><div class="name">' + UI.esc(t.title) + '</div><div class="meta">' + Store.dateShort(t.dueDate) + "</div></div>" +
            '<div class="end"><span class="chip ' + (t.state === "Concluída" ? "green" : stt.alert === "ATRASADA" ? "red" : "blue") + '">' +
            UI.esc(t.state === "Concluída" ? "Concluída" : stt.alert || t.state) + "</span></div></div>";
        }).join("") + "</div>" : "");

    var ov = UI.openSheet('<div class="sheet-head"><div class="ttl"><h2>' + UI.esc(e.name) + "</h2><p>" + e.id + " · " +
      UI.esc(Store.listName("role", e.roleId, "—")) + "</p></div>" +
      '<button class="icon-btn ghost" data-x="1">' + UI.icon("x", 18) + "</button></div><div class=\"sheet-body\">" + body + "</div>", "");
    ov.querySelector("[data-x]").onclick = UI.closeSheet;
    var salBtn = ov.querySelector("[data-sal]");
    if (salBtn) salBtn.onclick = function () {
      function ask() {
        UI.form({
          title: "Alteração salarial",
          subtitle: "Guarda o histórico sem alterar o salário original.",
          fields: [
            { k: "date", label: "Data de início", type: "date", required: true, value: Store.todayISO() },
            { k: "salary", label: "Novo salário base", type: "money", required: true, value: e.baseSalary }
          ],
          submitLabel: "Registar",
          onSubmit: function (v) {
            e.salaryHistory = e.salaryHistory || [];
            e.salaryHistory.push({ date: v.date, salary: Store.round2(Store.num(v.salary)) });
            Store.save();
            App.onData("Histórico salarial atualizado.");
            App.render();
            setTimeout(function () { openEmployeeProfile(id); }, 60);
          }
        });
      }
      if (!App.isAdmin()) { UI.toast("Apenas administradores alteram salários.", "err"); return; }
      ask();
    };
  }

  /* ==================================================================
     TAREFAS
  ================================================================== */
  function tasks() {
    var db = Store.db();
    var f = App.taskFilter || (App.taskFilter = { state: "Abertas", priority: "" });
    var list = db.tasks.slice();
    if (f.state === "Abertas") list = list.filter(function (t) { return t.state !== "Concluída"; });
    else if (f.state !== "Todas") list = list.filter(function (t) { return t.state === f.state; });
    if (f.priority) list = list.filter(function (t) { return t.priority === f.priority; });
    list.sort(function (a, b) {
      var sa = Engine.taskStatus(a), sb = Engine.taskStatus(b);
      var wa = sa.alert === "ATRASADA" ? 0 : sa.alert ? 1 : 2;
      var wb = sb.alert === "ATRASADA" ? 0 : sb.alert ? 1 : 2;
      if (wa !== wb) return wa - wb;
      return (a.dueDate || "9999") < (b.dueDate || "9999") ? -1 : 1;
    });

    var late = db.tasks.filter(function (t) { return t.state !== "Concluída" && Engine.taskStatus(t).alert === "ATRASADA"; }).length;
    var soon = db.tasks.filter(function (t) { return t.state !== "Concluída" && Engine.taskStatus(t).alert === "Prazo próximo"; }).length;
    var open = db.tasks.filter(function (t) { return t.state !== "Concluída"; }).length;

    var head = V.head("Tarefas", "Projetos e prazos · " + open + " em aberto · " + late + " atrasadas",
      '<button class="btn primary" data-act="task-new">' + UI.icon("plus", 17) + " Nova tarefa</button>");

    var summary = '<div class="grid cols-3" style="margin-bottom:14px">' +
      V.kpi("Em aberto", String(open), "accent-lime") +
      V.kpi("Atrasadas", String(late), late ? "accent-red" : "") +
      V.kpi("Prazo próximo", String(soon), soon ? "accent-orange" : "") + "</div>";

    var tabs = '<div class="tabs">' + ["Abertas", "A fazer", "Em curso", "Concluída", "Todas"].map(function (s) {
      return '<button data-act="task-filter" data-id="' + s + '" aria-pressed="' + (f.state === s) + '">' + s + "</button>";
    }).join("") + '<button data-act="task-priority" data-id="' + (f.priority === "Urgente" ? "" : "Urgente") + '" aria-pressed="' +
      (f.priority === "Urgente") + '" style="margin-left:auto">Urgentes</button></div>';

    var rows = list.length ? '<div class="vstack">' + list.map(function (t) {
      var st = Engine.taskStatus(t);
      var emp = employee(t.employeeId), cl = client(t.clientId);
      var pr = Store.listName("priority", t.priority, "—");
      var cls = pr === "Urgente" ? "red" : pr === "Alta" ? "orange" : pr === "Média" ? "blue" : "";
      return '<div class="card" style="padding:14px 16px">' +
        '<div class="hstack" style="align-items:flex-start">' +
        '<button class="tile" style="width:30px;height:30px;border-radius:9px;background:rgba(243,246,248,.06);display:grid;place-items:center;color:' +
        (t.state === "Concluída" ? "var(--green)" : "var(--text-3)") + '" data-act="task-toggle" data-id="' + t.id + '" aria-label="Concluir">' +
        UI.icon(t.state === "Concluída" ? "check-circle" : "check", 16) + "</button>" +
        '<div style="flex:1;min-width:0"><div style="font-size:14px;font-weight:600;' +
        (t.state === "Concluída" ? "text-decoration:line-through;color:var(--text-2)" : "") + '">' + UI.esc(t.title) + "</div>" +
        '<div class="tiny muted" style="margin-top:2px">' + UI.esc(emp ? emp.name : "—") +
        (cl ? " · " + UI.esc(cl.name) : "") + " · prazo " + Store.dateShort(t.dueDate) + "</div>" +
        '<div class="hstack" style="margin-top:7px"><span class="chip ' + cls + '">' + UI.esc(pr) + "</span>" +
        '<span class="chip">' + UI.esc(t.state) + "</span>" +
        (st.alert === "ATRASADA" ? '<span class="chip red">Atrasada ' + Math.abs(st.days) + "d</span>" :
          st.alert ? '<span class="chip orange">' + st.days + " dias</span>" :
            (t.state !== "Concluída" && st.days !== null ? '<span class="chip">' + st.days + " dias</span>" : "")) + "</div></div>" +
        '<button class="btn-icon" data-act="task-edit" data-id="' + t.id + '" aria-label="Editar">' + UI.icon("edit", 15) + "</button></div></div>";
    }).join("") + "</div>" : UI.emptyState("clipboard-list", "Sem tarefas neste filtro.",
      '<button class="btn primary" data-act="task-new">Criar tarefa</button>');

    return '<div class="view">' + head + summary + tabs + rows + "</div>";
  }

  function openTaskForm(id, presetClientId) {
    var db = Store.db();
    var t = id ? db.tasks.find(function (x) { return x.id === id; }) : null;
    var fields = [
      { k: "title", label: "Tarefa", type: "text", required: true, full: true },
      { k: "employeeId", label: "Responsável", type: "select", required: true, options: V.employeeOptions(true) },
      { k: "clientId", label: "Cliente (opcional)", type: "select", options: [{ id: "", name: "— Sem cliente —" }].concat(V.clientOptions()) },
      { k: "priority", label: "Prioridade", type: "select", required: true, blank: false, options: UI.optsFromList("priority", null) },
      { k: "state", label: "Estado", type: "select", required: true, blank: false, options: ["A fazer", "Em curso", "Concluída"] },
      { k: "startDate", label: "Data de início", type: "date" },
      { k: "dueDate", label: "Prazo", type: "date" },
      { k: "notes", label: "Notas", type: "textarea" }
    ];
    UI.form({
      title: t ? "Editar tarefa" : "Nova tarefa",
      fields: fields,
      values: t || {
        employeeId: (App.currentUser() || {}).id, clientId: presetClientId || "",
        priority: (Store.listValues("priority")[1] || {}).id, state: "A fazer",
        startDate: Store.todayISO(), dueDate: Store.addDays(Store.todayISO(), 7)
      },
      submitLabel: t ? "Guardar" : "Criar tarefa",
      onSubmit: function (v) {
        var data = {
          title: v.title, employeeId: v.employeeId, clientId: v.clientId || null,
          priority: v.priority, state: v.state, startDate: v.startDate,
          dueDate: v.dueDate, notes: v.notes
        };
        if (t) Object.assign(t, data);
        else db.tasks.push(Object.assign({ id: Store.nextId("task", "TRF-", 4) }, data));
        Store.save();
        App.onData(t ? "Tarefa atualizada." : "Tarefa criada.");
        App.render();
      }
    });
  }

  /* ------------------------------- ações --------------------------- */
  Actions["client-new"] = function () { openClientForm(null); };
  Actions["client-edit"] = function (id) { openClientForm(id); };
  Actions["client-sell"] = function (id) { openSaleEditor(null, { clientId: id }); };
  Actions["client-deactivate"] = function (id) {
    var c = client(id); if (!c) return;
    c.state = "Inativo"; Store.save(); App.onData("Cliente inativado."); App.render();
  };
  Actions["client-activate"] = function (id) {
    var c = client(id); if (!c) return;
    c.state = "Ativo"; Store.save(); App.onData("Cliente reativado."); App.render();
  };
  Actions["client-delete"] = function (id) {
    var db = Store.db();
    var hasDocs = db.sales.some(function (s) { return s.clientId === id; });
    if (hasDocs) { UI.toast("Não é possível eliminar: existem vendas associadas. Inative o cliente.", "err"); return; }
    UI.confirm({ title: "Eliminar cliente", message: "O cliente será removido definitivamente.", confirmLabel: "Eliminar", danger: true })
      .then(function (ok) {
        if (!ok) return;
        db.clients = db.clients.filter(function (c) { return c.id !== id; });
        Store.save(); App.onData("Cliente eliminado."); App.go("#/clientes");
      });
  };

  Actions["employee-new"] = function () {
    if (!App.isAdmin()) { UI.toast("Apenas administradores gerem funcionários.", "err"); return; }
    openEmployeeForm(null);
  };
  Actions["employee-edit"] = function (id) {
    if (!App.isAdmin()) { UI.toast("Apenas administradores gerem funcionários.", "err"); return; }
    openEmployeeForm(id);
  };
  Actions["employee-profile"] = function (id) { openEmployeeProfile(id); };
  Actions["employee-salary"] = function (id) {
    if (!App.isAdmin()) { UI.toast("Apenas administradores alteram salários.", "err"); return; }
    var e = employee(id); if (!e) return;
    UI.form({
      title: "Alteração salarial",
      fields: [
        { k: "date", label: "Data de início", type: "date", required: true, value: Store.todayISO() },
        { k: "salary", label: "Novo salário base", type: "money", required: true, value: e.baseSalary }
      ],
      submitLabel: "Registar",
      onSubmit: function (v) {
        e.salaryHistory = e.salaryHistory || [];
        e.salaryHistory.push({ date: v.date, salary: Store.round2(Store.num(v.salary)) });
        Store.save(); App.onData("Histórico salarial atualizado."); App.render();
      }
    });
  };

  Actions["task-new"] = function (id) { openTaskForm(null, id || null); };
  Actions["task-edit"] = function (id) { openTaskForm(id); };
  Actions["task-toggle"] = function (id) {
    var t = Store.db().tasks.find(function (x) { return x.id === id; });
    if (!t) return;
    t.state = t.state === "Concluída" ? "A fazer" : "Concluída";
    Store.save(); App.onData(t.state === "Concluída" ? "Tarefa concluída." : "Tarefa reaberta."); App.render();
  };
  Actions["task-filter"] = function (id) { App.taskFilter.state = id; App.render(); };
  Actions["task-priority"] = function (id) { App.taskFilter.priority = id; App.render(); };

  document.addEventListener("change", function (e) {
    if (!e.target) return;
    if (e.target.getAttribute("data-act") === "client-state") { App.clientFilter.state = e.target.value; App.render(); }
  });

  function row(k, v) { return '<div class="it"><span class="k">' + k + '</span><span class="v">' + v + "</span></div>"; }

  window.Views.clients = clients;
  window.Views.clientDetail = clientDetail;
  window.Views.employees = employees;
  window.Views.tasks = tasks;
  window.openClientForm = openClientForm;
  window.openEmployeeForm = openEmployeeForm;
  window.openTaskForm = openTaskForm;
})();
