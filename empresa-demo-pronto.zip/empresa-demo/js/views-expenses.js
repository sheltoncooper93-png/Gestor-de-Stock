/* ============================================================
   VIEWS — Despesas e catálogo de serviços/produtos
   ============================================================ */
(function () {
  "use strict";

  var money = Store.money;

  function supplierOptions(blank) {
    var arr = Store.db().suppliers.map(function (s) { return { id: s.id, name: s.name }; });
    if (blank !== null) arr.unshift({ id: "", name: blank || "— Sem fornecedor —" });
    return arr;
  }

  /* ==================================================================
     DESPESAS
  ================================================================== */
  function expenses() {
    var db = Store.db();
    var now = new Date();
    var monthKey = now.getFullYear() + "-" + String(now.getMonth() + 1).padStart(2, "0");
    var f = App.expFilter || (App.expFilter = { q: "", state: "Todas", categoryId: "", period: "all" });

    var list = db.expenses.slice();
    if (f.state === "Pendentes") list = list.filter(function (x) { return x.state !== "Paga"; });
    if (f.state === "Pagas") list = list.filter(function (x) { return x.state === "Paga"; });
    if (f.categoryId) list = list.filter(function (x) { return x.categoryId === f.categoryId; });
    if (f.period === "month") list = list.filter(function (x) { return (x.date || "").slice(0, 7) === monthKey; });
    if (f.period === "year") list = list.filter(function (x) { return (x.date || "").slice(0, 4) === String(db.config.refYear); });
    if (f.q) {
      var q = f.q.toLowerCase();
      list = list.filter(function (x) {
        return (x.description + " " + (x.id || "")).toLowerCase().indexOf(q) >= 0;
      });
    }
    list.sort(function (a, b) { return a.date > b.date ? -1 : 1; });

    var monthTotal = 0, yearTotal = 0, pending = 0, listTotal = 0;
    var cats = {};
    db.expenses.forEach(function (x) {
      var y = (x.date || "").slice(0, 4), m = (x.date || "").slice(0, 7);
      if (y === String(db.config.refYear)) yearTotal += Store.num(x.amountNet);
      if (m === monthKey) {
        monthTotal += Store.num(x.amountNet);
        cats[x.categoryId] = (cats[x.categoryId] || 0) + Store.num(x.amountNet);
      }
      if (x.state !== "Paga") pending += Store.num(x.total);
    });
    list.forEach(function (x) { listTotal += Store.num(x.amountNet); });

    var catRows = Object.keys(cats).map(function (k) {
      return { id: k, name: V.categoryName(k), value: cats[k] };
    }).sort(function (a, b) { return b.value - a.value; });
    var palette = ["#b9fc01", "#6b8cff", "#f5a94a", "#4ade80", "#ff7a7a", "#a78bfa"];

    var head = V.head("Despesas", "Operacionais, separadas das compras de mercadoria",
      '<button class="btn primary" data-act="expense-new">' + UI.icon("plus", 17) + " Nova despesa</button>");

    var hero = '<div class="card" style="margin-bottom:12px"><div class="card-head"><div class="title">Total de ' +
      Store.MONTHS_LONG[now.getMonth()] + "</div><span class=\"pill-note\">" + money(monthTotal) + "</span></div>" +
      '<div style="font-size:32px;font-weight:800;letter-spacing:-.04em;font-variant-numeric:tabular-nums">' + money(monthTotal) + "</div>" +
      (catRows.length ? '<div class="hstack" style="gap:3px;margin:14px 0 10px">' + catRows.map(function (c, i) {
        var p = monthTotal > 0 ? (c.value / monthTotal * 100) : 0;
        return '<div style="height:7px;border-radius:999px;background:' + palette[i % palette.length] + ';width:' + Math.max(p, 1) + '%"></div>';
      }).join("") + "</div>" +
        '<div class="legend">' + catRows.slice(0, 4).map(function (c, i) {
          return '<span><i style="background:' + palette[i % palette.length] + '"></i>' + UI.esc(c.name) + "</span>";
        }).join("") + "</div>" : '<p class="small muted" style="margin-top:8px">Sem despesas registadas este mês.</p>') + "</div>";

    var summary = '<div class="grid cols-3" style="margin-bottom:14px">' +
      V.kpi("Ano " + db.config.refYear, money(yearTotal), "accent-orange") +
      V.kpi("Listado", money(listTotal), "", list.length + " registos") +
      V.kpi("Por pagar", money(pending), pending ? "accent-red" : "") + "</div>";

    var tabs = '<div class="tabs">' + ["Todas", "Pendentes", "Pagas"].map(function (s) {
      return '<button data-act="exp-filter" data-id="' + s + '" aria-pressed="' + (f.state === s) + '">' + s + "</button>";
    }).join("") + '<button data-act="exp-report" style="margin-left:auto">Relatório por categoria</button></div>';

    var filterBar = '<div class="hstack" style="margin-bottom:12px">' +
      '<div class="search" style="flex:1;min-width:120px;height:42px">' + UI.icon("search", 17) +
      '<input placeholder="Pesquisar despesa" data-act="exp-search" value="' + UI.esc(f.q) + '"></div>' +
      '<select class="select" data-act="exp-category" style="width:auto;height:42px;min-height:42px;border-radius:999px;font-size:12.5px;padding:8px 32px 8px 13px">' +
      '<option value="">Categorias</option>' + UI.optsFromList("expenseCategory", null).map(function (o) {
        return '<option value="' + o.id + '"' + (f.categoryId === o.id ? " selected" : "") + ">" + UI.esc(o.name) + "</option>";
      }).join("") + "</select>" +
      '<select class="select" data-act="exp-period" style="width:auto;height:42px;min-height:42px;border-radius:999px;font-size:12.5px;padding:8px 32px 8px 13px">' +
      [["all", "Tudo"], ["month", "Este mês"], ["year", "Este ano"]].map(function (o) {
        return '<option value="' + o[0] + '"' + (f.period === o[0] ? " selected" : "") + ">" + o[1] + "</option>";
      }).join("") + "</select></div>";

    var icons = { "Renda": "home", "Água / Luz / Internet": "help", "Marketing e publicidade": "star", "Software e subscrições": "database", "Material de escritório": "file-text", "Deslocações": "truck", "Impostos e taxas": "percent", "Serviços externos": "users", "Formação": "clipboard-list", "Seguros": "lock", "Equipamento": "settings" };

    var rows = list.length ? '<div class="group">' + list.map(function (x) {
      var cname = V.categoryName(x.categoryId);
      var sup = db.suppliers.find(function (s) { return s.id === x.supplierId; });
      return '<div class="row" data-act="expense-open" data-id="' + x.id + '" style="cursor:pointer">' +
        '<div class="tile orange">' + UI.icon(icons[cname] || "wallet", 18) + "</div>" +
        '<div class="body"><div class="name">' + UI.esc(x.description) + '</div>' +
        '<div class="meta">' + UI.esc(cname) + " · " + Store.dateShort(x.date) + (sup ? " · " + UI.esc(sup.name) : "") +
        (x.recurring ? " · recorrente" : "") + "</div></div>" +
        '<div class="end"><div class="amount">' + money(x.total) + "</div>" +
        (x.state === "Paga" ? '<span class="chip green">Paga</span>' : '<span class="chip orange">Pendente</span>') + "</div></div>";
    }).join("") + "</div>" : UI.emptyState("wallet", "Sem despesas neste filtro.",
      '<button class="btn primary" data-act="expense-new">Registar despesa</button>');

    App.afterRender = function () {
      var i = document.querySelector('[data-act="exp-search"]');
      if (i) i.addEventListener("input", UI.debounce(function () {
        f.q = i.value; App.render();
        var a = document.querySelector('[data-act="exp-search"]');
        if (a) { a.focus(); a.setSelectionRange(a.value.length, a.value.length); }
      }, 240));
    };

    return '<div class="view">' + head + hero + summary + tabs + filterBar + rows + "</div>";
  }

  function openExpenseForm(id) {
    var db = Store.db();
    var x = id ? db.expenses.find(function (e) { return e.id === id; }) : null;
    var base = x || {
      date: Store.todayISO(), description: "", categoryId: "",
      supplierId: "", amountNet: 0, vatRate: Store.num(db.config.vatDefault),
      method: "", state: "Pendente", recurring: false, notes: ""
    };
    var fields = [
      { k: "description", label: "Descrição", type: "text", required: true, full: true },
      { k: "date", label: "Data", type: "date", required: true },
      { k: "categoryId", label: "Categoria", type: "select", required: true, options: UI.optsFromList("expenseCategory") },
      { k: "supplierId", label: "Fornecedor", type: "select", options: supplierOptions() },
      { k: "amountNet", label: "Valor sem IVA", type: "money", required: true, value: 0 },
      { k: "vatRate", label: "IVA %", type: "select", options: Store.listValues("vatRate").map(function (v) { return { id: v.meta.rate, name: v.name }; }) },
      { k: "method", label: "Forma de pagamento", type: "select", options: UI.optsFromList("paymentMethod", "— Definir depois —") },
      { k: "state", label: "Estado", type: "select", options: ["Paga", "Pendente"], blank: false },
      { k: "recurring", label: "Despesa recorrente", type: "checkbox" },
      { k: "notes", label: "Notas", type: "textarea" },
      { k: "calc", type: "static", html: "" }
    ];
    var ov = UI.form({
      title: x ? "Editar despesa" : "Nova despesa",
      subtitle: "O IVA e o total são calculados automaticamente.",
      fields: fields,
      values: Object.assign({}, base, { vatRate: String(Store.num(base.vatRate)) }),
      submitLabel: x ? "Guardar" : "Registar despesa",
      onChange: function (v) {
        var vat = Store.num(v.amountNet) * Store.num(v.vatRate);
        var el = ov.querySelector(".form-note:last-of-type");
        if (el) el.innerHTML = "IVA <b>" + money(vat) + "</b> · Total <b>" + money(Store.num(v.amountNet) + vat) + "</b>";
      },
      validate: function (v) {
        if (Store.num(v.amountNet) <= 0) return "O valor sem IVA deve ser superior a zero.";
        return null;
      },
      onSubmit: function (v) {
        var vat = Store.round2(Store.num(v.amountNet) * Store.num(v.vatRate));
        var data = {
          date: v.date, description: v.description, categoryId: v.categoryId,
          supplierId: v.supplierId || null, amountNet: Store.round2(Store.num(v.amountNet)),
          vatRate: Store.num(v.vatRate), vat: vat,
          total: Store.round2(Store.num(v.amountNet) + vat),
          method: v.method || null, state: v.state, recurring: !!v.recurring, notes: v.notes
        };
        if (x) Object.assign(x, data);
        else db.expenses.push(Object.assign({ id: Store.nextId("expense", "DP-", 4) }, data));
        Store.save();
        App.onData(x ? "Despesa atualizada." : "Despesa registada.");
        App.render();
      }
    });
    setTimeout(function () {
      var vat = Store.num(base.amountNet) * Store.num(base.vatRate);
      var note = ov.querySelector(".form-note:last-of-type");
      if (note) note.innerHTML = "IVA <b>" + money(vat) + "</b> · Total <b>" + money(Store.num(base.amountNet) + vat) + "</b>";
    }, 40);
  }

  function openExpenseDetail(id) {
    var db = Store.db();
    var x = db.expenses.find(function (e) { return e.id === id; });
    if (!x) return;
    var sup = db.suppliers.find(function (s) { return s.id === x.supplierId; });
    var ov = UI.openSheet(
      '<div class="sheet-head"><div class="ttl"><h2>' + UI.esc(x.description) + "</h2><p>" + x.id + " · " + Store.dateLong(x.date) + "</p></div>" +
      '<button class="icon-btn ghost" data-x="1">' + UI.icon("x", 18) + "</button></div>" +
      '<div class="sheet-body"><div class="kv">' +
      '<div class="it"><span class="k">Categoria</span><span class="v">' + UI.esc(V.categoryName(x.categoryId)) + "</span></div>" +
      '<div class="it"><span class="k">Fornecedor</span><span class="v">' + UI.esc(sup ? sup.name : "—") + "</span></div>" +
      '<div class="it"><span class="k">Valor sem IVA</span><span class="v">' + money(x.amountNet) + "</span></div>" +
      '<div class="it"><span class="k">IVA (" + Store.pct(x.vatRate, 0) + ")</span><span class="v">' + money(x.vat) + "</span></div>" +
      '<div class="it"><span class="k">Total</span><span class="v big">' + money(x.total) + "</span></div>" +
      '<div class="it sep"><span class="k">Forma de pagamento</span><span class="v">' + UI.esc(Store.listName("paymentMethod", x.method, "—")) + "</span></div>" +
      '<div class="it"><span class="k">Estado</span><span class="v">' + (x.state === "Paga" ? "Paga" : "Pendente") + "</span></div>" +
      '<div class="it"><span class="k">Recorrente</span><span class="v">' + (x.recurring ? "Sim" : "Não") + "</span></div>" +
      "</div>" + (x.notes ? '<div class="divider"></div><p class="small muted">' + UI.esc(x.notes) + "</p>" : "") +
      '<div class="btn-row" style="margin-top:16px">' +
      (x.state !== "Paga" ? '<button class="btn primary" data-pay="1">' + UI.icon("check", 16) + " Marcar paga</button>" : "") +
      '<button class="btn ghost" data-edit="1">' + UI.icon("edit", 16) + " Editar</button>" +
      '<button class="btn danger" data-del="1">' + UI.icon("trash", 16) + " Eliminar</button></div></div>", "");
    ov.querySelector("[data-x]").onclick = UI.closeSheet;
    var pay = ov.querySelector("[data-pay]");
    if (pay) pay.onclick = function () { x.state = "Paga"; Store.save(); UI.closeSheet(); App.onData("Despesa paga."); App.render(); };
    ov.querySelector("[data-edit]").onclick = function () { UI.closeSheet(); openExpenseForm(id); };
    ov.querySelector("[data-del]").onclick = function () {
      UI.closeSheet();
      UI.confirm({ title: "Eliminar despesa", message: "Esta ação não pode ser revertida.", confirmLabel: "Eliminar", danger: true })
        .then(function (ok) {
          if (!ok) return;
          Store.db().expenses = Store.db().expenses.filter(function (e) { return e.id !== id; });
          Store.save(); App.onData("Despesa eliminada."); App.render();
        });
    };
  }

  function openExpenseReport() {
    var db = Store.db();
    var year = db.config.refYear;
    var cat = Engine.expensesByCategory(year);
    var rows = cat.rows;
    var palette = ["#b9fc01", "#6b8cff", "#f5a94a", "#4ade80", "#ff7a7a", "#a78bfa", "#38bdf8"];
    var body = '<div class="vstack">' +
      (rows.length ? UI.donut(rows.map(function (r, i) { return { name: r.name, value: r.value, color: palette[i % palette.length] }; }), cat.total, "total " + year, money(cat.total, { compact: true })) : "") +
      '<div class="chart-legend" style="gap:12px">' + rows.map(function (r, i) {
        return '<div><div class="li"><i style="background:' + palette[i % palette.length] + '"></i><span class="nm" style="flex:1">' +
          UI.esc(r.name) + '</span><span class="vl">' + money(r.value) + " · " + Store.pct(r.pct) + "</span></div>" +
          '<div class="bar" style="margin-top:5px"><i style="width:' + (r.pct * 100).toFixed(1) + "%;background:" + palette[i % palette.length] + '"></i></div></div>';
      }).join("") + "</div>" +
      '<div class="form-note">O total inclui todas as categorias com movimento. Diferenças aparecem como <b>Outras</b>.</div></div>';
    var ov = UI.openSheet('<div class="sheet-head"><div class="ttl"><h2>Despesas por categoria</h2><p>Ano ' + year + " · valores sem IVA</p></div>" +
      '<button class="icon-btn ghost" data-x="1">' + UI.icon("x", 18) + "</button></div><div class=\"sheet-body\">" + body + "</div>", "");
    ov.querySelector("[data-x]").onclick = UI.closeSheet;
  }

  /* ==================================================================
     CATÁLOGO
  ================================================================== */
  function catalog() {
    var db = Store.db();
    var f = App.catFilter || (App.catFilter = { q: "", typeId: "", categoryId: "" });
    var stats = Engine.catalogStats();
    var list = db.catalog.slice();
    if (f.q) {
      var q = f.q.toLowerCase();
      list = list.filter(function (c) { return (c.name + " " + (c.barcode || "")).toLowerCase().indexOf(q) >= 0; });
    }
    if (f.typeId) list = list.filter(function (c) { return c.typeId === f.typeId; });
    if (f.categoryId) list = list.filter(function (c) { return c.categoryId === f.categoryId; });

    var totalRevenue = 0, totalCost = 0;
    db.catalog.forEach(function (c) {
      var st = stats[c.id]; if (!st) return;
      totalRevenue += st.revenue; totalCost += st.cost;
    });

    var head = V.head("Serviços e produtos", db.catalog.length + " itens no catálogo · " + money(totalRevenue) + " faturado s/IVA",
      '<button class="btn primary" data-act="catalog-new">' + UI.icon("plus", 17) + " Novo item</button>");

    var summary = '<div class="grid cols-3" style="margin-bottom:14px">' +
      V.kpi("Faturado s/IVA", money(totalRevenue), "accent-lime") +
      V.kpi("Custo das vendas", money(totalCost)) +
      V.kpi("Margem média", Store.pct(totalRevenue > 0 ? (totalRevenue - totalCost) / totalRevenue : 0), "accent-green") + "</div>";

    var tabs = '<div class="tabs">' +
      '<button data-act="cat-type" data-id="" aria-pressed="' + (!f.typeId) + '">Todos</button>' +
      Store.listValues("itemType").map(function (t) {
        return '<button data-act="cat-type" data-id="' + t.id + '" aria-pressed="' + (f.typeId === t.id) + '">' + UI.esc(t.name) + "</button>";
      }).join("") + "</div>";

    var filterBar = '<div class="hstack" style="margin-bottom:12px">' +
      '<div class="search" style="flex:1;min-width:120px;height:42px">' + UI.icon("search", 17) +
      '<input placeholder="Pesquisar item" data-act="cat-search" value="' + UI.esc(f.q) + '"></div>' +
      '<select class="select" data-act="cat-category" style="width:auto;height:42px;min-height:42px;border-radius:999px;font-size:12.5px;padding:8px 32px 8px 13px">' +
      '<option value="">Categorias</option>' + UI.optsFromList("serviceCategory", null).map(function (o) {
        return '<option value="' + o.id + '"' + (f.categoryId === o.id ? " selected" : "") + ">" + UI.esc(o.name) + "</option>";
      }).join("") + "</select></div>";

    var rows = list.length ? '<div class="vstack">' + list.map(function (c) {
      var info = Engine.catalogInfo(c);
      var st = stats[c.id] || { qtySold: 0, revenue: 0 };
      return '<a class="card" href="#/catalogo/' + c.id + '" style="display:block;padding:14px 16px">' +
        '<div class="hstack" style="align-items:flex-start">' +
        '<div class="tile" style="width:40px;height:40px;border-radius:13px;background:var(--surface);display:grid;place-items:center;color:' +
        (c.typeId === Store.listValues("itemType")[0].id ? "var(--blue)" : "var(--lime)") + '">' +
        UI.icon(c.stockItemId ? "package" : "tag", 18) + "</div>" +
        '<div style="flex:1;min-width:0"><div class="name" style="font-size:14px;font-weight:650">' + UI.esc(c.name) +
        (c.active === false ? ' <span class="chip red">Inativo</span>' : "") + "</div>" +
        '<div class="tiny muted">' + UI.esc(Store.listName("itemType", c.typeId, "—")) + " · " +
        UI.esc(Store.listName("serviceCategory", c.categoryId, "—")) + " · " + UI.esc(Store.listName("unit", c.unitId, "—")) + "</div></div>" +
        '<div style="text-align:right"><div class="amount">' + money(info.priceWithVat) + '</div><div class="tiny muted">' + money(c.price) + " s/IVA</div></div></div>" +
        '<div class="hstack" style="margin-top:11px;justify-content:space-between">' +
        '<span class="tiny muted">custo ' + money(info.effectiveCost) + " · margem <b style=\"color:" +
        (info.margin >= 0.3 ? "var(--green)" : info.margin > 0 ? "var(--orange)" : "var(--red)") + '">' + Store.pct(info.margin) + "</b></span>" +
        '<span class="chip">' + Store.round2(st.qtySold) + " vendidos · " + money(st.revenue) + "</span></div></a>";
    }).join("") + "</div>" : UI.emptyState("tag", "Sem itens neste filtro.",
      '<button class="btn primary" data-act="catalog-new">Criar item</button>');

    App.afterRender = function () {
      var i = document.querySelector('[data-act="cat-search"]');
      if (i) i.addEventListener("input", UI.debounce(function () {
        f.q = i.value; App.render();
        var a = document.querySelector('[data-act="cat-search"]');
        if (a) { a.focus(); a.setSelectionRange(a.value.length, a.value.length); }
      }, 240));
    };

    return '<div class="view">' + head + summary + tabs + filterBar + rows + "</div>";
  }

  function catalogDetail(id) {
    var db = Store.db();
    var c = db.catalog.find(function (x) { return x.id === id; });
    if (!c) return Views.notFound();
    var info = Engine.catalogInfo(c);
    var st = Engine.catalogStats()[c.id] || { qtySold: 0, revenue: 0, cost: 0, profit: 0 };
    var stockItem = db.stock.find(function (s) { return s.id === c.stockItemId; });
    var stockStat = stockItem ? Engine.stockOf(stockItem.id) : null;
    var salesLines = [];
    db.sales.forEach(function (s) {
      if (s.state === "Cancelada") return;
      (s.items || []).forEach(function (ln) { if (ln.catalogId === id) salesLines.push({ s: s, ln: ln }); });
    });
    salesLines.sort(function (a, b) { return a.s.date < b.s.date ? 1 : -1; });

    var head = '<div class="page-head"><div class="titles">' +
      '<button class="pill-note" data-nav="#/catalogo" style="margin-bottom:8px">' + UI.icon("chevron-left", 14) + " Catálogo</button>" +
      '<div class="h1">' + UI.esc(c.name) + '</div><div class="sub">' + c.id + " · " +
      UI.esc(Store.listName("itemType", c.typeId, "—")) + " · " + UI.esc(Store.listName("serviceCategory", c.categoryId, "—")) + "</div></div>" +
      '<div class="btn-row"><button class="btn ghost" data-act="catalog-edit" data-id="' + c.id + '">' + UI.icon("edit", 16) + " Editar</button>" +
      '<button class="btn primary" data-act="catalog-sell" data-id="' + c.id + '">' + UI.icon("plus", 16) + " Vender</button></div></div>";

    var hero = '<div class="detail-hero"><div class="top"><div>' +
      '<div class="eyebrow">Preço com IVA</div><div class="amt">' + money(info.priceWithVat) + "</div>" +
      '<div class="hstack" style="margin-top:8px"><span class="chip">' + money(c.price) + ' s/IVA</span><span class="chip">IVA ' +
      Store.pct(info.vat, 0) + "</span>" + (c.active === false ? '<span class="chip red">Inativo</span>' : '<span class="chip green">Ativo</span>') + "</div></div>" +
      '<div class="right"><div class="eyebrow">Margem</div><div class="amt" style="font-size:22px;color:' +
      (info.margin >= 0.3 ? "var(--green)" : info.margin > 0 ? "var(--orange)" : "var(--red)") + '">' + Store.pct(info.margin) + "</div>" +
      '<div class="tiny muted">custo ' + money(info.effectiveCost) + "</div></div></div>" +
      '<div class="divider"></div><div class="kv">' +
      row("Unidade de venda", UI.esc(Store.listName("unit", c.unitId, "—"))) +
      row("Custo manual", money(c.manualCost)) +
      row("Custo efetivo", money(info.effectiveCost) + (c.stockItemId ? " (stock)" : " (manual)")) +
      row("Item de stock ligado", stockItem ? '<a href="#/stock/' + stockItem.id + '" style="color:var(--lime)">' + UI.esc(stockItem.name) + "</a>" : "—") +
      row("Consumo por unidade", c.stockItemId ? String(info.stockConsumption) : "—") +
      row("Quantidade vendida", Store.round2(st.qtySold)) +
      row("Receita s/IVA", money(st.revenue)) +
      row("Lucro gerado", money(st.profit)) +
      (stockStat ? row("Stock atual", Store.round2(stockStat.qty) + " · " + V.stockStatus(stockStat)) : "") +
      (c.barcode ? row("Código de barras", UI.esc(c.barcode)) : "") + "</div></div>";

    var desc = c.description ? '<div class="card"><div class="card-head"><div class="title">Descrição</div></div><p class="small muted">' + UI.esc(c.description) + "</p></div>" : "";

    var salesCard = '<div class="card"><div class="card-head"><div class="title">Vendas deste item</div>' +
      '<span class="pill-note">' + salesLines.length + "</span></div>" +
      (salesLines.length ? '<div class="rows">' + salesLines.slice(0, 12).map(function (x) {
        return '<a class="row" href="#/vendas/' + x.s.id + '"><div class="tile">' + UI.icon("receipt", 17) + "</div>" +
          '<div class="body"><div class="name">' + x.s.id + " · " + Store.round2(x.ln.qty) + " un.</div>" +
          '<div class="meta">' + Store.dateShort(x.s.date) + " · " + money(x.ln.price) + "</div></div>" +
          '<div class="end"><div class="amount sm">' + money(Store.num(x.ln.qty) * Store.num(x.ln.price) * (1 - Store.num(x.ln.discount))) + "</div></div></a>";
      }).join("") + "</div>" : '<p class="small muted">Ainda não foi vendido.</p>') + "</div>";

    var actions = '<div class="btn-row" style="margin-top:12px">' +
      (c.active === false ? '<button class="btn ghost" data-act="catalog-toggle" data-id="' + c.id + '">Reativar item</button>'
        : '<button class="btn ghost" data-act="catalog-toggle" data-id="' + c.id + '">Inativar item</button>') +
      '<button class="btn danger" data-act="catalog-delete" data-id="' + c.id + '">' + UI.icon("trash", 16) + "</button></div>";

    return '<div class="view">' + head + hero +
      '<div class="two-col"><div class="col">' + desc + salesCard + "</div><div class=\"col\">" + actions + "</div></div></div>";
  }

  function openCatalogForm(id) {
    var db = Store.db();
    var c = id ? db.catalog.find(function (x) { return x.id === id; }) : null;
    var defaults = c || {
      name: "", typeId: Store.listValues("itemType")[0].id,
      categoryId: "", unitId: "", price: 0, manualCost: 0, vatRate: "",
      stockItemId: "", stockConsumption: 1, description: "", barcode: "", active: true
    };
    var vatOptions = [{ id: "", name: "Usar IVA padrão (" + Store.pct(db.config.vatDefault, 0) + ")" }]
      .concat(Store.listValues("vatRate").map(function (v) { return { id: String(v.meta.rate), name: v.name }; }));
    var fields = [
      { k: "name", label: "Serviço / produto", type: "text", required: true, full: true },
      { k: "typeId", label: "Tipo", type: "select", required: true, blank: false, options: UI.optsFromList("itemType", null) },
      { k: "categoryId", label: "Categoria", type: "select", required: true, options: UI.optsFromList("serviceCategory") },
      { k: "unitId", label: "Unidade de venda", type: "select", required: true, options: UI.optsFromList("unit") },
      { k: "price", label: "Preço sem IVA", type: "money", required: true },
      { k: "manualCost", label: "Custo manual", type: "money", help: "Ignorado quando existe item de stock ligado." },
      { k: "vatRate", label: "IVA próprio", type: "select", options: vatOptions, help: "Vazio usa o IVA padrão da empresa." },
      { k: "stockItemId", label: "Item de stock ligado", type: "select", options: [{ id: "", name: "— Sem ligação ao stock —" }].concat(db.stock.map(function (s) { return { id: s.id, name: s.name }; })) },
      { k: "stockConsumption", label: "Consumo de stock por unidade", type: "number", step: "0.01", help: "Ex.: vender um saco de 5 kg de um item de 25 kg = 0,2." },
      { k: "barcode", label: "Código de barras", type: "text" },
      { k: "description", label: "Descrição", type: "textarea" },
      { k: "active", label: "Item ativo no catálogo", type: "checkbox" },
      { k: "calc", type: "static", html: "" }
    ];
    var ov = UI.form({
      title: c ? "Editar item" : "Novo serviço ou produto",
      subtitle: "O custo efetivo e a margem são recalculados automaticamente.",
      fields: fields,
      values: Object.assign({}, defaults, { vatRate: defaults.vatRate === null || defaults.vatRate === undefined ? "" : String(defaults.vatRate) }),
      submitLabel: c ? "Guardar" : "Criar item",
      onChange: function (v) {
        var cost = v.stockItemId
          ? Store.num((Engine.stockOf(v.stockItemId) || {}).avgCost) * (Store.num(v.stockConsumption) || 1)
          : Store.num(v.manualCost);
        var price = Store.num(v.price);
        var vat = v.vatRate === "" ? Store.num(db.config.vatDefault) : Store.num(v.vatRate);
        var margin = price > 0 ? (price - cost) / price : 0;
        var note = ov.querySelector(".form-note:last-of-type");
        if (note) note.innerHTML = "Custo efetivo <b>" + money(cost) + "</b> · margem <b>" + Store.pct(margin) +
          "</b> · preço c/IVA <b>" + money(price * (1 + vat)) + "</b>";
      },
      validate: function (v) {
        var name = (v.name || "").trim().toLowerCase();
        if (!name) return "Indique o nome do item.";
        var dup = db.catalog.find(function (x) {
          return x.id !== (c && c.id) && (x.name || "").trim().toLowerCase() === name;
        });
        if (dup) return "Já existe um item com esse nome.";
        if (v.barcode) {
          var bdup = db.catalog.find(function (x) { return x.id !== (c && c.id) && x.barcode === v.barcode; });
          if (bdup) return "Este código de barras já está a ser usado por " + bdup.name + ".";
        }
        return null;
      },
      onSubmit: function (v) {
        var data = {
          name: v.name.trim(), typeId: v.typeId, categoryId: v.categoryId, unitId: v.unitId,
          price: Store.round2(Store.num(v.price)), manualCost: Store.round2(Store.num(v.manualCost)),
          vatRate: v.vatRate === "" ? null : Store.num(v.vatRate),
          stockItemId: v.stockItemId || null,
          stockConsumption: Store.num(v.stockConsumption) || 1,
          barcode: v.barcode || "", description: v.description || "",
          active: !!v.active
        };
        if (c) Object.assign(c, data);
        else db.catalog.push(Object.assign({ id: Store.nextId("catalog", "SRV-", 3) }, data));
        Store.save();
        App.onData(c ? "Item atualizado." : "Item criado no catálogo.");
        if (!c) App.go("#/catalogo"); else App.render();
      }
    });
  }

  /* ------------------------------- ações --------------------------- */
  Actions["expense-new"] = function () { openExpenseForm(null); };
  Actions["expense-open"] = function (id) { openExpenseDetail(id); };
  Actions["exp-filter"] = function (id) { App.expFilter.state = id; App.render(); };
  Actions["exp-report"] = function () { openExpenseReport(); };

  Actions["catalog-new"] = function () { openCatalogForm(null); };
  Actions["catalog-edit"] = function (id) { openCatalogForm(id); };
  Actions["catalog-sell"] = function (id) {
    var c = Store.db().catalog.find(function (x) { return x.id === id; });
    if (!c) return;
    openSaleEditor(null, {
      items: [{
        catalogId: c.id, name: c.name, qty: 1, price: Store.num(c.price), discount: 0,
        vatRate: Engine.catalogVat(c), cost: Engine.catalogEffectiveCost(c),
        unitId: c.unitId, typeId: c.typeId
      }]
    });
  };
  Actions["catalog-toggle"] = function (id) {
    var c = Store.db().catalog.find(function (x) { return x.id === id; });
    if (!c) return;
    c.active = c.active === false;
    Store.save(); App.onData(c.active ? "Item reativado." : "Item inativado."); App.render();
  };
  Actions["catalog-delete"] = function (id) {
    var db = Store.db();
    var used = db.sales.some(function (s) { return (s.items || []).some(function (l) { return l.catalogId === id; }); });
    if (used) { UI.toast("Não é possível eliminar: o item já foi vendido. Inative-o.", "err"); return; }
    UI.confirm({ title: "Eliminar item", message: "O item será removido do catálogo.", confirmLabel: "Eliminar", danger: true })
      .then(function (ok) {
        if (!ok) return;
        db.catalog = db.catalog.filter(function (x) { return x.id !== id; });
        Store.save(); App.onData("Item eliminado."); App.go("#/catalogo");
      });
  };
  Actions["cat-type"] = function (id) { App.catFilter.typeId = id; App.render(); };

  document.addEventListener("change", function (e) {
    if (!e.target) return;
    var a = e.target.getAttribute("data-act");
    if (!a) return;
    if (a === "exp-category") { App.expFilter.categoryId = e.target.value; App.render(); }
    if (a === "exp-period") { App.expFilter.period = e.target.value; App.render(); }
    if (a === "cat-category") { App.catFilter.categoryId = e.target.value; App.render(); }
  });

  function row(k, v) { return '<div class="it"><span class="k">' + k + '</span><span class="v">' + v + "</span></div>"; }

  window.Views.expenses = expenses;
  window.Views.catalog = catalog;
  window.Views.catalogDetail = catalogDetail;
  window.openExpenseForm = openExpenseForm;
  window.openCatalogForm = openCatalogForm;
})();
