/* ============================================================
   SEED — dados de demonstração derivados da planilha original
   ============================================================ */
(function () {
  "use strict";

  function buildSeed() {
    /* ---------- Listas editáveis (alimentam todos os menus) ---------- */
    var L = [];
    function add(key, name, meta) {
      var id = "L-" + key + "-" + (L.filter(function (x) { return x.key === key; }).length + 1);
      L.push({ id: id, key: key, name: name, order: L.length, meta: meta || null });
      return id;
    }
    function list(key, names) { names.forEach(function (n) { add(key, n); }); }

    list("serviceCategory", ["Consultoria", "Design", "Desenvolvimento", "Marketing", "Formação", "Manutenção", "Suporte técnico", "Venda de produtos", "Outros"]);
    list("itemType", ["Serviço", "Produto", "Subscrição"]);
    list("unit", ["Unidade", "Hora", "Dia", "Mês", "Projeto", "Pacote", "Caixa", "Kg", "Litro", "Metro"]);
    [["23%", 0.23], ["16%", 0.16], ["13%", 0.13], ["6%", 0.06], ["5%", 0.05], ["0%", 0]].forEach(function (v) {
      add("vatRate", v[0], { rate: v[1] });
    });
    list("paymentMethod", ["Numerário", "M-Pesa", "e-Mola", "mKesh", "Transferência bancária", "POS / Cartão", "Cheque", "Depósito bancário", "Multibanco", "MB WAY", "PayPal"]);
    list("expenseCategory", ["Renda", "Água / Luz / Internet", "Marketing e publicidade", "Software e subscrições", "Material de escritório", "Deslocações", "Impostos e taxas", "Serviços externos", "Formação", "Seguros", "Equipamento", "Outros"]);
    list("department", ["Direção", "Comercial", "Operações", "Financeiro", "Marketing", "Suporte", "Produção"]);
    list("clientOrigin", ["Recomendação", "Website", "Redes sociais", "Anúncios", "Contacto direto", "Parceria", "Evento"]);
    list("clientType", ["Particular", "Empresa", "Entidade pública", "Associação"]);
    list("clientState", ["Ativo", "Potencial", "Inativo"]);
    list("priority", ["Baixa", "Média", "Alta", "Urgente"]);
    list("stockCategory", ["Matéria-prima", "Produto acabado", "Consumíveis", "Equipamento", "Embalagens"]);
    list("currency", ["€", "$", "R$", "£", "Kz", "MT", "CHF"]);
    list("role", ["Gerente", "Técnico", "Comercial", "Administrativo", "Designer", "Programador", "Assistente"]);
    list("taskState", ["A fazer", "Em curso", "Concluída"]);
    list("saleState", ["Pendente", "Paga", "Cancelada"]);
    add("movementType", "Ajuste de inventário (+)", { effect: 1 });
    add("movementType", "Devolução de cliente", { effect: 1 });
    add("movementType", "Inventário inicial", { effect: 1 });
    add("movementType", "Ajuste de inventário (−)", { effect: -1 });
    add("movementType", "Perda / quebra / validade", { effect: -1 });
    add("movementType", "Consumo interno", { effect: -1 });
    add("movementType", "Devolução a fornecedor", { effect: -1 });

    var byName = {};
    L.forEach(function (it) { byName[it.key + "|" + it.name] = it.id; });
    function lid(key, name) { return byName[key + "|" + name] || null; }

    /* ---------- Configuração ---------- */
    var config = {
      company: "Minha Empresa, Lda.",
      slogan: "Gestão simples, resultados claros",
      nif: "500 000 000",
      sector: "Serviços e consultoria",
      address: "Rua Exemplo, 123",
      city: "Lisboa",
      country: "Portugal",
      email: "geral@minhaempresa.pt",
      phone: "210 000 000",
      website: "www.minhaempresa.pt",
      currency: "€",
      vatDefault: 0.23,
      paymentTerm: 30,
      refYear: 2026,
      monthlyTarget: 5000,
      payrollPct: 0.2375,
      alertDays: 3,
      creditAuthorization: true,
      theme: "Lime",
      modules: { clients: true, catalog: true, sales: true, expenses: true, employees: true, stock: true, tasks: true, purchases: true, suppliers: true, movements: true, pos: true }
    };

    /* ---------- Fornecedores ---------- */
    var suppliers = [
      ["Imobiliária Central", "500100001", "Sofia Matos", "geral@imobiliaria.exemplo", "210 100 001", "Lisboa", "Ativo"],
      ["Fornecedor de software", "500100002", "Rui Alves", "vendas@software.exemplo", "210 100 002", "Porto", "Ativo"],
      ["Plataforma de anúncios", "500100003", "Apoio comercial", "ads@plataforma.exemplo", "210 100 003", "Lisboa", "Ativo"],
      ["Seguradora Exemplo", "500100004", "Ana Lopes", "apolices@seguradora.exemplo", "210 100 004", "Lisboa", "Ativo"],
      ["Papelaria Central", "500100005", "Carlos Dias", "encomendas@papelaria.exemplo", "210 100 005", "Amadora", "Ativo"],
      ["Portagens", "500100006", "—", "apoio@portagens.exemplo", "210 100 006", "Lisboa", "Ativo"],
      ["Contabilista Exemplo", "500100007", "Teresa Nunes", "teresа@contabilista.exemplo", "210 100 007", "Lisboa", "Ativo"],
      ["Fornecedor Exemplo", "500100008", "Pedro Sousa", "compras@fornecedor.exemplo", "210 100 008", "Sintra", "Ativo"],
      ["Gráfica Exemplo", "500100009", "Hugo Martins", "producao@grafica.exemplo", "210 100 009", "Loures", "Ativo"],
      ["Loja de Informática", "500100010", "Bruno Costa", "loja@informatica.exemplo", "210 100 010", "Lisboa", "Ativo"],
      ["Embalagens Exemplo", "500100011", "Marta Reis", "vendas@embalagens.exemplo", "210 100 011", "Setúbal", "Ativo"],
      ["Distribuidora Central", "500100012", "Joana Pires", "geral@distribuidora.exemplo", "210 100 012", "Lisboa", "Ativo"]
    ].map(function (s, i) {
      return {
        id: "FOR-" + String(i + 1).padStart(3, "0"),
        name: s[0], nuit: s[1], contact: s[2], email: s[3], phone: s[4],
        city: s[5], state: s[6], notes: ""
      };
    });
    var sup = {};
    suppliers.forEach(function (s) { sup[s.name] = s.id; });

    /* ---------- Clientes ---------- */
    var clients = [
      ["Padaria Dourada, Lda.", "Empresa", "500000011", "geral@padariadourada.exemplo", "912 000 001", "Lisboa", "Recomendação", "Ativo", "2026-01-10", "Cliente de referência na área alimentar."],
      ["Clínica Vida Nova", "Empresa", "500000022", "info@vidanova.exemplo", "912 000 002", "Porto", "Website", "Ativo", "2026-01-25", "Contrato de manutenção mensal ativo."],
      ["Ana Rodrigues", "Particular", "200000033", "ana.rodrigues@exemplo.pt", "912 000 003", "Braga", "Redes sociais", "Ativo", "2026-02-14", "Prefere contacto por WhatsApp."],
      ["TechNova Soluções", "Empresa", "500000044", "contacto@technova.exemplo", "912 000 004", "Coimbra", "Parceria", "Ativo", "2026-02-28", "Parceiro tecnológico. Faturação elevada."],
      ["Associação Mar Azul", "Associação", "500000055", "secretaria@marazul.exemplo", "912 000 005", "Faro", "Evento", "Potencial", "2026-03-09", "Tem fatura em atraso — acompanhar cobrança."],
      ["Restaurante O Cais", "Empresa", "500000066", "reservas@ocais.exemplo", "912 000 006", "Aveiro", "Anúncios", "Ativo", "2026-03-30", ""]
    ].map(function (c, i) {
      return {
        id: "CLI-" + String(i + 1).padStart(4, "0"),
        name: c[0], typeId: lid("clientType", c[1]), nuit: c[2], email: c[3], phone: c[4],
        city: c[5], originId: lid("clientOrigin", c[6]), state: c[7],
        registeredAt: c[8], notes: c[9]
      };
    });
    var cli = {};
    clients.forEach(function (c) { cli[c.name] = c.id; });

    /* ---------- Funcionários ---------- */
    var employees = [
      ["Marta Silva", "Gerente", "Direção", "2023-02-01", 1500, "marta.silva@minhaempresa.pt", "913 000 001", "Ativo", "1234", "admin", ""],
      ["João Pereira", "Programador", "Operações", "2024-05-06", 1300, "joao.pereira@minhaempresa.pt", "913 000 002", "Ativo", "2345", "operator", ""],
      ["Inês Costa", "Designer", "Marketing", "2025-09-15", 1000, "ines.costa@minhaempresa.pt", "913 000 003", "Férias", "3456", "operator", "Regressa de férias no fim do mês."]
    ].map(function (e, i) {
      return {
        id: "FUN-" + String(i + 1).padStart(3, "0"),
        name: e[0], roleId: lid("role", e[1]), departmentId: lid("department", e[2]),
        hireDate: e[3], exitDate: "", baseSalary: e[4],
        chargesPct: null, chargesDefault: true,
        email: e[5], phone: e[6], state: e[7],
        pin: e[8], permission: e[9], notes: e[10],
        salaryHistory: []
      };
    });
    var emp = {};
    employees.forEach(function (e) { emp[e.name] = e.id; });

    /* ---------- Stock ---------- */
    var stock = [
      ["Papel A4 (resma)", "Consumíveis", "Pacote", 20, 3.5, 10, sup["Papelaria Central"], "Resma de 500 folhas."],
      ["Toner impressora", "Consumíveis", "Unidade", 4, 45, 2, sup["Fornecedor Exemplo"], ""],
      ["Brochuras impressas", "Produto acabado", "Pacote", 30, 90, 10, sup["Gráfica Exemplo"], "Pack de 50 brochuras."],
      ["Portátil de reserva", "Equipamento", "Unidade", 3, 650, 1, sup["Loja de Informática"], ""],
      ["Caixas de envio", "Embalagens", "Unidade", 50, 0.8, 20, sup["Embalagens Exemplo"], ""]
    ].map(function (s, i) {
      return {
        id: "STK-" + String(i + 1).padStart(4, "0"),
        name: s[0], categoryId: lid("stockCategory", s[1]), unitId: lid("unit", s[2]),
        qtyInitial: s[3], costInitial: s[4], minStock: s[5],
        supplierId: s[6], salePrice: null, notes: s[7], barcode: ""
      };
    });
    var stk = {};
    stock.forEach(function (s) { stk[s.name] = s.id; });

    /* ---------- Compras (reproduzem as entradas da planilha) ---------- */
    var purchases = [
      { id: "CP-0001", date: "2026-09-18", supplierId: sup["Papelaria Central"], state: "Paga", method: lid("paymentMethod", "Transferência bancária"), dueDate: "2026-10-18", notes: "Reposição de papel.", responsibleId: emp["Marta Silva"], items: [{ stockItemId: stk["Papel A4 (resma)"], qty: 10, unitCost: 3.5, vatRate: 0.23 }] }
    ].map(function (p) {
      var net = p.items.reduce(function (a, it) { return a + it.qty * it.unitCost; }, 0);
      var vat = p.items.reduce(function (a, it) { return a + it.qty * it.unitCost * it.vatRate; }, 0);
      p.net = net; p.vat = vat; p.total = net + vat;
      return p;
    });

    /* ---------- Movimentos de stock (saídas e ajustes da planilha) ---------- */
    var moves = [
      ["2026-09-15", "Brochuras impressas", "Consumo interno", 12, emp["Inês Costa"], "Material usado em campanha."],
      ["2026-08-02", "Portátil de reserva", "Devolução a fornecedor", 1, emp["João Pereira"], "Equipamento devolvido."],
      ["2026-10-20", "Papel A4 (resma)", "Consumo interno", 8, emp["João Pereira"], "Impressões internas."],
      ["2026-10-28", "Toner impressora", "Perda / quebra / validade", 5, emp["Marta Silva"], "Tinteiros danificados."],
      ["2026-11-01", "Caixas de envio", "Consumo interno", 50, emp["Marta Silva"], "Expedição do trimestre."]
    ].map(function (m, i) {
      return {
        id: "MV-" + String(i + 1).padStart(4, "0"),
        date: m[0], stockItemId: stk[m[1]], typeId: lid("movementType", m[2]),
        qty: m[3], responsibleId: m[4], notes: m[5]
      };
    });

    /* ---------- Catálogo ---------- */
    var catalog = [
      ["Consultoria de gestão", "Serviço", "Consultoria", "Hora", 60, 20, null, "Apoio estratégico e acompanhamento de gestão."],
      ["Website institucional", "Serviço", "Desenvolvimento", "Projeto", 1200, 450, null, "Website responsivo com CMS."],
      ["Gestão de redes sociais", "Subscrição", "Marketing", "Mês", 350, 120, null, "Gestão mensal de conteúdos e publicações."],
      ["Formação em Excel", "Serviço", "Formação", "Dia", 400, 150, 0, "Formação prática em Excel, isenta de IVA."],
      ["Manutenção mensal", "Subscrição", "Manutenção", "Mês", 90, 25, null, "Manutenção preventiva mensal."],
      ["Pack de brochuras", "Produto", "Marketing", "Pacote", 180, 90, null, "Pack de 50 brochuras impressas."],
      ["Design de logótipo", "Serviço", "Design", "Projeto", 250, 80, null, "Identidade visual e manual de marca."],
      ["Resma de papel A4", "Produto", "Venda de produtos", "Pacote", 5.5, 0, null, "Ligado ao stock — consome 1 resma por unidade.", stk["Papel A4 (resma)"], 1],
      ["Toner para impressora", "Produto", "Venda de produtos", "Unidade", 65, 0, null, "Ligado ao stock — consome 1 tóner por unidade.", stk["Toner impressora"], 1]
    ].map(function (s, i) {
      return {
        id: "SRV-" + String(i + 1).padStart(3, "0"),
        name: s[0], typeId: lid("itemType", s[1]), categoryId: lid("serviceCategory", s[2]),
        unitId: lid("unit", s[3]), price: s[4], manualCost: s[5],
        vatRate: s[6], stockItemId: s[8] || null, stockConsumption: s[9] || 1,
        description: s[7] || "",
        active: true, barcode: ""
      };
    });
    var cat = {};
    catalog.forEach(function (c) { cat[c.name] = c.id; });

    /* ---------- Vendas (as 20 linhas da planilha) ---------- */
    var rawSales = [
      ["2026-01-15", "Padaria Dourada, Lda.", "Website institucional", 5, 1200, 0, 0.23, "Transferência bancária", "Paga", "2026-01-30"],
      ["2026-02-10", "Clínica Vida Nova", "Consultoria de gestão", 50, 60, 0, 0.23, "Multibanco", "Paga", "2026-02-25"],
      ["2026-02-20", "Ana Rodrigues", "Design de logótipo", 5, 250, 0.1, 0.23, "MB WAY", "Paga", "2026-03-01"],
      ["2026-03-05", "TechNova Soluções", "Gestão de redes sociais", 15, 350, 0, 0.23, "Transferência bancária", "Paga", "2026-03-20"],
      ["2026-03-18", "Associação Mar Azul", "Formação em Excel", 10, 400, 0, 0, "Transferência bancária", "Paga", "2026-04-05"],
      ["2026-04-08", "Restaurante O Cais", "Pack de brochuras", 20, 180, 0.05, 0.23, "POS / Cartão", "Paga", "2026-04-08"],
      ["2026-04-22", "Padaria Dourada, Lda.", "Manutenção mensal", 30, 90, 0, 0.23, "Transferência bancária", "Paga", "2026-05-05"],
      ["2026-05-12", "TechNova Soluções", "Website institucional", 5, 1200, 0, 0.23, "Transferência bancária", "Paga", "2026-06-01"],
      ["2026-05-27", "Clínica Vida Nova", "Gestão de redes sociais", 10, 350, 0, 0.23, "Multibanco", "Paga", "2026-06-10"],
      ["2026-06-09", "Ana Rodrigues", "Consultoria de gestão", 25, 60, 0, 0.23, "MB WAY", "Paga", "2026-06-20"],
      ["2026-06-24", "Associação Mar Azul", "Design de logótipo", 5, 250, 0, 0.23, "Transferência bancária", "Paga", "2026-07-08"],
      ["2026-07-07", "Restaurante O Cais", "Formação em Excel", 5, 400, 0, 0, "POS / Cartão", "Paga", "2026-07-07"],
      ["2026-07-21", "Padaria Dourada, Lda.", "Gestão de redes sociais", 20, 350, 0.1, 0.23, "Transferência bancária", "Paga", "2026-08-05"],
      ["2026-08-11", "TechNova Soluções", "Consultoria de gestão", 40, 60, 0, 0.23, "Transferência bancária", "Paga", "2026-08-30"],
      ["2026-09-03", "Clínica Vida Nova", "Website institucional", 5, 1200, 0.05, 0.23, "Multibanco", "Paga", "2026-09-25"],
      ["2026-09-20", "Associação Mar Azul", "Pack de brochuras", 30, 180, 0, 0.23, "Transferência bancária", "Pendente", null],
      ["2026-10-06", "Ana Rodrigues", "Gestão de redes sociais", 10, 350, 0, 0.23, "MB WAY", "Pendente", null],
      ["2026-10-19", "Restaurante O Cais", "Manutenção mensal", 15, 90, 0, 0.23, "POS / Cartão", "Paga", "2026-10-19"],
      ["2026-11-03", "TechNova Soluções", "Formação em Excel", 10, 400, 0, 0, "Transferência bancária", "Pendente", null],
      ["2026-11-09", "Padaria Dourada, Lda.", "Design de logótipo", 5, 250, 0, 0.23, "Transferência bancária", "Cancelada", null]
    ];
    var sellers = [emp["Marta Silva"], emp["João Pereira"], emp["Inês Costa"]];
    var sales = [];
    var payments = [];
    rawSales.forEach(function (s, i) {
      var item = catalog.find(function (c) { return c.name === s[2]; });
      var net = s[3] * s[4] * (1 - s[5]);
      var vat = net * s[6];
      var line = {
        catalogId: item.id, name: item.name,
        qty: s[3], price: s[4], discount: s[5], vatRate: s[6],
        cost: item.manualCost, unitId: item.unitId, typeId: item.typeId
      };
      var sale = {
        id: "VD-" + String(i + 1).padStart(4, "0"),
        date: s[0], clientId: cli[s[1]], sellerId: sellers[i % 3],
        items: [line], state: s[8],
        dueDate: s[10] || (function () {
          var d = new Date(s[0] + "T00:00:00"); d.setDate(d.getDate() + 30);
          return d.toISOString().slice(0, 10);
        })(),
        paymentMethod: lid("paymentMethod", s[7]),
        notes: "", priceList: "Tabela padrão"
      };
      sales.push(sale);
      if (s[8] === "Paga") {
        payments.push({
          id: "PG-" + String(payments.length + 1).padStart(4, "0"),
          saleId: sale.id, date: s[9] || s[0],
          amount: Math.round((net + vat) * 100) / 100,
          method: sale.paymentMethod, notes: "Liquidação total"
        });
      }
    });

    /* ---------- Despesas ---------- */
    var rawExp = [
      ["2026-01-01", "Renda do escritório", "Renda", "Imobiliária Central", 600, 0, "Transferência bancária", "Paga", "Sim"],
      ["2026-02-01", "Renda do escritório", "Renda", "Imobiliária Central", 600, 0, "Transferência bancária", "Paga", "Sim"],
      ["2026-03-01", "Renda do escritório", "Renda", "Imobiliária Central", 600, 0, "Transferência bancária", "Paga", "Sim"],
      ["2026-04-01", "Renda do escritório", "Renda", "Imobiliária Central", 600, 0, "Transferência bancária", "Paga", "Sim"],
      ["2026-05-01", "Renda do escritório", "Renda", "Imobiliária Central", 600, 0, "Transferência bancária", "Paga", "Sim"],
      ["2026-06-01", "Renda do escritório", "Renda", "Imobiliária Central", 600, 0, "Transferência bancária", "Paga", "Sim"],
      ["2026-07-01", "Renda do escritório", "Renda", "Imobiliária Central", 600, 0, "Transferência bancária", "Paga", "Sim"],
      ["2026-08-01", "Renda do escritório", "Renda", "Imobiliária Central", 600, 0, "Transferência bancária", "Paga", "Sim"],
      ["2026-09-01", "Renda do escritório", "Renda", "Imobiliária Central", 600, 0, "Transferência bancária", "Paga", "Sim"],
      ["2026-10-01", "Renda do escritório", "Renda", "Imobiliária Central", 600, 0, "Transferência bancária", "Paga", "Sim"],
      ["2026-11-01", "Renda do escritório", "Renda", "Imobiliária Central", 600, 0, "Transferência bancária", "Paga", "Sim"],
      ["2026-01-20", "Licença de software de faturação", "Software e subscrições", "Fornecedor de software", 240, 0.23, "POS / Cartão", "Paga", "Não"],
      ["2026-03-12", "Campanha de anúncios", "Marketing e publicidade", "Plataforma de anúncios", 300, 0.23, "POS / Cartão", "Paga", "Não"],
      ["2026-04-15", "Seguro multirriscos", "Seguros", "Seguradora Exemplo", 420, 0, "Transferência bancária", "Paga", "Não"],
      ["2026-06-02", "Material de escritório", "Material de escritório", "Papelaria Central", 85, 0.23, "POS / Cartão", "Paga", "Não"],
      ["2026-08-14", "Deslocação a cliente", "Deslocações", "Portagens", 38, 0.23, "POS / Cartão", "Paga", "Não"],
      ["2026-10-30", "Serviços de contabilidade", "Serviços externos", "Contabilista Exemplo", 250, 0.23, "Transferência bancária", "Pendente", "Sim"]
    ];
    var expenses = rawExp.map(function (e, i) {
      var vat = e[4] * e[5];
      return {
        id: "DP-" + String(i + 1).padStart(4, "0"),
        date: e[0], description: e[1], categoryId: lid("expenseCategory", e[2]),
        supplierId: sup[e[3]] || null, amountNet: e[4], vatRate: e[5],
        vat: Math.round(vat * 100) / 100, total: Math.round((e[4] + vat) * 100) / 100,
        method: lid("paymentMethod", e[6]), state: e[7],
        recurring: e[8] === "Sim", notes: ""
      };
    });

    /* ---------- Tarefas ---------- */
    var tasks = [
      ["Entregar proposta de website", "Marta Silva", "TechNova Soluções", "Alta", "Em curso", "2026-11-02", "2026-11-14", "Rever âmbito e orçamento antes do envio."],
      ["Reunião de acompanhamento mensal", "Marta Silva", "Padaria Dourada, Lda.", "Média", "A fazer", "2026-11-10", "2026-11-20", ""],
      ["Criar calendário de publicações", "Inês Costa", "Ana Rodrigues", "Média", "Em curso", "2026-11-03", "2026-11-13", "Aprovar temas com a cliente."],
      ["Cobrar fatura em atraso", "Marta Silva", "Associação Mar Azul", "Urgente", "A fazer", "2026-11-05", "2026-11-09", "Contactar secretaria por telefone."],
      ["Atualizar plugin do site", "João Pereira", "Clínica Vida Nova", "Baixa", "Concluída", "2026-10-20", "2026-10-30", ""],
      ["Preparar formação em Excel", "João Pereira", "TechNova Soluções", "Alta", "A fazer", "2026-11-12", "2026-11-25", "Preparar exercícios práticos."]
    ].map(function (t, i) {
      return {
        id: "TRF-" + String(i + 1).padStart(4, "0"),
        title: t[0], employeeId: emp[t[1]], clientId: cli[t[2]] || null,
        priority: lid("priority", t[3]), state: t[4],
        startDate: t[5], dueDate: t[6], notes: t[7]
      };
    });

    /* ---------- Carrinhos guardados ---------- */
    var carts = [{
      id: "CART-0001", name: "Orçamento — Clínica Vida Nova", createdAt: "2026-11-12",
      clientId: cli["Clínica Vida Nova"],
      items: [{ catalogId: cat["Gestão de redes sociais"], qty: 3, price: 350, discount: 0, vatRate: 0.23 }]
    }];

    return {
      version: 1,
      createdAt: new Date().toISOString(),
      config: config,
      lists: L,
      clients: clients,
      suppliers: suppliers,
      catalog: catalog,
      stock: stock,
      purchases: purchases,
      movements: moves,
      sales: sales,
      payments: payments,
      expenses: expenses,
      employees: employees,
      tasks: tasks,
      carts: carts,
      counters: {
        client: clients.length, supplier: suppliers.length, catalog: catalog.length,
        stock: stock.length, purchase: purchases.length, movement: moves.length,
        sale: sales.length, payment: payments.length, expense: expenses.length,
        employee: employees.length, task: tasks.length, cart: carts.length
      }
    };
  }

  window.SEED = { build: buildSeed };
})();
