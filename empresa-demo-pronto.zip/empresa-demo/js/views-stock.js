/* ============================================================
   VIEWS — Stock, compras, movimentos e fornecedores
   ============================================================ */
(function () {
  "use strict";

  var money = Store.money;

  function stockItemName(id) { return Store.listName("unit", id, ""); }
  function supplierName(id) {
    var s = Store.db().suppliers.find(function (x) { return x.id === id; });
    return s ? s.name : "—";
  }
  function stockName(id) {
    var s = Store.db().stock.find(function (x) { return x.id === id; });
    return s ? s.name : "—";
  }

  /* ------------------------------------------------------------------
     STOCK — LISTA
  ------------------------------------------------------------------ */
  function stock() {
    var db = Store.db();
    var f = App.stockFilter || (App.stockFilter = { q: "", situation: "Todos", categoryId: "" });
    var stats = Engine.stockStats();
    var list = db.stock.slice();
    if (f.q) {
      var q = f.q.toLowerCase();
      list = list.filter(function (i) { return i.name.toLowerCase().indexOf(q) >= 0 || (i.barcode || "").indexOf(q) >= 0; });
    }
    if (f.situation !== "Todos") {
      list = list.filter(function (i) {
        var st = stats[i.id];
        if (!st) return false;
        if (f.situation === "Repor") return st.situation !== "OK";
        return st.situation === f.situation;
      });
    }
    if (f.categoryId) list = list.filter(function (i) { return i.categoryId === f.categoryId; });

    var totalValue = 0, totalItems = 0, restock = 0, zero = 0;
    db.stock.forEach(function (i) {
      var st = stats[i.id]; if (!st) return;
      totalValue += st.value; totalItems += Math.max(0, st.qty);
      if (st.situation !== "OK") restock++;
      if (st.situation === "SEM STOCK") zero++;
    });

    var head = V.head("Stock", list.length + " itens · " + money(totalValue) + " em inventário",
      '<button class="btn ghost" data-act="stock-new">' + UI.icon("plus", 16) + " Item</button>" +
      '<button class="btn primary" data-act="purchase-new">' + UI.icon("download", 16) + " Compra</button>");

    var donutRows = db.stock.map(function (i) {
      return { name: i.name, value: stats[i.id] ? stats[i.id].value : 0 };
    }).filter(function (x) { return x.value > 0; }).sort(function (a, b) { return b.value - a.value; });
    var palette = ["#b9fc01", "#6b8cff", "#f5a94a", "#4ade80", "#ff7a7a", "#a78bfa"];
    var top = donutRows.slice(0, 5);
    var otherVal = donutRows.slice(5).reduce(function (a, x) { return a + x.value; }, 0);
    var donutItems = top.map(function (x, i) { return { name: x.name, value: x.value, color: palette[i % palette.length] }; });
    if (otherVal > 0) donutItems.push({ name: "Outros", value: otherVal, color: "#606f9c" });

    var summary = '<div class="card"><div class="card-head"><div class="title">Valor do inventário</div>' +
      '<span class="pill-note">' + money(totalValue) + "</span></div>" +
      (donutItems.length ? '<div class="donut-wrap">' + UI.donut(donutItems, totalValue, "em stock", Store.money0(totalValue)) +
        '<div class="chart-legend" style="flex:1">' + donutItems.map(function (x) {
          return '<div class="li"><i style="background:' + x.color + '"></i><span class="nm" style="flex:1">' + UI.esc(x.name) + '</span>' +
            '<span class="vl">' + (totalValue ? Math.round(x.value / totalValue * 100) : 0) + "%</span></div>";
        }).join("") + "</div></div>" : UI.emptyState("package", "Sem stock valorizado.")) +
      '</div><div class="grid cols-3" style="margin-top:10px">' +
      V.kpi("Unidades", String(Store.round2(totalItems))) +
      V.kpi("A repor", String(restock), restock ? "accent-orange" : "") +
      V.kpi("Sem stock", String(zero), zero ? "accent-red" : "") + "</div>";

    var filters = '<div class="tabs">' + ["Todos", "Repor", "SEM STOCK", "OK"].map(function (s) {
      return '<button data-act="stock-filter" data-id="' + s + '" aria-pressed="' + (f.situation === s) + '">' +
        (s === "SEM STOCK" ? "Sem stock" : s) + "</button>";
    }).join("") + "</div>" +
      '<div class="search" style="margin-bottom:12px">' + UI.icon("search", 18) +
      '<input placeholder="Pesquisar item ou código de barras" data-act="stock-search" value="' + UI.esc(f.q) + '"></div>';

    var cards = list.length ? list.map(function (i) {
      var st = stats[i.id] || { qty: 0, avgCost: 0, value: 0, situation: "SEM STOCK", suggested: 0, minStock: 0 };
      var pct = i.minStock > 0 ? Math.max(0, Math.min(100, (st.qty / (i.minStock * 2)) * 100)) : (st.qty > 0 ? 100 : 0);
      var cls = st.situation === "OK" ? "" : st.situation === "REPOR" ? "orange" : "red";
      return '<a class="card" href="#/stock/' + i.id + '" style="display:block;padding:15px">' +
        '<div class="hstack" style="justify-content:space-between;align-items:flex-start">' +
        '<div class="hstack" style="gap:11px;align-items:center;min-width:0">' +
        '<div class="tile" style="width:40px;height:40px;border-radius:13px;background:var(--surface);display:grid;place-items:center;color:var(--lime)">' + UI.icon("package", 18) + "</div>" +
        "<div style=\"min-width:0\"><div class=\"name\" style=\"font-size:14px;font-weight:650\">" + UI.esc(i.name) + "</div>" +
        '<div class="tiny muted">' + UI.esc(Store.listName("stockCategory", i.categoryId, "—")) + " · " + UI.esc(stockItemName(i.unitId)) + "</div></div></div>" +
        '<div style="text-align:right"><div style="font-size:20px;font-weight:750;letter-spacing:-.02em" class="mono">' + Store.round2(st.qty) + "</div>" +
        '<div class="tiny muted">' + money(st.value) + "</div></div></div>" +
        '<div style="margin-top:11px">' + '<div class="bar ' + cls + '"><i style="width:' + pct.toFixed(1) + '%"></i></div></div>' +
        '<div class="hstack" style="justify-content:space-between;margin-top:9px">' +
        '<span class="tiny muted">custo médio ' + money(st.avgCost) + " · mín. " + i.minStock + "</span>" +
        V.stockStatus(st) + (st.situation !== "OK" ? '<span class="chip lime">+' + st.suggested + "</span>" : "") +
        "</div></a>";
    }).join("") : UI.emptyState("package", f.q ? "Nenhum item encontrado." : "Sem itens de stock neste filtro.",
      '<button class="btn primary" data-act="stock-new">Criar item</button>');

    App.afterRender = function () {
      var inp = document.querySelector('[data-act="stock-search"]');
      if (inp) inp.addEventListener("input", UI.debounce(function () {
        f.q = inp.value; App.render();
        var a = document.querySelector('[data-act="stock-search"]');
        if (a) { a.focus(); a.setSelectionRange(a.value.length, a.value.length); }
      }, 240));
    };

    return '<div class="view">' + head + summary + filters + '<div class="vstack">' + cards + "</div></div>";
  }

  /* ------------------------------------------------------------------
     STOCK — DETALHE
  ------------------------------------------------------------------ */
  function stockDetail(id) {
    var db = Store.db();
    var item = db.stock.find(function (x) { return x.id === id; });
    if (!item) return Views.notFound();
    var st = Engine.stockOf(id) || {};
    var purchases = [];
    db.purchases.forEach(function (p) {
      (p.items || []).forEach(function (ln) {
        if (ln.stockItemId === id) purchases.push({ p: p, ln: ln });
      });
    });
    purchases.sort(function (a, b) { return a.p.date < b.p.date ? 1 : -1; });
    var moves = db.movements.filter(function (m) { return m.stockItemId === id; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    var linked = db.catalog.filter(function (c) { return c.stockItemId === id; });
    var salesLines = [];
    db.sales.forEach(function (s) {
      if (s.state === "Cancelada") return;
      (s.items || []).forEach(function (ln) {
        var ci = db.catalog.find(function (c) { return c.id === ln.catalogId; });
        if (ci && ci.stockItemId === id) salesLines.push({ s: s, ln: ln, ci: ci });
      });
    });
    salesLines.sort(function (a, b) { return a.s.date < b.s.date ? 1 : -1; });

    var head = '<div class="page-head"><div class="titles">' +
      '<button class="pill-note" data-nav="#/stock" style="margin-bottom:8px">' + UI.icon("chevron-left", 14) + " Stock</button>" +
      '<div class="h1">' + UI.esc(item.name) + '</div><div class="sub">' + item.id + " · " + UI.esc(Store.listName("stockCategory", item.categoryId, "—")) + "</div></div>" +
      '<div class="btn-row"><button class="btn ghost" data-act="stock-edit" data-id="' + item.id + '">' + UI.icon("edit", 16) + " Editar</button>" +
      '<button class="btn ghost" data-act="stock-delete" data-id="' + item.id + '" aria-label="Eliminar">' + UI.icon("trash", 16) + "</button>" +
      '<button class="btn primary" data-act="movement-new" data-id="' + item.id + '">' + UI.icon("layers", 16) + " Movimento</button></div></div>";

    var pct = item.minStock > 0 ? Math.min(100, (st.qty / (item.minStock * 2)) * 100) : (st.qty > 0 ? 100 : 0);
    var cls = st.situation === "REPOR" ? "orange" : st.situation === "SEM STOCK" ? "red" : "";

    var hero = '<div class="detail-hero"><div class="top">' +
      "<div><div class=\"eyebrow\">Quantidade atual</div><div class=\"amt\">" + Store.round2(st.qty) + " " + UI.esc(stockItemName(item.unitId)) + "</div>" +
      '<div class="hstack" style="margin-top:9px">' + V.stockStatus(st) +
      (st.situation !== "OK" ? '<span class="chip">sugerido encomendar ' + st.suggested + "</span>" : "") + "</div></div>" +
      '<div class="right"><div class="eyebrow">Valor em stock</div><div class="amt" style="font-size:22px">' + money(st.value) + "</div>" +
      '<div class="tiny muted">custo médio ' + money(st.avgCost) + "</div></div></div>" +
      '<div style="margin-top:16px"><div class="bar ' + cls + '"><i style="width:' + pct.toFixed(1) + '%"></i></div>' +
      '<div class="hstack" style="justify-content:space-between;margin-top:7px"><span class="tiny muted">0</span>' +
      '<span class="tiny muted">mínimo ' + item.minStock + " · ideal " + (item.minStock * 2) + "</span></div></div></div>";

    var detail = '<div class="card"><div class="card-head"><div class="title">Ficha do item</div></div><div class="kv">' +
      row("Código", item.id) +
      row("Categoria", UI.esc(Store.listName("stockCategory", item.categoryId, "—"))) +
      row("Unidade", UI.esc(stockItemName(item.unitId))) +
      row("Quantidade inicial", Store.round2(item.qtyInitial) + " × " + money(item.costInitial)) +
      row("Entradas por compras", Store.round2(st.purchasedQty) + " · " + money(st.purchasedValue)) +
      row("Entradas por ajustes", Store.round2(st.movesIn)) +
      row("Saídas por vendas", Store.round2(st.salesOut)) +
      row("Saídas por movimentos", Store.round2(st.movesOut)) +
      row("Stock mínimo", String(item.minStock)) +
      row("Fornecedor habitual", UI.esc(supplierName(item.supplierId))) +
      (item.salePrice ? row("Preço de venda s/IVA", money(item.salePrice)) : "") +
      (item.barcode ? row("Código de barras", UI.esc(item.barcode)) : "") +
      "</div>" +
      (item.notes ? '<div class="divider"></div><p class="small muted">' + UI.esc(item.notes) + "</p>" : "") + "</div>";

    var linkedCard = '<div class="card"><div class="card-head"><div class="title">Produtos ligados</div>' +
      '<span class="pill-note">' + linked.length + "</span></div>" +
      (linked.length ? '<div class="rows">' + linked.map(function (c) {
        var info = Engine.catalogInfo(c);
        return '<a class="row" href="#/catalogo/' + c.id + '"><div class="tile">' + UI.icon("tag", 17) + "</div>" +
          '<div class="body"><div class="name">' + UI.esc(c.name) + '</div><div class="meta">consome ' + info.stockConsumption +
          " por unidade · preço " + money(c.price) + "</div></div>" +
          '<div class="end"><div class="amount sm">' + money(info.effectiveCost) + '</div><div class="tiny muted">custo</div></div></a>';
      }).join("") + "</div>" : '<p class="small muted">Nenhum produto do catálogo está ligado a este item. Ligue um produto para que as vendas movimentem o stock automaticamente.</p>') + "</div>";

    var purchCard = '<div class="card"><div class="card-head"><div class="title">Histórico de compras</div>' +
      '<button class="btn sm soft" data-act="purchase-new" data-id="' + item.id + '">+ Compra</button></div>' +
      (purchases.length ? '<div class="rows">' + purchases.map(function (x) {
        return '<a class="row" href="#/compras/' + x.p.id + '"><div class="tile blue">' + UI.icon("download", 17) + "</div>" +
          '<div class="body"><div class="name">' + Store.round2(x.ln.qty) + " × " + money(x.ln.unitCost) + '</div><div class="meta">' +
          UI.esc(supplierName(x.p.supplierId)) + " · " + Store.dateShort(x.p.date) + "</div></div>" +
          '<div class="end"><div class="amount sm">' + money(Store.num(x.ln.qty) * Store.num(x.ln.unitCost)) + "</div>" +
          V.paidBadge(x.p.state) + "</div></a>";
      }).join("") + "</div>" : '<p class="small muted">Sem compras registadas.</p>') + "</div>";

    var salesCard = '<div class="card"><div class="card-head"><div class="title">Histórico de vendas</div>' +
      '<span class="pill-note">' + Store.round2(st.salesOut) + " saídas</span></div>" +
      (salesLines.length ? '<div class="rows">' + salesLines.slice(0, 10).map(function (x) {
        return '<a class="row" href="#/vendas/' + x.s.id + '"><div class="tile green">' + UI.icon("arrow-up-right", 16) + "</div>" +
          '<div class="body"><div class="name">' + x.s.id + " · " + UI.esc(x.ci.name) + '</div><div class="meta">' +
          Store.dateShort(x.s.date) + " · " + x.ln.qty + " vendidos</div></div>" +
          '<div class="end"><div class="amount sm">−' + Store.round2(Store.num(x.ln.qty) * (Store.num(x.ci.stockConsumption) || 1)) + "</div></div></a>";
      }).join("") + "</div>" : '<p class="small muted">As vendas deste item aparecem aqui quando o produto estiver ligado ao stock.</p>') + "</div>";

    var movesCard = '<div class="card"><div class="card-head"><div class="title">Histórico de movimentos</div>' +
      '<button class="btn sm soft" data-act="movement-new" data-id="' + item.id + '">+ Movimento</button></div>' +
      (moves.length ? '<div class="rows">' + moves.slice(0, 12).map(function (m) {
        var type = Store.listItem(m.typeId);
        var eff = type && type.meta ? Store.num(type.meta.effect) : 1;
        var person = db.employees.find(function (e) { return e.id === m.responsibleId; });
        return '<div class="row"><div class="tile ' + (eff > 0 ? "green" : "orange") + '">' + UI.icon(eff > 0 ? "arrow-down-left" : "arrow-up-right", 17) + "</div>" +
          '<div class="body"><div class="name">' + UI.esc(Store.listName("movementType", m.typeId, "Movimento")) + '</div>' +
          '<div class="meta">' + Store.dateShort(m.date) + " · " + UI.esc(person ? person.name : "—") + "</div></div>" +
          '<div class="end"><div class="amount sm" style="color:' + (eff > 0 ? "var(--green)" : "var(--orange)") + '">' +
          (eff > 0 ? "+" : "−") + Store.round2(m.qty) + '</div><div class="tiny muted">' + money(Store.num(m.qty) * Store.num(st.avgCost)) + "</div></div></div>";
      }).join("") + "</div>" : '<p class="small muted">Sem movimentos manuais.</p>') + "</div>";

    return '<div class="view">' + head + hero +
      '<div class="two-col"><div class="col">' + detail + linkedCard + "</div><div class=\"col\">" +
      purchCard + salesCard + movesCard + "</div></div></div>";
  }

  function row(k, v) { return '<div class="it"><span class="k">' + k + '</span><span class="v">' + v + "</span></div>"; }

  /* ------------------------------------------------------------------
     EDIÇÃO / CRIAÇÃO DE ITEM DE STOCK
  ------------------------------------------------------------------ */
  function openStockForm(id) {
    var db = Store.db();
    var it = id ? db.stock.find(function (x) { return x.id === id; }) : null;
    var fields = [
      { k: "name", label: "Item", type: "text", required: true, full: true },
      { k: "categoryId", label: "Categoria", type: "select", options: UI.optsFromList("stockCategory") },
      { k: "unitId", label: "Unidade", type: "select", options: UI.optsFromList("unit") },
      { k: "qtyInitial", label: "Quantidade inicial", type: "number", step: "0.01" },
      { k: "costInitial", label: "Custo unitário inicial", type: "money" },
      { k: "minStock", label: "Stock mínimo", type: "number", step: "0.01" },
      { k: "salePrice", label: "Preço de venda s/IVA", type: "money" },
      { k: "supplierId", label: "Fornecedor habitual", type: "select", options: supplierOptions() },
      { k: "barcode", label: "Código de barras", type: "text" },
      { k: "notes", label: "Notas", type: "textarea" }
    ];
    UI.form({
      title: it ? "Editar item de stock" : "Novo item de stock",
      subtitle: "Quantidade atual e custo médio são calculados automaticamente.",
      fields: fields,
      values: it || { qtyInitial: 0, costInitial: 0, minStock: 0, categoryId: "", unitId: "" },
      submitLabel: it ? "Guardar" : "Criar item",
      onSubmit: function (v) {
        if (!it && db.stock.some(function (s) { return s.name.trim().toLowerCase() === v.name.trim().toLowerCase(); })) {
          UI.toast("Já existe um item com esse nome.", "err"); return false;
        }
        if (it) {
          Object.assign(it, {
            name: v.name, categoryId: v.categoryId, unitId: v.unitId,
            minStock: v.minStock, supplierId: v.supplierId || null, notes: v.notes,
            salePrice: v.salePrice || null, barcode: v.barcode || "",
            qtyInitial: v.qtyInitial, costInitial: v.costInitial
          });
        } else {
          db.stock.push({
            id: Store.nextId("stock", "STK-", 4),
            name: v.name, categoryId: v.categoryId, unitId: v.unitId,
            qtyInitial: v.qtyInitial, costInitial: v.costInitial, minStock: v.minStock,
            supplierId: v.supplierId || null, salePrice: v.salePrice || null,
            barcode: v.barcode || "", notes: v.notes
          });
        }
        Store.save();
        App.onData(it ? "Item atualizado." : "Item criado.");
        if (!it) App.go("#/stock");
        else App.render();
      }
    });
  }
  function supplierOptions() {
    return Store.db().suppliers.map(function (s) { return { id: s.id, name: s.name }; });
  }

  /* ------------------------------------------------------------------
     COMPRAS — LISTA
  ------------------------------------------------------------------ */
  function purchases() {
    var db = Store.db();
    var f = App.purchFilter || (App.purchFilter = { q: "", state: "Todas" });
    var list = db.purchases.map(function (p) { return { p: p, t: Engine.purchaseTotals(p) }; });
    if (f.state === "Pendentes") list = list.filter(function (x) { return x.p.state !== "Paga"; });
    if (f.state === "Pagas") list = list.filter(function (x) { return x.p.state === "Paga"; });
    if (f.state === "Em atraso") list = list.filter(function (x) { return x.p.state !== "Paga" && x.p.dueDate && x.p.dueDate < Store.todayISO(); });
    if (f.q) {
      var q = f.q.toLowerCase();
      list = list.filter(function (x) {
        return (x.p.id || "").toLowerCase().indexOf(q) >= 0 || supplierName(x.p.supplierId).toLowerCase().indexOf(q) >= 0 ||
          (x.p.items || []).some(function (l) { return stockName(l.stockItemId).toLowerCase().indexOf(q) >= 0; });
      });
    }
    list.sort(function (a, b) { return a.p.date > b.p.date ? -1 : 1; });

    var totalNet = 0, totalPending = 0;
    list.forEach(function (x) { totalNet += x.t.net; if (x.p.state !== "Paga") totalPending += x.t.total; });

    var head = V.head("Compras", "Entradas de mercadoria e custo médio ponderado",
      '<button class="btn primary" data-act="purchase-new">' + UI.icon("plus", 17) + " Nova compra</button>");

    var tabs = '<div class="tabs">' + ["Todas", "Pendentes", "Em atraso", "Pagas"].map(function (s) {
      return '<button data-act="purch-filter" data-id="' + s + '" aria-pressed="' + (f.state === s) + '">' + s + "</button>";
    }).join("") + "</div>";

    var summary = '<div class="grid cols-3" style="margin-bottom:14px">' +
      V.kpi("Comprado s/IVA", money(totalNet), "accent-lime") +
      V.kpi("Nº de compras", String(list.length)) +
      V.kpi("A pagar c/IVA", money(totalPending), totalPending ? "accent-orange" : "") + "</div>";

    var rows = list.length ? '<div class="group">' + list.map(function (x) {
      var first = (x.p.items || [])[0];
      var label = x.p.items.length > 1 ? x.p.items.length + " itens" : (stockName(first.stockItemId) + " × " + Store.round2(first.qty));
      var overdue = x.p.state !== "Paga" && x.p.dueDate && x.p.dueDate < Store.todayISO();
      return '<a class="row" href="#/compras/' + x.p.id + '">' +
        '<div class="tile blue">' + UI.icon("truck", 18) + "</div>" +
        '<div class="body"><div class="name">' + UI.esc(label) + "</div>" +
        '<div class="meta">' + UI.esc(supplierName(x.p.supplierId)) + " · " + Store.dateShort(x.p.date) +
        (overdue ? ' · <span style="color:var(--red)">vencida</span>' : "") + "</div></div>" +
        '<div class="end"><div class="amount">' + money(x.t.total) + "</div>" +
        (x.p.state === "Paga" ? '<span class="chip green">Paga</span>' : '<span class="chip orange">Pendente</span>') + "</div></a>";
    }).join("") + "</div>" : UI.emptyState("shopping-bag", "Ainda não há compras registadas.",
      '<button class="btn primary" data-act="purchase-new">Registar compra</button>');

    return '<div class="view">' + head + summary + tabs + rows + "</div>";
  }

  /* ------------------------------------------------------------------
     COMPRA — FORMULÁRIO
  ------------------------------------------------------------------ */
  function openPurchaseForm(presetStockId) {
    var db = Store.db();
    if (!db.stock.length) { UI.toast("Crie primeiro um item de stock.", "err"); return; }
    if (!db.suppliers.length) { UI.toast("Crie primeiro um fornecedor.", "err"); return; }

    var model = {
      date: Store.todayISO(),
      supplierId: (db.stock.find(function (s) { return s.id === presetStockId; }) || {}).supplierId || "",
      paymentMethod: "", state: "Pendente",
      responsibleId: (App.currentUser() || {}).id || "",
      dueDate: Store.addDays(Store.todayISO(), Store.num(db.config.paymentTerm, 30)),
      notes: "",
      items: [{
        stockItemId: presetStockId || "", qty: 1, unitCost: 0,
        vatRate: Store.num(db.config.vatDefault)
      }]
    };

    var ov = UI.openSheet(
      '<div class="sheet-head"><div class="ttl"><h2>Nova compra</h2><p>A entrada atualiza o stock e o custo médio ponderado.</p></div>' +
      '<button class="icon-btn ghost" data-x="1">' + UI.icon("x", 18) + "</button></div>" +
      '<div class="sheet-body"><div id="purchBody"></div></div>' +
      '<div class="sheet-foot"><button class="btn ghost" data-cancel="1">Cancelar</button>' +
      '<button class="btn primary" data-save="1">Registar compra</button></div>', "wide");

    var body = ov.querySelector("#purchBody");
    function totals() {
      var net = 0, vat = 0;
      model.items.forEach(function (l) { var x = Store.num(l.qty) * Store.num(l.unitCost); net += x; vat += x * Store.num(l.vatRate); });
      return { net: Store.round2(net), vat: Store.round2(vat), total: Store.round2(net + vat) };
    }
    function paint() {
      var t = totals();
      body.innerHTML = '<div class="card tight"><div class="form"><div class="grid2">' +
        UI.fieldHTML({ k: "supplierId", label: "Fornecedor", type: "select", required: true, options: supplierOptions() }, model.supplierId) +
        UI.fieldHTML({ k: "date", label: "Data", type: "date", required: true }, model.date) +
        UI.fieldHTML({ k: "paymentMethod", label: "Forma de pagamento", type: "select", options: UI.optsFromList("paymentMethod", "— Definir depois —") }, model.paymentMethod) +
        UI.fieldHTML({ k: "state", label: "Estado", type: "select", options: ["Pendente", "Paga"], blank: false }, model.state) +
        UI.fieldHTML({ k: "dueDate", label: "Vencimento", type: "date" }, model.dueDate) +
        UI.fieldHTML({ k: "responsibleId", label: "Responsável", type: "select", options: V.employeeOptions(false) }, model.responsibleId) +
        "</div>" + UI.fieldHTML({ k: "notes", label: "Notas", type: "textarea" }, model.notes) + "</div></div>" +
        '<div class="card tight" style="margin-top:10px"><div class="card-head"><div class="title">Itens comprados</div></div>' +
        '<div class="lines">' + model.items.map(function (l, i) {
          return '<div class="line-card"><div class="top"><span class="num">' + (i + 1) + "</span>" +
            '<div style="flex:1"><select class="select" data-l="' + i + '" data-k="stockItemId">' +
            '<option value="">— Item de stock —</option>' + db.stock.map(function (s) {
              return '<option value="' + s.id + '"' + (s.id === l.stockItemId ? " selected" : "") + ">" + UI.esc(s.name) + "</option>";
            }).join("") + "</select></div>" +
            '<button class="btn-icon" data-rm="' + i + '">' + UI.icon("trash", 15) + "</button></div>" +
            '<div class="gridl" style="grid-template-columns:1fr 1fr 1fr">' +
            '<div><div class="lbl">Qtd</div><input class="input" type="number" min="0" step="0.01" value="' + l.qty + '" data-l="' + i + '" data-k="qty"></div>' +
            '<div><div class="lbl">Custo unit.</div><input class="input" type="number" min="0" step="0.01" value="' + l.unitCost + '" data-l="' + i + '" data-k="unitCost"></div>' +
            '<div><div class="lbl">IVA</div><select class="select" data-l="' + i + '" data-k="vatRate">' +
            Store.listValues("vatRate").map(function (v) {
              return '<option value="' + v.meta.rate + '"' + (String(v.meta.rate) === String(l.vatRate) ? " selected" : "") + ">" + v.name + "</option>";
            }).join("") + "</select></div></div>" +
            '<div class="line-total"><span>Subtotal <b>' + money(Store.num(l.qty) * Store.num(l.unitCost)) + "</b></span>" +
            (l.stockItemId ? '<span class="chip">stock atual ' + (Engine.stockOf(l.stockItemId) || {}).qty + "</span>" : "") + "</div></div>";
        }).join("") + "</div>" +
        '<button class="btn ghost sm" id="addLine" style="margin-top:10px">' + UI.icon("plus", 15) + " Adicionar item</button></div>" +
        '<div class="card tight" style="margin-top:10px"><div class="kv">' +
        row("Subtotal s/IVA", money(t.net)) + row("IVA", money(t.vat)) + row("Total c/IVA", "<b>" + money(t.total) + "</b>") +
        "</div></div>";
      bind();
    }
    function bind() {
      body.querySelectorAll(".form [name]").forEach(function (el) {
        var nm = el.getAttribute("name");
        var h = function () {
          model[nm] = el.value;
          if (nm === "date" && el.value) { model.dueDate = Store.addDays(el.value, Store.num(db.config.paymentTerm, 30)); paint(); }
        };
        el.addEventListener("change", h);
        el.addEventListener("input", function () { model[nm] = el.value; });
      });
      body.querySelectorAll("[data-l]").forEach(function (el) {
        var h = function () {
          var i = Number(el.getAttribute("data-l")), k = el.getAttribute("data-k");
          var l = model.items[i];
          if (k === "stockItemId") {
            l.stockItemId = el.value;
            var st = db.stock.find(function (s) { return s.id === el.value; });
            if (st) l.unitCost = st.costInitial;
          } else if (k === "vatRate") l.vatRate = Store.num(el.value);
          else l[k] = Store.num(el.value);
          paint();
        };
        el.addEventListener("change", h);
      });
      body.querySelectorAll("[data-rm]").forEach(function (b) {
        b.onclick = function () {
          if (model.items.length <= 1) { UI.toast("A compra precisa de pelo menos um item.", "err"); return; }
          model.items.splice(Number(b.getAttribute("data-rm")), 1); paint();
        };
      });
      var add = body.querySelector("#addLine");
      if (add) add.onclick = function () {
        model.items.push({ stockItemId: "", qty: 1, unitCost: 0, vatRate: Store.num(db.config.vatDefault) });
        paint();
      };
    }
    paint();

    ov.querySelector("[data-x]").onclick = UI.closeSheet;
    ov.querySelector("[data-cancel]").onclick = UI.closeSheet;
    ov.querySelector("[data-save]").onclick = function () {
      if (!model.supplierId) { UI.toast("Escolha o fornecedor.", "err"); return; }
      var items = model.items.filter(function (l) { return l.stockItemId && Store.num(l.qty) > 0; });
      if (!items.length) { UI.toast("Adicione pelo menos um item de stock.", "err"); return; }
      var t = totals();
      db.purchases.push({
        id: Store.nextId("purchase", "CP-", 4),
        date: model.date, supplierId: model.supplierId, items: items,
        paymentMethod: model.paymentMethod, state: model.state,
        dueDate: model.dueDate, notes: model.notes, responsibleId: model.responsibleId || null,
        net: t.net, vat: t.vat, total: t.total
      });
      Store.save();
      UI.closeSheet();
      App.onData("Compra registada · stock e custo médio atualizados.");
      App.go("#/compras");
    };
  }

  /* ------------------------------------------------------------------
     COMPRA — DETALHE
  ------------------------------------------------------------------ */
  function purchaseDetail(id) {
    var db = Store.db();
    var p = db.purchases.find(function (x) { return x.id === id; });
    if (!p) return Views.notFound();
    var t = Engine.purchaseTotals(p);
    var overdue = p.state !== "Paga" && p.dueDate && p.dueDate < Store.todayISO();

    var head = '<div class="page-head"><div class="titles">' +
      '<button class="pill-note" data-nav="#/compras" style="margin-bottom:8px">' + UI.icon("chevron-left", 14) + " Compras</button>" +
      '<div class="h1">' + p.id + '</div><div class="sub">' + Store.dateLong(p.date) + " · " + UI.esc(supplierName(p.supplierId)) + "</div></div>" +
      '<div class="btn-row">' +
      (p.state !== "Paga" ? '<button class="btn primary" data-act="purchase-pay" data-id="' + p.id + '">' + UI.icon("check", 16) + " Marcar paga</button>" : "") +
      '<button class="btn danger" data-act="purchase-delete" data-id="' + p.id + '">' + UI.icon("trash", 16) + "</button></div></div>";

    var hero = '<div class="detail-hero"><div class="top"><div>' +
      '<div class="eyebrow">Total com IVA</div><div class="amt">' + money(t.total) + "</div>" +
      '<div class="hstack" style="margin-top:9px">' + (p.state === "Paga" ? '<span class="chip green">Paga</span>' : '<span class="chip orange">Pendente</span>') +
      (overdue ? '<span class="chip red">Vencida</span>' : "") + "</div></div>" +
      '<div class="right"><div class="eyebrow">Vencimento</div><div class="amt" style="font-size:17px">' + Store.dateLong(p.dueDate) + "</div>" +
      '<div class="tiny muted">' + UI.esc(Store.listName("paymentMethod", p.paymentMethod, "—")) + "</div></div></div>" +
      '<div class="divider"></div><div class="kv">' + row("Fornecedor", '<a href="#/fornecedores/' + p.supplierId + '" style="color:var(--lime)">' + UI.esc(supplierName(p.supplierId)) + "</a>") +
      row("Subtotal s/IVA", money(t.net)) + row("IVA", money(t.vat)) + row("Total", "<b>" + money(t.total) + "</b>") + "</div></div>";

    var items = '<div class="card"><div class="card-head"><div class="title">Itens</div></div><div class="rows">' +
      (p.items || []).map(function (l) {
        var st = Engine.stockOf(l.stockItemId);
        return '<a class="row" href="#/stock/' + l.stockItemId + '">' +
          '<div class="tile blue">' + UI.icon("package", 18) + "</div>" +
          '<div class="body"><div class="name">' + UI.esc(stockName(l.stockItemId)) + '</div>' +
          '<div class="meta">' + Store.round2(l.qty) + " × " + money(l.unitCost) + " · IVA " + Store.pct(l.vatRate, 0) +
          " · custo médio agora " + money(st ? st.avgCost : 0) + "</div></div>" +
          '<div class="end"><div class="amount">' + money(Store.num(l.qty) * Store.num(l.unitCost)) + "</div></div></a>";
      }).join("") + "</div></div>";

    var notes = p.notes ? '<div class="card"><div class="card-head"><div class="title">Notas</div></div><p class="small muted">' + UI.esc(p.notes) + "</p></div>" : "";

    return '<div class="view">' + head + hero + items + notes +
      '<div class="form-note" style="margin-top:12px">As compras de mercadoria não são lançadas como despesa operacional. Entram no stock e no custo médio ponderado.</div></div>';
  }

  /* ------------------------------------------------------------------
     MOVIMENTOS DE STOCK
  ------------------------------------------------------------------ */
  function movements() {
    var db = Store.db();
    var f = App.moveFilter || (App.moveFilter = { q: "", typeId: "" });
    var list = db.movements.slice();
    if (f.typeId) list = list.filter(function (m) { return m.typeId === f.typeId; });
    if (f.q) {
      var q = f.q.toLowerCase();
      list = list.filter(function (m) { return (m.id + " " + stockName(m.stockItemId)).toLowerCase().indexOf(q) >= 0; });
    }
    list.sort(function (a, b) { return a.date > b.date ? -1 : 1; });

    var head = V.head("Movimentos de stock", "Ajustes, perdas, devoluções e consumos",
      '<button class="btn primary" data-act="movement-new">' + UI.icon("plus", 17) + " Novo movimento</button>", "#/stock");

    var inp = 0, out = 0;
    list.forEach(function (m) {
      var ty = Store.listItem(m.typeId);
      var eff = ty && ty.meta ? Store.num(ty.meta.effect) : 1;
      if (eff > 0) inp += Store.num(m.qty); else out += Store.num(m.qty);
    });

    var filterBar = '<div class="hstack" style="margin-bottom:12px">' +
      '<select class="select" data-act="move-type" style="width:auto;min-height:40px;border-radius:999px;font-size:12.5px;padding:8px 32px 8px 13px">' +
      '<option value="">Todos os tipos</option>' + Store.listValues("movementType").map(function (v) {
        return '<option value="' + v.id + '"' + (f.typeId === v.id ? " selected" : "") + ">" + UI.esc(v.name) + "</option>";
      }).join("") + "</select>" +
      '<div class="search" style="flex:1;min-width:140px;height:40px">' + UI.icon("search", 17) +
      '<input placeholder="Item ou nº" data-act="move-search" value="' + UI.esc(f.q) + '"></div></div>';

    var rows = list.length ? '<div class="group">' + list.map(function (m) {
      var ty = Store.listItem(m.typeId);
      var eff = ty && ty.meta ? Store.num(ty.meta.effect) : 1;
      var st = Engine.stockOf(m.stockItemId) || { avgCost: 0 };
      var person = db.employees.find(function (e) { return e.id === m.responsibleId; });
      return '<div class="row"><div class="tile ' + (eff > 0 ? "green" : "orange") + '">' +
        UI.icon(eff > 0 ? "arrow-down-left" : "arrow-up-right", 18) + "</div>" +
        '<div class="body"><div class="name">' + UI.esc(stockName(m.stockItemId)) + '</div>' +
        '<div class="meta">' + UI.esc(ty ? ty.name : "Movimento") + " · " + Store.dateShort(m.date) +
        (person ? " · " + UI.esc(person.name) : "") + "</div></div>" +
        '<div class="end"><div class="amount sm" style="color:' + (eff > 0 ? "var(--green)" : "var(--orange)") + '">' +
        (eff > 0 ? "+" : "−") + Store.round2(m.qty) + '</div><div class="tiny muted">' + money(Store.num(m.qty) * Store.num(st.avgCost)) + "</div>" +
        '<button class="btn-icon" data-act="move-delete" data-id="' + m.id + '" aria-label="Eliminar">' + UI.icon("trash", 14) + "</button></div></div>";
    }).join("") + "</div>" : UI.emptyState("layers", "Sem movimentos registados.",
      '<button class="btn primary" data-act="movement-new">Registar movimento</button>');

    App.afterRender = function () {
      var i = document.querySelector('[data-act="move-search"]');
      if (i) i.addEventListener("input", UI.debounce(function () {
        f.q = i.value; App.render();
        var a = document.querySelector('[data-act="move-search"]');
        if (a) { a.focus(); a.setSelectionRange(a.value.length, a.value.length); }
      }, 240));
    };

    return '<div class="view">' + head +
      '<div class="grid cols-3" style="margin-bottom:14px">' +
      V.kpi("Entradas", "+" + Store.round2(inp), "accent-green") +
      V.kpi("Saídas", "−" + Store.round2(out), "accent-orange") +
      V.kpi("Movimentos", String(list.length)) + "</div>" + filterBar + rows + "</div>";
  }

  function openMovementForm(presetStockId) {
    var db = Store.db();
    if (!db.stock.length) { UI.toast("Crie primeiro um item de stock.", "err"); return; }
    var itemId = presetStockId || db.stock[0].id;
    var fields = [
      { k: "date", label: "Data", type: "date", required: true, value: Store.todayISO() },
      { k: "stockItemId", label: "Item de stock", type: "select", required: true, blank: false, options: db.stock.map(function (s) { return { id: s.id, name: s.name }; }) },
      { k: "typeId", label: "Tipo de movimento", type: "select", required: true, blank: false, options: UI.optsFromList("movementType", null) },
      { k: "qty", label: "Quantidade (positiva)", type: "number", step: "0.01", required: true, value: 1 },
      { k: "responsibleId", label: "Responsável", type: "select", options: V.employeeOptions(false), value: (App.currentUser() || {}).id },
      { k: "notes", label: "Notas", type: "textarea" }
    ];
    var extra = '<div class="form-note" id="moveHint" style="margin-top:12px"></div>';
    var ov = UI.form({
      title: "Novo movimento de stock",
      subtitle: "O efeito (entrada ou saída) vem do tipo escolhido.",
      fields: fields,
      values: { date: Store.todayISO(), stockItemId: itemId, typeId: (Store.listValues("movementType")[0] || {}).id, qty: 1, responsibleId: (App.currentUser() || {}).id },
      extraBody: extra,
      submitLabel: "Registar movimento",
      onChange: function (v) {
        var type = Store.listItem(v.typeId);
        var eff = type && type.meta ? Store.num(type.meta.effect) : 1;
        var st = Engine.stockOf(v.stockItemId) || { qty: 0, avgCost: 0 };
        var qty = Store.num(v.qty);
        var after = Store.round2(st.qty + (eff >= 0 ? qty : -qty));
        var hint = document.getElementById("moveHint");
        if (hint) hint.innerHTML = (eff > 0 ? "<b>Entrada</b> de " : "<b>Saída</b> de ") + qty +
          " · stock atual " + st.qty + " → <b>" + after + "</b> · valor ao custo médio " + money(qty * Store.num(st.avgCost));
      },
      validate: function (v) {
        var type = Store.listItem(v.typeId);
        var eff = type && type.meta ? Store.num(type.meta.effect) : 1;
        var st = Engine.stockOf(v.stockItemId) || { qty: 0 };
        if (eff < 0 && Store.num(v.qty) > st.qty + 0.0001 && !App.isAdmin()) {
          return "Esta saída deixa o stock negativo. É necessária autorização de administrador.";
        }
        if (Store.num(v.qty) <= 0) return "A quantidade tem de ser superior a zero.";
        return null;
      },
      onSubmit: function (v) {
        db.movements.push({
          id: Store.nextId("movement", "MV-", 4),
          date: v.date, stockItemId: v.stockItemId, typeId: v.typeId,
          qty: Store.round2(Store.num(v.qty)), responsibleId: v.responsibleId || null,
          notes: v.notes || ""
        });
        Store.save();
        App.onData("Movimento registado · stock atualizado.");
        App.render();
      }
    });
    setTimeout(function () {
      var el = ov.querySelector('[name="typeId"]');
      if (el) el.dispatchEvent(new Event("change"));
    }, 50);
  }

  /* ------------------------------------------------------------------
     FORNECEDORES
  ------------------------------------------------------------------ */
  function suppliers() {
    var db = Store.db();
    var stats = Engine.supplierStats();
    var head = V.head("Fornecedores", db.suppliers.length + " fornecedores registados",
      '<button class="btn primary" data-act="supplier-new">' + UI.icon("plus", 17) + " Novo fornecedor</button>");

    var rows = db.suppliers.length ? '<div class="group">' + db.suppliers.map(function (s) {
      var st = stats[s.id] || { purchases: 0, purchased: 0, expenses: 0, payable: 0 };
      return '<a class="row" href="#/fornecedores/' + s.id + '">' +
        '<div class="tile">' + UI.icon("truck", 18) + "</div>" +
        '<div class="body"><div class="name">' + UI.esc(s.name) + '</div>' +
        '<div class="meta">' + (s.city ? UI.esc(s.city) + " · " : "") + st.purchases + " compras · " + money(st.purchased) + " s/IVA</div></div>" +
        '<div class="end"><div class="amount sm">' + (st.payable > 0 ? money(st.payable) : "—") + "</div>" +
        (st.payable > 0 ? '<span class="chip orange">em dívida</span>' : '<span class="chip">' + UI.esc(s.state || "Ativo") + "</span>") + "</div></a>";
    }).join("") + "</div>" : UI.emptyState("truck", "Ainda não há fornecedores.", '<button class="btn primary" data-act="supplier-new">Criar fornecedor</button>');

    return '<div class="view">' + head + rows + "</div>";
  }

  function supplierDetail(id) {
    var db = Store.db();
    var s = db.suppliers.find(function (x) { return x.id === id; });
    if (!s) return Views.notFound();
    var st = Engine.supplierInfo(id);
    var purch = db.purchases.filter(function (p) { return p.supplierId === id; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    var exps = db.expenses.filter(function (x) { return x.supplierId === id; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    var items = db.stock.filter(function (i) { return i.supplierId === id; });

    var head = '<div class="page-head"><div class="titles">' +
      '<button class="pill-note" data-nav="#/fornecedores" style="margin-bottom:8px">' + UI.icon("chevron-left", 14) + " Fornecedores</button>" +
      '<div class="h1">' + UI.esc(s.name) + '</div><div class="sub">' + s.id + " · " + UI.esc(s.city || "") + "</div></div>" +
      '<div class="btn-row"><button class="btn ghost" data-act="supplier-edit" data-id="' + s.id + '">' + UI.icon("edit", 16) + " Editar</button>" +
      '<button class="btn primary" data-act="purchase-new">' + UI.icon("plus", 16) + " Compra</button></div></div>";

    var hero = '<div class="detail-hero"><div class="top"><div>' +
      '<div class="eyebrow">Em dívida com IVA</div><div class="amt" style="color:' + (st.payable > 0 ? "var(--orange)" : "var(--green)") + '">' + money(st.payable) + "</div>" +
      '<div class="hstack" style="margin-top:9px">' + (s.state === "Ativo" ? '<span class="chip green">Ativo</span>' : '<span class="chip red">Inativo</span>') + "</div></div>" +
      '<div class="right"><div class="eyebrow">Comprado s/IVA</div><div class="amt" style="font-size:20px">' + money(st.purchased) + "</div>" +
      '<div class="tiny muted">' + st.purchases + " compras</div></div></div>" +
      '<div class="divider"></div><div class="kv">' +
      row("NUIT", UI.esc(s.nuit || "—")) +
      row("Pessoa de contacto", UI.esc(s.contact || "—")) +
      row("Email", s.email ? '<a href="mailto:' + UI.esc(s.email) + '">' + UI.esc(s.email) + "</a>" : "—") +
      row("Telefone", UI.esc(s.phone || "—")) +
      row("Despesas associadas", money(st.expenses)) + "</div></div>";

    var purchCard = '<div class="card"><div class="card-head"><div class="title">Compras</div><span class="pill-note">' + purch.length + "</span></div>" +
      (purch.length ? '<div class="rows">' + purch.map(function (p) {
        var t = Engine.purchaseTotals(p);
        return '<a class="row" href="#/compras/' + p.id + '"><div class="tile blue">' + UI.icon("shopping-bag", 17) + "</div>" +
          '<div class="body"><div class="name">' + p.id + " · " + money(t.total) + '</div><div class="meta">' + Store.dateShort(p.date) + "</div></div>" +
          '<div class="end">' + (p.state === "Paga" ? '<span class="chip green">Paga</span>' : '<span class="chip orange">Pendente</span>') + "</div></a>";
      }).join("") + "</div>" : '<p class="small muted">Sem compras registadas.</p>') + "</div>";

    var expCard = '<div class="card"><div class="card-head"><div class="title">Despesas</div><span class="pill-note">' + exps.length + "</span></div>" +
      (exps.length ? '<div class="rows">' + exps.map(function (x) {
        return '<div class="row"><div class="tile orange">' + UI.icon("wallet", 17) + "</div>" +
          '<div class="body"><div class="name">' + UI.esc(x.description) + '</div><div class="meta">' + Store.dateShort(x.date) + " · " + UI.esc(V.categoryName(x.categoryId)) + "</div></div>" +
          '<div class="end"><div class="amount sm">' + money(x.total) + "</div>" + (x.state === "Paga" ? '<span class="chip green">Paga</span>' : '<span class="chip orange">Pendente</span>') + "</div></div>";
      }).join("") + "</div>" : '<p class="small muted">Sem despesas associadas.</p>') + "</div>";

    var itemsCard = items.length ? '<div class="card"><div class="card-head"><div class="title">Itens fornecidos</div></div><div class="rows">' +
      items.map(function (i) {
        var stt = Engine.stockOf(i.id);
        return '<a class="row" href="#/stock/' + i.id + '"><div class="tile">' + UI.icon("package", 17) + "</div>" +
          '<div class="body"><div class="name">' + UI.esc(i.name) + '</div><div class="meta">stock ' + stt.qty + " · mín. " + i.minStock + "</div></div>" +
          '<div class="end"><div class="amount sm">' + money(stt.avgCost) + "</div></div></a>";
      }).join("") + "</div></div>" : "";

    return '<div class="view">' + head + hero +
      '<div class="two-col"><div class="col">' + purchCard + "</div><div class=\"col\">" + expCard + itemsCard + "</div></div></div>";
  }

  /* ------------------------------------------------------------------
     AÇÕES
  ------------------------------------------------------------------ */
  Actions["stock-new"] = function () { openStockForm(null); };
  Actions["stock-edit"] = function (id) { openStockForm(id); };
  Actions["stock-filter"] = function (id) { App.stockFilter.situation = id; App.render(); };
  Actions["stock-delete"] = function (id) {
    var db = Store.db();
    var item = db.stock.find(function (x) { return x.id === id; });
    if (!item) return;
    var used = db.purchases.some(function (p) { return (p.items || []).some(function (l) { return l.stockItemId === id; }); }) ||
      db.movements.some(function (m) { return m.stockItemId === id; }) ||
      db.catalog.some(function (c) { return c.stockItemId === id; });
    if (used) {
      UI.toast("Não é possível eliminar: existem compras, movimentos ou produtos ligados a este item.", "err");
      return;
    }
    UI.confirm({ title: "Eliminar item de stock", message: "\"" + item.name + "\" será removido do inventário.", confirmLabel: "Eliminar", danger: true })
      .then(function (ok) {
        if (!ok) return;
        db.stock = db.stock.filter(function (x) { return x.id !== id; });
        Store.save(); App.onData("Item de stock eliminado."); App.go("#/stock");
      });
  };

  Actions["purchase-new"] = function (id) {
    if (!App.isAdmin()) { UI.toast("Apenas administradores registam compras.", "err"); return; }
    openPurchaseForm(id || null);
  };
  Actions["purch-filter"] = function (id) { App.purchFilter.state = id; App.render(); };
  Actions["purchase-pay"] = function (id) {
    var db = Store.db();
    var p = db.purchases.find(function (x) { return x.id === id; });
    if (!p) return;
    UI.confirm({ title: "Marcar compra como paga", message: "O valor deixa de contar como dívida a fornecedores.", confirmLabel: "Confirmar" })
      .then(function (ok) {
        if (!ok) return;
        p.state = "Paga";
        Store.save(); App.onData("Compra marcada como paga."); App.render();
      });
  };
  Actions["purchase-delete"] = function (id) {
    var db = Store.db();
    var p = db.purchases.find(function (x) { return x.id === id; });
    if (!p) return;
    UI.confirm({
      title: "Eliminar compra " + p.id,
      message: "O stock e o custo médio serão recalculados sem esta compra.",
      confirmLabel: "Eliminar", danger: true
    }).then(function (ok) {
      if (!ok) return;
      db.purchases = db.purchases.filter(function (x) { return x.id !== id; });
      Store.save(); App.onData("Compra eliminada."); App.go("#/compras");
    });
  };

  Actions["movement-new"] = function (id) { openMovementForm(id || null); };
  Actions["move-delete"] = function (id) {
    UI.confirm({ title: "Eliminar movimento", message: "O stock será recalculado sem este movimento.", confirmLabel: "Eliminar", danger: true })
      .then(function (ok) {
        if (!ok) return;
        var db = Store.db();
        db.movements = db.movements.filter(function (m) { return m.id !== id; });
        Store.save(); App.onData("Movimento eliminado."); App.render();
      });
  };

  Actions["supplier-new"] = function () { openSupplierForm(null); };
  Actions["supplier-edit"] = function (id) { openSupplierForm(id); };

  function openSupplierForm(id) {
    var db = Store.db();
    var s = id ? db.suppliers.find(function (x) { return x.id === id; }) : null;
    UI.form({
      title: s ? "Editar fornecedor" : "Novo fornecedor",
      fields: [
        { k: "name", label: "Nome do fornecedor", type: "text", required: true, full: true },
        { k: "nuit", label: "NUIT", type: "text" },
        { k: "contact", label: "Pessoa de contacto", type: "text" },
        { k: "email", label: "Email", type: "email" },
        { k: "phone", label: "Telefone / WhatsApp", type: "tel" },
        { k: "city", label: "Cidade", type: "text" },
        { k: "state", label: "Estado", type: "select", options: ["Ativo", "Inativo"], blank: false },
        { k: "notes", label: "Notas", type: "textarea" }
      ],
      values: s || { state: "Ativo" },
      submitLabel: s ? "Guardar" : "Criar fornecedor",
      onSubmit: function (v) {
        if (s) Object.assign(s, v);
        else db.suppliers.push(Object.assign({ id: Store.nextId("supplier", "FOR-", 3) }, v, { notes: v.notes || "" }));
        Store.save();
        App.onData(s ? "Fornecedor atualizado." : "Fornecedor criado.");
        if (!s) App.go("#/fornecedores"); else App.render();
      }
    });
  }

  document.addEventListener("change", function (e) {
    if (!e.target) return;
    if (e.target.getAttribute("data-act") === "move-type") {
      App.moveFilter.typeId = e.target.value; App.render();
    }
  });

  window.Views.stock = stock;
  window.Views.stockDetail = stockDetail;
  window.Views.purchases = purchases;
  window.Views.purchaseDetail = purchaseDetail;
  window.Views.movements = movements;
  window.Views.suppliers = suppliers;
  window.Views.supplierDetail = supplierDetail;
  window.openStockForm = openStockForm;
  window.openPurchaseForm = openPurchaseForm;
  window.openMovementForm = openMovementForm;
})();
