/* ============================================================
   APP — shell, navegação, sessão e permissões
   ============================================================ */
(function () {
  "use strict";

  var NAV = [
    { id: "home", label: "Início", icon: "home", route: "#/inicio", group: "Principal" },
    { id: "sales", label: "Vendas", icon: "receipt", route: "#/vendas", group: "Principal" },
    { id: "stock", label: "Stock", icon: "package", route: "#/stock", group: "Principal" },
    { id: "expenses", label: "Despesas", icon: "wallet", route: "#/despesas", group: "Principal" },
    { id: "more", label: "Mais", icon: "grid", route: "#/mais", group: "Principal" },
    { id: "dashboard", label: "Dashboard", icon: "bar-chart", route: "#/dashboard", group: "Gestão" },
    { id: "clients", label: "Clientes", icon: "users", route: "#/clientes", group: "Gestão" },
    { id: "catalog", label: "Serviços e produtos", icon: "tag", route: "#/catalogo", group: "Gestão" },
    { id: "purchases", label: "Compras", icon: "shopping-bag", route: "#/compras", group: "Operações" },
    { id: "suppliers", label: "Fornecedores", icon: "truck", route: "#/fornecedores", group: "Operações" },
    { id: "movements", label: "Movimentos de stock", icon: "layers", route: "#/movimentos", group: "Operações" },
    { id: "pos", label: "Caixa / POS", icon: "printer", route: "#/pdv", group: "Operações" },
    { id: "tasks", label: "Tarefas", icon: "clipboard-list", route: "#/tarefas", group: "Equipa" },
    { id: "employees", label: "Funcionários", icon: "user", route: "#/funcionarios", group: "Equipa" },
    { id: "lists", label: "Listas editáveis", icon: "sliders", route: "#/listas", group: "Sistema" },
    { id: "settings", label: "Configuração", icon: "settings", route: "#/config", group: "Sistema" }
  ];

  var SESSION_KEY = "empresa_demo_session_v1";

  var MODULE_BY_ROUTE = {
    clientes: "clients", catalogo: "catalog", vendas: "sales", pdv: "pos",
    despesas: "expenses", funcionarios: "employees", stock: "stock",
    tarefas: "tasks", compras: "purchases", fornecedores: "suppliers",
    movimentos: "movements"
  };

  var App = {
    route: "",
    parts: [],
    session: null,

    init: function () {
      Store.load();
      App.session = App.loadSession();
      window.addEventListener("hashchange", App.render);
      document.addEventListener("click", App.onClick);
      if (!location.hash) location.hash = "#/inicio";
      App.render();
      // atualiza indicadores de data (alertas) a cada minuto
      setInterval(function () { Store.invalidate(); }, 60000);
    },

    loadSession: function () {
      var raw = null;
      try { raw = localStorage.getItem(SESSION_KEY); } catch (e) { }
      var s = raw ? JSON.parse(raw) : null;
      var db = Store.db();
      var admin = db.employees.find(function (e) { return e.permission === "admin" && e.state !== "Inativo"; }) || db.employees[0];
      if (!s || !db.employees.find(function (e) { return e.id === s.employeeId; })) {
        s = { employeeId: admin ? admin.id : null, since: new Date().toISOString() };
      }
      return s;
    },

    saveSession: function () {
      try { localStorage.setItem(SESSION_KEY, JSON.stringify(App.session)); } catch (e) { }
    },

    currentUser: function () {
      var db = Store.db();
      var id = App.session && App.session.employeeId;
      return db.employees.find(function (e) { return e.id === id; }) || db.employees[0] || null;
    },

    isAdmin: function () {
      var u = App.currentUser();
      return !u || u.permission !== "operator";
    },

    go: function (route) {
      if (location.hash === route) App.render();
      else location.hash = route;
    },

    render: function () {
      var hash = location.hash || "#/inicio";
      var path = hash.replace(/^#\/?/, "");
      var segs = path.split("/").filter(Boolean);
      App.route = segs[0] || "inicio";
      App.parts = segs.slice(1);

      var db = Store.db();
      var cfg = db.config;
      var user = App.currentUser();
      var initials = (cfg.company || "ED").replace(/[^\p{L}\p{N} ]/gu, "").split(/\s+/).filter(Boolean).slice(0, 2)
        .map(function (w) { return w[0].toUpperCase(); }).join("") || "ED";

      var visibleNav = NAV.filter(function (n) {
        var m = MODULE_BY_ROUTE[n.route.replace("#/", "")];
        return !m || cfg.modules[m] !== false;
      });
      var isHome = App.route === "inicio";
      var topbar = "";
      if (isHome) {
        var hour = new Date().getHours();
        var greet = hour < 12 ? "Bom dia" : hour < 20 ? "Boa tarde" : "Boa noite";
        var alerts = Engine.alerts();
        var alertCount = alerts.salesOverdue.length + alerts.restock.length + alerts.tasksLate.length + alerts.purchasesOverdue.length;
        topbar = '<div class="topbar">' +
          '<div class="avatar">' + UI.esc(initials) + "</div>" +
          '<div class="who"><div class="hello">' + greet + ", " + UI.esc((user && user.name || "").split(" ")[0]) + "</div>" +
          '<div class="brand">' + UI.esc(cfg.company) + "</div></div>" +
          '<button class="icon-btn" data-act="alerts" aria-label="Notificações">' + UI.icon("bell", 20) +
          (alertCount ? '<span class="dot"></span>' : "") + "</button></div>";
      }

      var navMobile = '<nav class="nav-mobile" aria-label="Navegação principal">' +
        visibleNav.slice(0, 5).map(function (n) {
          var active = App.route === n.id ||
            (n.id === "sales" && (App.route === "vendas" || App.route === "pdv")) ||
            (n.id === "stock" && ["stock", "compras", "movimentos", "fornecedores"].indexOf(App.route) >= 0) ||
            (n.id === "expenses" && App.route === "despesas");
          return '<a href="' + n.route + '"' + (active ? ' class="active"' : "") + ">" + UI.icon(n.icon, 21) +
            "<span>" + n.label + "</span></a>";
        }).join("") + "</nav>";

      var groups = {};
      visibleNav.slice(5).forEach(function (n) { (groups[n.group] = groups[n.group] || []).push(n); });
      var sideHTML = '<aside class="side">' +
        '<div class="brand-block"><div class="avatar">' + UI.esc(initials) + "</div>" +
        '<div><div class="nm">' + UI.esc(cfg.company) + '</div><div class="sb">Gestão empresarial</div></div></div>' +
        '<div class="nav-group"><div class="gl">Principal</div>' +
        visibleNav.slice(0, 4).map(function (n) {
          var active = (App.route === n.id) ||
            (n.id === "sales" && (App.route === "vendas" || App.route === "pdv")) ||
            (n.id === "stock" && ["stock", "compras", "movimentos", "fornecedores"].indexOf(App.route) >= 0);
          return '<a href="' + n.route + '"' + (active ? ' class="active"' : "") + ">" + UI.icon(n.icon, 18) + n.label + "</a>";
        }).join("") + "</div>" +
        Object.keys(groups).map(function (g) {
          return '<div class="nav-group"><div class="gl">' + g + "</div>" +
            groups[g].map(function (n) {
              var active = App.route === n.id;
              return '<a href="' + n.route + '"' + (active ? ' class="active"' : "") + ">" + UI.icon(n.icon, 18) + n.label + "</a>";
            }).join("") + "</div>";
        }).join("") +
        '<div class="side-foot">' + UI.esc(user ? user.name : "") + " · " +
        (App.isAdmin() ? "Administrador" : "Operador de caixa") + "</div></aside>";

      var view = App.resolveView();
      document.getElementById("app").innerHTML =
        '<div class="shell">' + sideHTML + navMobile +
        '<main class="main">' + topbar + view + "</main></div>" +
        '<div class="toasts"></div>';

      document.title = (viewTitle(App.route) ? viewTitle(App.route) + " · " : "") + cfg.company;
      window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
      if (App.afterRender) { var fn = App.afterRender; App.afterRender = null; fn(); }
    },

    onData: function (msg) {
      Store.invalidate();
      if (msg) UI.toast(msg);
      App.render();
    },

    resolveView: function () {
      var r = App.route;
      try {
        if (r === "inicio") return Views.home();
        if (r === "vendas") return App.parts.length ? Views.saleDetail(App.parts[0]) : Views.sales();
        if (r === "pdv") return Views.pos();
        if (r === "stock") return App.parts.length ? Views.stockDetail(App.parts[0]) : Views.stock();
        if (r === "despesas") return Views.expenses();
        if (r === "mais") return Views.more();
        if (r === "dashboard") return Views.dashboard();
        if (r === "clientes") return App.parts.length ? Views.clientDetail(App.parts[0]) : Views.clients();
        if (r === "catalogo") return App.parts.length ? Views.catalogDetail(App.parts[0]) : Views.catalog();
        if (r === "compras") return App.parts.length ? Views.purchaseDetail(App.parts[0]) : Views.purchases();
        if (r === "fornecedores") return App.parts.length ? Views.supplierDetail(App.parts[0]) : Views.suppliers();
        if (r === "movimentos") return Views.movements();
        if (r === "tarefas") return Views.tasks();
        if (r === "funcionarios") return Views.employees();
        if (r === "listas") return Views.lists();
        if (r === "config") return Views.settings();
      } catch (err) {
        console.error(err);
        return '<div class="empty"><div class="ic">' + UI.icon("alert-triangle", 24) + "</div><p>Ocorreu um erro ao abrir este ecrã.</p>" +
          '<div class="tiny muted" style="margin-top:8px">' + UI.esc(err.message) + "</div>" +
          '<button class="btn primary" onclick="location.hash=\'#/inicio\'">Voltar ao início</button></div>';
      }
      return Views.notFound();
    },

    onClick: function (e) {
      var t = e.target.closest("[data-nav]");
      if (t) {
        e.preventDefault();
        App.go(t.getAttribute("data-nav"));
        return;
      }
      var back = e.target.closest("[data-back]");
      if (back) { e.preventDefault(); history.length > 1 ? history.back() : App.go("#/inicio"); return; }
      var act = e.target.closest("[data-act]");
      if (act) {
        e.preventDefault();
        var fn = window.Actions && Actions[act.getAttribute("data-act")];
        if (fn) fn(act.getAttribute("data-id"), act);
      }
    }
  };

  function viewTitle(route) {
    var map = {
      inicio: "", vendas: "Vendas", pdv: "Caixa", stock: "Stock", despesas: "Despesas", mais: "Mais",
      dashboard: "Dashboard", clientes: "Clientes", catalogo: "Serviços e produtos", compras: "Compras",
      fornecedores: "Fornecedores", movimentos: "Movimentos de stock", tarefas: "Tarefas",
      funcionarios: "Funcionários", listas: "Listas", config: "Configuração"
    };
    return map[route] || "";
  }

  window.App = App;
  window.NAV = NAV;
  document.addEventListener("DOMContentLoaded", App.init);
})();
