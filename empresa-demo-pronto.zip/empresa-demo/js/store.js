/* ============================================================
   STORE — persistência local + motor de cálculo do sistema
   ============================================================ */
(function () {
  "use strict";

  var KEY = "empresa_demo_db_v1";
  var state = null;
  var memOnly = false;
  var dirty = false;

  try {
    var probe = "__probe__";
    localStorage.setItem(probe, "1");
    localStorage.removeItem(probe);
  } catch (e) { memOnly = true; }

  /* ---------------------------------- utilidades ------------------- */
  function round2(v) { return Math.round((Number(v) + Number.EPSILON) * 100) / 100; }
  function num(v, d) { var n = Number(v); return isFinite(n) ? n : (d === undefined ? 0 : d); }
  function todayISO() {
    var d = new Date();
    return [d.getFullYear(), String(d.getMonth() + 1).padStart(2, "0"), String(d.getDate()).padStart(2, "0")].join("-");
  }
  function parseISO(s) {
    if (!s) return null;
    var p = String(s).slice(0, 10).split("-");
    return new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]));
  }
  function iso(d) {
    return [d.getFullYear(), String(d.getMonth() + 1).padStart(2, "0"), String(d.getDate()).padStart(2, "0")].join("-");
  }
  function addDays(isoDate, days) {
    var d = parseISO(isoDate); if (!d) return "";
    d.setDate(d.getDate() + days);
    return iso(d);
  }
  function diffDays(a, b) { // b - a em dias
    var da = parseISO(a), db = parseISO(b);
    if (!da || !db) return 0;
    return Math.round((db - da) / 86400000);
  }
  function pad(n, size) { return String(n).padStart(size, "0"); }

  /* ---------------------------------- formatação -------------------- */
  var nf2 = new Intl.NumberFormat("pt-PT", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  var nf0 = new Intl.NumberFormat("pt-PT", { maximumFractionDigits: 0 });
  var nfCompact = new Intl.NumberFormat("pt-PT", { notation: "compact", maximumFractionDigits: 1 });

  function money(v, opts) {
    opts = opts || {};
    var cur = (state && state.config.currency) || "€";
    var n = num(v);
    var txt = opts.compact ? nfCompact.format(n) : nf2.format(n);
    return txt + " " + cur;
  }
  function money0(v) {
    var cur = (state && state.config.currency) || "€";
    return nf0.format(num(v)) + " " + cur;
  }
  function pct(v, digits) {
    if (v === null || v === undefined || !isFinite(v)) return "—";
    var p = num(v) * 100;
    if (digits === undefined) {
      digits = Math.abs(p - Math.round(p * 10) / 10) < 1e-9 ? 1 : 2;
    }
    return p.toFixed(digits) + "%";
  }
  function dateShort(s) {
    var d = parseISO(s); if (!d) return "—";
    return pad(d.getDate(), 2) + "/" + pad(d.getMonth() + 1, 2) + "/" + String(d.getFullYear()).slice(2);
  }
  function dateLong(s) {
    var d = parseISO(s); if (!d) return "—";
    return pad(d.getDate(), 2) + "/" + pad(d.getMonth() + 1, 2) + "/" + d.getFullYear();
  }
  var MONTHS = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
  var MONTHS_LONG = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];

  /* ---------------------------------- persistência ----------------- */
  function load() {
    if (state) return state;
    var raw = null;
    if (!memOnly) { try { raw = localStorage.getItem(KEY); } catch (e) { raw = null; } }
    if (raw) {
      try {
        var parsed = JSON.parse(raw);
        if (parsed && parsed.config && parsed.sales) { state = migrate(parsed); return state; }
      } catch (e) { console.warn("Base de dados local inválida — a repor exemplo.", e); }
    }
    state = window.SEED.build();
    save(true);
    return state;
  }

  function migrate(db) {
    db.counters = db.counters || {};
    ["clients", "suppliers", "catalog", "stock", "purchases", "movements", "sales", "payments", "expenses", "employees", "tasks", "carts", "lists"].forEach(function (k) {
      if (!Array.isArray(db[k])) db[k] = [];
    });
    db.config.modules = db.config.modules || {};
    return db;
  }

  function save(immediate) {
    dirty = true;
    invalidate();
    if (memOnly) return;
    var write = function () {
      try { localStorage.setItem(KEY, JSON.stringify(state)); dirty = false; }
      catch (e) {
        console.error("Falha ao gravar dados locais", e);
        if (window.UI && UI.toast) UI.toast("Não foi possível gravar os dados no dispositivo.", "err");
      }
    };
    if (immediate) { write(); return; }
    clearTimeout(save._t);
    save._t = setTimeout(write, 120);
  }

  function resetToSeed() {
    state = window.SEED.build();
    save(true);
    return state;
  }

  function replaceAll(db) {
    state = migrate(db);
    save(true);
  }

  function exportJSON() { return JSON.stringify(state, null, 2); }

  function db() { return load(); }

  function nextId(kind, prefix, size) {
    var c = db().counters;
    c[kind] = (c[kind] || 0) + 1;
    return prefix + pad(c[kind], size);
  }

  /* ---------------------------------- cache ------------------------ */
  var cache = {};
  function invalidate() { cache = {}; }
  function memo(key, fn) {
    if (!(key in cache)) cache[key] = fn();
    return cache[key];
  }

  /* ---------------------------------- listas ----------------------- */
  function listValues(key) {
    return db().lists
      .filter(function (l) { return l.key === key; })
      .sort(function (a, b) { return a.order - b.order; });
  }
  function listName(key, id, fallback) {
    if (!id) return fallback === undefined ? "—" : fallback;
    var it = db().lists.find(function (l) { return l.id === id; });
    return it ? it.name : (fallback === undefined ? "—" : fallback);
  }
  function listItem(id) {
    return db().lists.find(function (l) { return l.id === id; }) || null;
  }
  function vatRateOf(id) {
    var it = listItem(id);
    if (!it) return num(db().config.vatDefault);
    return num(it.meta && it.meta.rate, num(db().config.vatDefault));
  }

  /* ---------------------------------- motor ------------------------ */
  var Engine = {
    round2: round2,
    num: num,
    todayISO: todayISO,
    addDays: addDays,
    diffDays: diffDays,

    /* ---------- stock ---------- */
    stockStats: function () {
      return memo("stockStats", function () {
        var d = db(), map = {};
        d.stock.forEach(function (it) {
          var purchasedQty = 0, purchasedValue = 0, purValueTax = 0;
          d.purchases.forEach(function (p) {
            (p.items || []).forEach(function (ln) {
              if (ln.stockItemId === it.id) {
                purchasedQty += num(ln.qty);
                purchasedValue += num(ln.qty) * num(ln.unitCost);
                purValueTax += num(ln.qty) * num(ln.unitCost) * num(ln.vatRate);
              }
            });
          });
          var movesIn = 0, movesOut = 0;
          d.movements.forEach(function (m) {
            if (m.stockItemId !== it.id) return;
            var type = listItem(m.typeId);
            var eff = type && type.meta ? num(type.meta.effect, 1) : 1;
            if (eff >= 0) movesIn += num(m.qty); else movesOut += num(m.qty);
          });
          var salesOut = 0, soldValue = 0;
          d.sales.forEach(function (s) {
            if (s.state === "Cancelada") return;
            (s.items || []).forEach(function (ln) {
              var ci = d.catalog.find(function (c) { return c.id === ln.catalogId; });
              if (!ci || ci.stockItemId !== it.id) return;
              var cons = num(ci.stockConsumption) || 1;
              salesOut += num(ln.qty) * cons;
              soldValue += num(ln.qty) * cons * (num(ci.manualCost) || num(it.costInitial));
            });
          });
          var qty = num(it.qtyInitial) + purchasedQty + movesIn - movesOut - salesOut;
          var denom = num(it.qtyInitial) + purchasedQty;
          var avgCost = denom > 0
            ? (num(it.qtyInitial) * num(it.costInitial) + purchasedValue) / denom
            : num(it.costInitial);
          var situation = qty <= 0 ? "SEM STOCK" : (qty <= num(it.minStock) ? "REPOR" : "OK");
          var suggested = situation === "OK" ? 0 : Math.max(0, 2 * num(it.minStock) - qty);
          map[it.id] = {
            qty: round2(qty), avgCost: round2(avgCost),
            value: round2(Math.max(0, qty) * avgCost),
            purchasedQty: round2(purchasedQty), purchasedValue: round2(purchasedValue),
            movesIn: round2(movesIn), movesOut: round2(movesOut), salesOut: round2(salesOut),
            situation: situation, suggested: round2(suggested)
          };
        });
        return map;
      });
    },
    stockOf: function (id) { return Engine.stockStats()[id] || null; },

    /* ---------- catálogo ---------- */
    catalogEffectiveCost: function (c) {
      if (!c) return 0;
      if (c.stockItemId) {
        var st = Engine.stockOf(c.stockItemId);
        var cons = num(c.stockConsumption) || 1;
        return round2((st ? st.avgCost : 0) * cons);
      }
      return round2(num(c.manualCost));
    },
    catalogVat: function (c) {
      if (!c) return num(db().config.vatDefault);
      return (c.vatRate === null || c.vatRate === undefined || c.vatRate === "") ? num(db().config.vatDefault) : num(c.vatRate);
    },
    catalogStats: function () {
      return memo("catalogStats", function () {
        var d = db(), map = {};
        d.catalog.forEach(function (c) {
          map[c.id] = { qtySold: 0, revenue: 0, cost: 0, profit: 0, sales: 0 };
        });
        d.sales.forEach(function (s) {
          if (s.state === "Cancelada") return;
          (s.items || []).forEach(function (ln) {
            var e = map[ln.catalogId];
            if (!e) return;
            var net = num(ln.qty) * num(ln.price) * (1 - num(ln.discount));
            e.qtySold += num(ln.qty);
            e.revenue += net;
            e.cost += num(ln.qty) * num(ln.cost);
            e.profit += net - num(ln.qty) * num(ln.cost);
          });
        });
        Object.keys(map).forEach(function (k) {
          map[k].revenue = round2(map[k].revenue);
          map[k].cost = round2(map[k].cost);
          map[k].profit = round2(map[k].profit);
          map[k].qtySold = round2(map[k].qtySold);
        });
        return map;
      });
    },
    catalogInfo: function (c) {
      var eff = Engine.catalogEffectiveCost(c);
      var vat = Engine.catalogVat(c);
      var stats = Engine.catalogStats()[c.id] || { qtySold: 0, revenue: 0 };
      var st = c.stockItemId ? Engine.stockOf(c.stockItemId) : null;
      return {
        effectiveCost: eff,
        margin: num(c.price) > 0 ? (num(c.price) - eff) / num(c.price) : 0,
        vat: vat,
        priceWithVat: round2(num(c.price) * (1 + vat)),
        qtySold: stats.qtySold,
        revenue: stats.revenue,
        profit: stats.profit,
        stockQty: st ? st.qty : null,
        stockConsumption: num(c.stockConsumption) || 1
      };
    },

    /* ---------- vendas ---------- */
    saleTotals: function (s) {
      var net = 0, vat = 0, cost = 0, qty = 0;
      (s.items || []).forEach(function (ln) {
        var lnet = num(ln.qty) * num(ln.price) * (1 - num(ln.discount));
        net += lnet;
        vat += lnet * num(ln.vatRate);
        cost += num(ln.qty) * num(ln.cost);
        qty += num(ln.qty);
      });
      net = round2(net); vat = round2(vat); cost = round2(cost);
      var total = round2(net + vat);
      var paid = round2((db().payments || []).filter(function (p) { return p.saleId === s.id; })
        .reduce(function (a, p) { return a + num(p.amount); }, 0));
      var balance = round2(total - paid);
      if (Math.abs(balance) < 0.005) balance = 0;
      var cancelled = s.state === "Cancelada";
      var status = cancelled ? "Cancelada" : (balance <= 0 ? "Paga" : "Pendente");
      var overdue = 0;
      if (!cancelled && balance > 0 && s.dueDate && s.dueDate < todayISO()) {
        overdue = Math.max(0, diffDays(s.dueDate, todayISO()));
      }
      return {
        net: net, vat: vat, total: total, cost: cost, qty: round2(qty),
        profit: round2(net - cost), paid: paid, balance: balance,
        status: status, overdueDays: overdue,
        margin: net > 0 ? (net - cost) / net : 0,
        count: (s.items || []).length
      };
    },
    saleLabel: function (s) {
      if (s.items && s.items.length === 1) return s.items[0].name + " × " + num(s.items[0].qty);
      return (s.items && s.items.length) ? s.items.length + " itens" : "Sem itens";
    },
    paymentsOf: function (saleId) {
      return db().payments.filter(function (p) { return p.saleId === saleId; })
        .sort(function (a, b) { return a.date < b.date ? -1 : 1; });
    },

    /* ---------- clientes / fornecedores ---------- */
    clientStats: function () {
      return memo("clientStats", function () {
        var d = db(), map = {};
        d.clients.forEach(function (c) { map[c.id] = { sales: 0, revenue: 0, debt: 0, overdue: 0, lastSale: "", balanceOpen: 0 }; });
        d.sales.forEach(function (s) {
          if (s.state === "Cancelada") return;
          var e = map[s.clientId]; if (!e) return;
          var t = Engine.saleTotals(s);
          e.sales += 1; e.revenue += t.net; e.debt += t.balance;
          if (t.overdueDays > 0) e.overdue += t.balance;
          if (!e.lastSale || s.date > e.lastSale) e.lastSale = s.date;
        });
        var list = Object.keys(map).map(function (k) { return map[k]; });
        list.sort(function (a, b) { return b.revenue - a.revenue; });
        list.forEach(function (e, i) { e.rank = e.revenue > 0 ? i + 1 : null; e.revenue = round2(e.revenue); e.debt = round2(e.debt); e.overdue = round2(e.overdue); });
        return map;
      });
    },
    clientInfo: function (id) { return Engine.clientStats()[id] || { sales: 0, revenue: 0, debt: 0, overdue: 0, lastSale: "", rank: null }; },

    supplierStats: function () {
      return memo("supplierStats", function () {
        var d = db(), map = {};
        d.suppliers.forEach(function (s) { map[s.id] = { purchases: 0, purchased: 0, expenses: 0, payable: 0 }; });
        d.purchases.forEach(function (p) {
          var e = map[p.supplierId]; if (!e) return;
          var t = Engine.purchaseTotals(p);
          e.purchases += 1; e.purchased += t.net;
          if (p.state !== "Paga") e.payable += t.total;
        });
        d.expenses.forEach(function (x) {
          var e = map[x.supplierId]; if (!e) return;
          e.expenses += num(x.amountNet);
          if (x.state !== "Paga") e.payable += num(x.total);
        });
        Object.keys(map).forEach(function (k) {
          map[k].purchased = round2(map[k].purchased);
          map[k].expenses = round2(map[k].expenses);
          map[k].payable = round2(map[k].payable);
        });
        return map;
      });
    },
    supplierInfo: function (id) { return Engine.supplierStats()[id] || { purchases: 0, purchased: 0, expenses: 0, payable: 0 }; },

    purchaseTotals: function (p) {
      var net = 0, vat = 0;
      (p.items || []).forEach(function (ln) {
        var l = num(ln.qty) * num(ln.unitCost);
        net += l; vat += l * num(ln.vatRate);
      });
      return { net: round2(net), vat: round2(vat), total: round2(net + vat) };
    },

    /* ---------- funcionários ---------- */
    employeeMonthlyCost: function (e, monthISO) {
      var salary = num(e.baseSalary);
      (e.salaryHistory || []).forEach(function (h) {
        if (h.date <= monthISO) salary = num(h.salary);
      });
      var charges = e.chargesDefault || e.chargesPct === null || e.chargesPct === undefined
        ? num(db().config.payrollPct) : num(e.chargesPct);
      return round2(salary * (1 + charges));
    },
    employeeSalaryAt: function (e, monthISO) {
      var salary = num(e.baseSalary);
      (e.salaryHistory || []).forEach(function (h) { if (h.date <= monthISO) salary = num(h.salary); });
      return salary;
    },
    employeeActiveInMonth: function (e, monthStart, monthEnd) {
      if (e.hireDate && e.hireDate > monthEnd) return false;
      if (e.exitDate && e.exitDate < monthStart) return false;
      if (!e.exitDate && e.state === "Inativo") return false;
      return true;
    },
    employeeStats: function () {
      return memo("employeeStats", function () {
        var d = db(), map = {};
        d.employees.forEach(function (e) { map[e.id] = { revenue: 0, sales: 0, openTasks: 0 }; });
        d.sales.forEach(function (s) {
          if (s.state === "Cancelada") return;
          var e = map[s.sellerId]; if (!e) return;
          var t = Engine.saleTotals(s);
          e.revenue += t.net; e.sales += 1;
        });
        d.tasks.forEach(function (t) {
          if (t.state === "Concluída") return;
          var e = map[t.employeeId]; if (e) e.openTasks += 1;
        });
        Object.keys(map).forEach(function (k) { map[k].revenue = round2(map[k].revenue); });
        return map;
      });
    },
    payrollForMonth: function (year, month) {
      var d = db();
      var mStart = iso(new Date(year, month - 1, 1));
      var mEnd = iso(new Date(year, month, 0));
      var total = 0;
      d.employees.forEach(function (e) {
        if (!Engine.employeeActiveInMonth(e, mStart, mEnd)) return;
        total += Engine.employeeMonthlyCost(e, mEnd);
      });
      return round2(total);
    },

    /* ---------- tarefas ---------- */
    taskStatus: function (t) {
      if (t.state === "Concluída") return { days: null, alert: "" };
      if (!t.dueDate) return { days: null, alert: "" };
      var days = diffDays(todayISO(), t.dueDate);
      var alert = "";
      if (days < 0) alert = "ATRASADA";
      else if (days <= num(db().config.alertDays, 3)) alert = "Prazo próximo";
      return { days: days, alert: alert };
    },

    /* ---------- despesas ---------- */
    expenseVat: function (x) { return round2(num(x.amountNet) * num(x.vatRate)); },
    expenseTotal: function (x) { return round2(num(x.amountNet) + Engine.expenseVat(x)); },

    /* ---------- dashboard ---------- */
    monthRows: function (year) {
      return memo("months" + year, function () {
        var d = db(), rows = [];
        var today = parseISO(todayISO());
        for (var m = 1; m <= 12; m++) {
          var start = iso(new Date(year, m - 1, 1));
          var end = iso(new Date(year, m, 0));
          var revenue = 0, cost = 0;
          d.sales.forEach(function (s) {
            if (s.state === "Cancelada" || !s.date) return;
            if (s.date < start || s.date > end) return;
            var t = Engine.saleTotals(s);
            revenue += t.net; cost += t.cost;
          });
          var expenses = 0;
          d.expenses.forEach(function (x) {
            if (!x.date || x.date < start || x.date > end) return;
            expenses += num(x.amountNet);
          });
          var payroll = 0;
          var monthStartDate = new Date(year, m - 1, 1);
          if (monthStartDate <= today) payroll = Engine.payrollForMonth(year, m);
          var target = num(d.config.monthlyTarget);
          rows.push({
            month: m, label: MONTHS[m - 1], labelLong: MONTHS_LONG[m - 1],
            revenue: round2(revenue), cost: round2(cost),
            gross: round2(revenue - cost),
            expenses: round2(expenses), payroll: round2(payroll),
            result: round2(revenue - cost - expenses - payroll),
            target: target, targetPct: target > 0 ? revenue / target : 0
          });
        }
        return rows;
      });
    },

    yearStats: function (year) {
      return memo("year" + year, function () {
        var d = db(), rows = Engine.monthRows(year);
        var revenue = 0, cost = 0, expenses = 0, payroll = 0, count = 0;
        rows.forEach(function (r) {
          revenue += r.revenue; cost += r.cost; expenses += r.expenses; payroll += r.payroll;
        });
        d.sales.forEach(function (s) {
          if (s.state === "Cancelada") return;
          if (!s.date || s.date.slice(0, 4) !== String(year)) return;
          count += 1;
        });
        var gross = round2(revenue - cost);
        var result = round2(gross - expenses - payroll);
        var receivable = 0, overdue = 0, salesVat = 0;
        d.sales.forEach(function (s) {
          if (s.state === "Cancelada") return;
          var t = Engine.saleTotals(s);
          receivable += t.balance;
          if (t.overdueDays > 0) overdue += t.balance;
          if (s.date && s.date.slice(0, 4) === String(year)) salesVat += t.vat;
        });
        var payable = 0, purchaseVat = 0, expenseVat = 0;
        d.purchases.forEach(function (p) {
          var t = Engine.purchaseTotals(p);
          if (p.state !== "Paga") payable += t.total;
          if (p.date && p.date.slice(0, 4) === String(year)) purchaseVat += t.vat;
        });
        d.expenses.forEach(function (x) {
          if (x.state !== "Paga") payable += num(x.total);
          if (x.date && x.date.slice(0, 4) === String(year)) expenseVat += num(x.vatRate) * num(x.amountNet);
        });
        var stockStats = Engine.stockStats();
        var stockValue = 0, restock = 0;
        Object.keys(stockStats).forEach(function (k) {
          stockValue += stockStats[k].value;
          if (stockStats[k].situation !== "OK") restock += 1;
        });
        var activeClients = d.clients.filter(function (c) { return c.state === "Ativo"; }).length;
        var openTasks = d.tasks.filter(function (t) { return t.title && t.state !== "Concluída"; }).length;
        return {
          year: year, revenue: round2(revenue), cost: round2(cost), gross: gross,
          expenses: round2(expenses), payroll: round2(payroll), result: result,
          salesCount: count, avgTicket: count ? round2(revenue / count) : 0,
          grossMargin: revenue > 0 ? gross / revenue : 0,
          resultMargin: revenue > 0 ? result / revenue : 0,
          activeClients: activeClients, openTasks: openTasks,
          receivable: round2(receivable), overdue: round2(overdue), payable: round2(payable),
          stockValue: round2(stockValue), restockCount: restock,
          vatDue: round2(salesVat - purchaseVat - expenseVat),
          salesVat: round2(salesVat), purchaseVat: round2(purchaseVat), expenseVat: round2(expenseVat)
        };
      });
    },

    expensesByCategory: function (year) {
      return memo("expCat" + year, function () {
        var d = db();
        var cats = listValues("expenseCategory");
        var map = {};
        cats.forEach(function (c) { map[c.id] = { name: c.name, value: 0 }; });
        var other = 0, total = 0;
        d.expenses.forEach(function (x) {
          if (!x.date || x.date.slice(0, 4) !== String(year)) return;
          total += num(x.amountNet);
          if (map[x.categoryId]) map[x.categoryId].value += num(x.amountNet);
          else other += num(x.amountNet);
        });
        var arr = cats.map(function (c) { return { id: c.id, name: map[c.id].name, value: round2(map[c.id].value) }; })
          .filter(function (x) { return x.value > 0.004; });
        if (other > 0.004) arr.push({ id: "other", name: "Outras", value: round2(other) });
        arr.sort(function (a, b) { return b.value - a.value; });
        arr.forEach(function (x) { x.pct = total > 0 ? x.value / total : 0; });
        return { rows: arr, total: round2(total) };
      });
    },

    topClients: function (limit) {
      var d = db(), stats = Engine.clientStats();
      return d.clients.map(function (c) { return { client: c, stat: stats[c.id] || { revenue: 0 } }; })
        .filter(function (x) { return x.stat.revenue > 0; })
        .sort(function (a, b) { return b.stat.revenue - a.stat.revenue; })
        .slice(0, limit || 5);
    },
    topItems: function (limit) {
      var d = db(), stats = Engine.catalogStats();
      return d.catalog.map(function (c) { return { item: c, stat: stats[c.id] || { revenue: 0, qtySold: 0 } }; })
        .filter(function (x) { return x.stat.revenue > 0; })
        .sort(function (a, b) { return b.stat.revenue - a.stat.revenue; })
        .slice(0, limit || 5);
    },

    alerts: function () {
      var d = db(), out = { salesOverdue: [], purchasesOverdue: [], stockNegative: [], restock: [], tasksLate: [], tasksSoon: [] };
      d.sales.forEach(function (s) {
        var t = Engine.saleTotals(s);
        if (t.status === "Pendente" && t.overdueDays > 0) out.salesOverdue.push({ sale: s, totals: t });
      });
      d.purchases.forEach(function (p) {
        if (p.state === "Paga") return;
        if (p.dueDate && p.dueDate < todayISO()) out.purchasesOverdue.push({ purchase: p, days: diffDays(p.dueDate, todayISO()) });
      });
      var ss = Engine.stockStats();
      d.stock.forEach(function (it) {
        var st = ss[it.id]; if (!st) return;
        if (st.qty < 0) out.stockNegative.push({ item: it, stat: st });
        else if (st.situation !== "OK") out.restock.push({ item: it, stat: st });
      });
      d.tasks.forEach(function (t) {
        if (!t.title || t.state === "Concluída") return;
        var st = Engine.taskStatus(t);
        if (st.alert === "ATRASADA") out.tasksLate.push({ task: t, status: st });
        else if (st.alert) out.tasksSoon.push({ task: t, status: st });
      });
      return out;
    },

    /* ---------- indicadores "este mês" ---------- */
    monthSnapshot: function (year, month) {
      var row = Engine.monthRows(year)[month - 1];
      var d = db();
      var revenue = 0, cost = 0, receivable = 0, overdue = 0;
      var start = iso(new Date(year, month - 1, 1)), end = iso(new Date(year, month, 0));
      d.sales.forEach(function (s) {
        if (s.state === "Cancelada") return;
        var t = Engine.saleTotals(s);
        if (s.date >= start && s.date <= end) { revenue += t.net; cost += t.cost; }
        receivable += t.balance;
        if (t.overdueDays > 0) overdue += t.balance;
      });
      var stockValue = 0;
      var ss = Engine.stockStats();
      Object.keys(ss).forEach(function (k) { stockValue += ss[k].value; });
      return {
        revenue: round2(revenue), gross: round2(revenue - cost),
        expenses: row.expenses, payroll: row.payroll,
        result: round2(revenue - cost - row.expenses - row.payroll),
        receivable: round2(receivable), overdue: round2(overdue), stockValue: round2(stockValue)
      };
    }
  };

  window.Store = {
    db: db,
    load: load,
    save: save,
    resetToSeed: resetToSeed,
    replaceAll: replaceAll,
    exportJSON: exportJSON,
    nextId: nextId,
    invalidate: invalidate,
    listValues: listValues,
    listName: listName,
    listItem: listItem,
    vatRateOf: vatRateOf,
    money: money,
    money0: money0,
    pct: pct,
    dateShort: dateShort,
    dateLong: dateLong,
    round2: round2,
    num: num,
    todayISO: todayISO,
    addDays: addDays,
    diffDays: diffDays,
    parseISO: parseISO,
    iso: iso,
    MONTHS: MONTHS,
    MONTHS_LONG: MONTHS_LONG,
    isMemoryOnly: function () { return memOnly; }
  };
  window.Engine = Engine;
})();
