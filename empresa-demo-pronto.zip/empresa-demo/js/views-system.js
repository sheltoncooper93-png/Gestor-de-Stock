/* ============================================================
   VIEWS — Listas editáveis e Configuração
   ============================================================ */
(function () {
  "use strict";

  var money = Store.money;

  var LIST_META = [
    { key: "serviceCategory", label: "Categorias de serviço", icon: "tag", used: "Catálogo" },
    { key: "itemType", label: "Tipos de item", icon: "layers", used: "Catálogo" },
    { key: "unit", label: "Unidades", icon: "box", used: "Catálogo e stock" },
    { key: "vatRate", label: "Taxas de IVA", icon: "percent", used: "Vendas, compras e despesas", special: "rate" },
    { key: "paymentMethod", label: "Formas de pagamento", icon: "credit-card", used: "Vendas, compras e despesas" },
    { key: "expenseCategory", label: "Categorias de despesa", icon: "wallet", used: "Despesas" },
    { key: "department", label: "Departamentos", icon: "building", used: "Funcionários" },
    { key: "clientOrigin", label: "Origem do cliente", icon: "arrow-up-right", used: "Clientes" },
    { key: "clientType", label: "Tipos de cliente", icon: "users", used: "Clientes" },
    { key: "clientState", label: "Estados do cliente", icon: "check-circle", used: "Clientes", special: "state" },
    { key: "priority", label: "Prioridades", icon: "alert-triangle", used: "Tarefas" },
    { key: "stockCategory", label: "Categorias de stock", icon: "package", used: "Stock" },
    { key: "currency", label: "Moedas", icon: "coins", used: "Configuração" },
    { key: "role", label: "Cargos", icon: "user", used: "Funcionários" },
    { key: "movementType", label: "Tipos de movimento de stock", icon: "layers", used: "Movimentos", special: "effect" }
  ];

  function usageOf(item) {
    var db = Store.db();
    var n = 0;
    var key = item.key, id = item.id, name = item.name;
    function cnt(arr, fn) { arr.forEach(function (x) { if (fn(x)) n++; }); }
    if (key === "serviceCategory") cnt(db.catalog, function (c) { return c.categoryId === id; });
    if (key === "itemType") cnt(db.catalog, function (c) { return c.typeId === id; });
    if (key === "unit") { cnt(db.catalog, function (c) { return c.unitId === id; }); cnt(db.stock, function (s) { return s.unitId === id; }); }
    if (key === "vatRate") {
      var rate = item.meta && item.meta.rate;
      cnt(db.catalog, function (c) { return Number(c.vatRate) === Number(rate); });
      cnt(db.expenses, function (x) { return Number(x.vatRate) === Number(rate); });
      db.purchases.forEach(function (p) { (p.items || []).forEach(function (l) { if (Number(l.vatRate) === Number(rate)) n++; }); });
      cnt(db.sales, function (s) { return (s.items || []).some(function (l) { return Number(l.vatRate) === Number(rate); }); });
    }
    if (key === "paymentMethod") {
      cnt(db.sales, function (s) { return s.paymentMethod === id; });
      cnt(db.expenses, function (x) { return x.method === id; });
      cnt(db.purchases, function (p) { return p.paymentMethod === id; });
      cnt(db.payments, function (p) { return p.method === id; });
    }
    if (key === "expenseCategory") cnt(db.expenses, function (x) { return x.categoryId === id; });
    if (key === "department") cnt(db.employees, function (e) { return e.departmentId === id; });
    if (key === "clientOrigin") cnt(db.clients, function (c) { return c.originId === id; });
    if (key === "clientType") cnt(db.clients, function (c) { return c.typeId === id; });
    if (key === "clientState") cnt(db.clients, function (c) { return c.state === name; });
    if (key === "priority") cnt(db.tasks, function (t) { return t.priority === id; });
    if (key === "stockCategory") cnt(db.stock, function (s) { return s.categoryId === id; });
    if (key === "currency") { if (db.config.currency === name) n++; }
    if (key === "role") cnt(db.employees, function (e) { return e.roleId === id; });
    if (key === "movementType") cnt(db.movements, function (m) { return m.typeId === id; });
    return n;
  }

  /* ==================================================================
     LISTAS
  ================================================================== */
  function lists() {
    var db = Store.db();
    var q = (App.listSearch || "").toLowerCase();
    var head = V.head("Listas editáveis", "Cada lista alimenta os menus de toda a aplicação",
      App.isAdmin() ? "" : '<span class="chip orange">Apenas leitura</span>', "#/mais");

    var cards = LIST_META.map(function (meta, idx) {
      var items = Store.listValues(meta.key).filter(function (it) {
        return !q || it.name.toLowerCase().indexOf(q) >= 0;
      });
      if (q && !items.length) return "";
      var all = Store.listValues(meta.key);
      var open = q || idx === 0;
      return '<details class="list-block"' + (open ? " open" : "") + ' id="list-' + meta.key + '">' +
        "<summary><div class=\"ic\">" + UI.icon(meta.icon, 16) + "</div>" +
        '<div class="tt"><b>' + UI.esc(meta.label) + "</b><span>" + all.length + " opções · " + UI.esc(meta.used) + "</span></div>" +
        '<div class="chev">' + UI.icon("chevron-down", 16) + "</div></summary>" +
        '<div class="inner">' +
        (items.length ? '<div class="rows">' + items.map(function (it) {
          var use = usageOf(it);
          return '<div class="row">' +
            '<div class="body"><div class="name" style="font-size:13.5px">' + UI.esc(it.name) + "</div>" +
            '<div class="meta">' + (use ? use + " utilização(ões)" : "não utilizada") + "</div></div>" +
            (App.isAdmin() ? '<div class="hstack">' +
              '<button class="btn-icon" style="width:30px;height:30px;border-radius:9px" data-act="list-up" data-id="' + it.id + '" aria-label="Mover para cima" title="Mover para cima">' +
              UI.icon("chevron-down", 13, 'style="transform:rotate(180deg)"') + "</button>" +
              '<button class="btn-icon" style="width:30px;height:30px;border-radius:9px" data-act="list-edit" data-id="' + it.id + '" aria-label="Editar">' + UI.icon("edit", 13) + "</button>" +
              '<button class="btn-icon" style="width:30px;height:30px;border-radius:9px" data-act="list-del" data-id="' + it.id + '" aria-label="Eliminar">' + UI.icon("trash", 13) + "</button></div>" : "") +
            "</div>";
        }).join("") + "</div>" : '<p class="small muted" style="padding:8px 0">Sem opções.</p>') +
        (App.isAdmin() ? '<button class="btn ghost sm" data-act="list-add" data-id="' + meta.key + '" style="margin-top:6px">' +
          UI.icon("plus", 14) + " Adicionar opção</button>" : "") +
        "</div></details>";
    }).join("");

    App.afterRender = function () {
      var i = document.querySelector('[data-act="list-search"]');
      if (i) i.addEventListener("input", UI.debounce(function () {
        App.listSearch = i.value; App.render();
        var a = document.querySelector('[data-act="list-search"]');
        if (a) { a.focus(); a.setSelectionRange(a.value.length, a.value.length); }
      }, 240));
    };

    return '<div class="view">' + head +
      '<div class="search" style="margin-bottom:14px">' + UI.icon("search", 18) +
      '<input placeholder="Pesquisar opção" data-act="list-search" value="' + UI.esc(App.listSearch || "") + '"></div>' +
      '<div class="form-note" style="margin-bottom:14px">As alterações refletem-se imediatamente nos formulários e menus pendentes. Não é possível eliminar opções em uso.</div>' +
      '<div class="vstack">' + cards + "</div></div>";
  }

  function openListOptionForm(listKey, id) {
    var db = Store.db();
    var meta = LIST_META.find(function (m) { return m.key === listKey; });
    var it = id ? db.lists.find(function (x) { return x.id === id; }) : null;
    var fields = [{ k: "name", label: "Opção", type: "text", required: true, full: true }];
    if (meta.special === "rate" && !it) fields.push({ k: "rate", label: "Taxa (%)", type: "pct", required: true, value: 23 });
    if (meta.special === "effect" && !it) {
      fields.push({ k: "effect", label: "Efeito no stock", type: "select", blank: false, options: [{ id: "1", name: "Entrada (+)" }, { id: "-1", name: "Saída (−)" }] });
    }
    UI.form({
      title: (it ? "Editar" : "Nova opção") + " · " + meta.label,
      fields: fields,
      values: it ? { name: it.name } : { effect: "1" },
      submitLabel: it ? "Guardar" : "Adicionar",
      onSubmit: function (v) {
        var name = v.name.trim();
        if (!name) { UI.toast("Indique o nome da opção.", "err"); return false; }
        var dup = Store.listValues(listKey).find(function (x) {
          return x.id !== (it && it.id) && x.name.trim().toLowerCase() === name.toLowerCase();
        });
        if (dup) { UI.toast("Já existe uma opção com esse nome nesta lista.", "err"); return false; }
        if (it) {
          var old = it.name;
          it.name = name;
          // manter referências por nome em sincronia (estados e configuração)
          if (listKey === "clientState") {
            db.clients.forEach(function (c) { if (c.state === old) c.state = name; });
          }
          if (listKey === "currency" && db.config.currency === old) db.config.currency = name;
        } else {
          var order = Store.listValues(listKey).length;
          var lid = "L-" + listKey + "-" + Date.now().toString(36);
          var obj = { id: lid, key: listKey, name: name, order: order, meta: null };
          if (meta.special === "rate") obj.meta = { rate: Store.num(v.rate) / 100 };
          if (meta.special === "effect") obj.meta = { effect: Store.num(v.effect) };
          db.lists.push(obj);
        }
        Store.save();
        App.onData(it ? "Opção atualizada." : "Opção adicionada.");
        App.render();
      }
    });
  }

  /* ==================================================================
     CONFIGURAÇÃO
  ================================================================== */
  function settings() {
    var db = Store.db(), cfg = db.config;
    if (!App.isAdmin()) {
      return '<div class="view">' + V.head("Configuração", "Definições da empresa", "", "#/mais") +
        UI.emptyState("lock", "Apenas administradores podem alterar a configuração.",
          '<button class="btn ghost" data-act="switch-operator">Trocar operador</button>') + "</div>";
    }

    var modules = [
      ["clients", "Clientes"], ["catalog", "Serviços e produtos"], ["sales", "Vendas"],
      ["expenses", "Despesas"], ["employees", "Funcionários"], ["stock", "Stock"],
      ["tasks", "Tarefas"], ["purchases", "Compras"], ["suppliers", "Fornecedores"],
      ["movements", "Movimentos de stock"], ["pos", "Caixa / POS"]
    ];

    var savedSize = 0;
    try { savedSize = (localStorage.getItem("empresa_demo_db_v1") || "").length; } catch (e) { }

    var html = V.head("Configuração", "Dados da empresa, preferências e módulos ativos", "", "#/mais") +
      '<div class="card"><div class="card-head"><div class="title">Dados da empresa</div></div>' +
      '<div class="form" id="cfgForm"><div class="grid2">' +
      field("company", "Nome da empresa", cfg.company, "text") +
      field("slogan", "Slogan / descrição", cfg.slogan, "text") +
      field("nif", "NIF / Nº de contribuinte", cfg.nif, "text") +
      field("sector", "Setor de atividade", cfg.sector, "text") +
      field("address", "Morada", cfg.address, "text") +
      field("city", "Cidade", cfg.city, "text") +
      field("country", "País", cfg.country, "text") +
      field("email", "Email", cfg.email, "email") +
      field("phone", "Telefone", cfg.phone, "tel") +
      field("website", "Website", cfg.website, "text") +
      "</div></div></div>" +

      '<div class="card"><div class="card-head"><div class="title">Preferências</div></div>' +
      '<div class="form"><div class="grid2">' +
      '<div class="field"><label>Moeda</label><select class="select" name="currency">' +
      UI.optsFromList("currency", null).map(function (o) {
        return '<option value="' + UI.esc(o.name) + '"' + (cfg.currency === o.name ? " selected" : "") + ">" + UI.esc(o.name) + "</option>";
      }).join("") + "</select></div>" +
      '<div class="field"><label>Taxa de IVA padrão (%)</label><input class="input" type="number" step="0.01" name="vatDefault" value="' + (cfg.vatDefault * 100) + '"></div>' +
      '<div class="field"><label>Prazo de pagamento (dias)</label><input class="input" type="number" name="paymentTerm" value="' + cfg.paymentTerm + '"></div>' +
      '<div class="field"><label>Ano de referência</label><input class="input" type="number" name="refYear" value="' + cfg.refYear + '"></div>' +
      '<div class="field"><label>Meta de faturação mensal (s/IVA)</label><input class="input" type="number" step="0.01" name="monthlyTarget" value="' + cfg.monthlyTarget + '"></div>' +
      '<div class="field"><label>Encargos patronais (%)</label><input class="input" type="number" step="0.01" name="payrollPct" value="' + (cfg.payrollPct * 100) + '"></div>' +
      '<div class="field"><label>Dias de aviso de tarefas</label><input class="input" type="number" name="alertDays" value="' + cfg.alertDays + '"></div>' +
      '<div class="field"><label class="inline-check"><input type="checkbox" name="creditAuthorization"' + (cfg.creditAuthorization ? " checked" : "") + "> Autorizar vendas a crédito</label></div>" +
      "</div>" + '<div class="form-note">A moeda e o IVA padrão são aplicados em todos os cálculos e cabeçalhos. O ano de referência abre por defeito no dashboard.</div>' +
      '<button class="btn primary" data-act="cfg-save">' + UI.icon("save", 16) + " Guardar configuração</button></div></div>" +

      '<div class="card"><div class="card-head"><div class="title">Módulos ativos</div>' +
      '<span class="pill-note">ocultam da navegação</span></div>' +
      '<div class="grid cols-2">' + modules.map(function (m) {
        var on = cfg.modules[m[0]] !== false;
        return '<label class="inline-check" style="justify-content:space-between;background:var(--surface);padding:10px 13px;border-radius:12px">' +
          '<span>' + m[1] + '</span><input type="checkbox" data-module="' + m[0] + '"' + (on ? " checked" : "") + "></label>";
      }).join("") + "</div></div>" +

      '<div class="card"><div class="card-head"><div class="title">Segurança e sessão</div></div>' +
      '<div class="kv"><div class="it"><span class="k">Operador ativo</span><span class="v">' +
      UI.esc((App.currentUser() || {}).name || "—") + "</span></div>" +
      '<div class="it"><span class="k">Perfil</span><span class="v">' + (App.isAdmin() ? "Administrador" : "Operador de caixa") + "</span></div>" +
      '<div class="it"><span class="k">Armazenamento</span><span class="v">' + (Store.isMemoryOnly() ? "Temporário" : Math.max(1, Math.round(savedSize / 1024)) + " KB no dispositivo") + "</span></div>" +
      '<div class="it"><span class="k">Versão</span><span class="v">1.0 · PWA offline</span></div></div>' +
      '<div class="btn-row" style="margin-top:14px"><button class="btn ghost" data-act="switch-operator">' + UI.icon("users", 16) + " Trocar operador</button>" +
      '<button class="btn ghost" data-act="backup-download">' + UI.icon("download", 16) + " Cópia de segurança</button></div></div>" +

      '<div class="card" style="border-color:rgba(255,122,122,.25)"><div class="card-head"><div class="title" style="color:var(--red)">Zona de risco</div></div>' +
      '<p class="small muted">Recarregar os dados de exemplo substitui tudo pelos dados da planilha original. Apagar tudo deixa a aplicação vazia.</p>' +
      '<div class="btn-row" style="margin-top:12px"><button class="btn ghost" data-act="seed-reset">Recarregar exemplo</button>' +
      '<button class="btn danger" data-act="wipe">' + UI.icon("trash", 16) + " Apagar tudo</button></div></div>";

    function field(name, label, value, type) {
      return '<div class="field"><label>' + label + '</label><input class="input" type="' + type + '" name="' + name + '" value="' + UI.esc(value || "") + '"></div>';
    }

    App.afterRender = function () {
      document.querySelectorAll("[data-module]").forEach(function (el) {
        el.addEventListener("change", function () {
          var cfgNow = Store.db().config;
          cfgNow.modules[el.getAttribute("data-module")] = el.checked;
          Store.save();
          UI.toast(el.checked ? "Módulo ativado." : "Módulo ocultado da navegação.");
          App.render();
        });
      });
    };

    return '<div class="view">' + html + "</div>";
  }

  /* ==================================================================
     DADOS — backup, restauro, reset
  ================================================================== */
  function downloadBackup() {
    var data = Store.exportJSON();
    var blob = new Blob([data], { type: "application/json" });
    var a = document.createElement("a");
    var d = new Date();
    a.href = URL.createObjectURL(blob);
    a.download = "empresa-demo-backup-" + Store.iso(d) + ".json";
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1200);
    UI.toast("Cópia de segurança gerada.");
  }

  function restoreBackup() {
    var input = document.createElement("input");
    input.type = "file";
    input.accept = "application/json,.json";
    input.onchange = function () {
      var file = input.files && input.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function () {
        try {
          var parsed = JSON.parse(String(reader.result));
          if (!parsed || !parsed.config || !Array.isArray(parsed.sales)) throw new Error("Ficheiro inválido");
          UI.confirm({
            title: "Restaurar cópia",
            message: "Todos os dados atuais serão substituídos pelo conteúdo do ficheiro.",
            confirmLabel: "Restaurar", danger: true
          }).then(function (ok) {
            if (!ok) return;
            Store.replaceAll(parsed);
            App.onData("Cópia restaurada.");
            App.go("#/inicio");
          });
        } catch (err) {
          UI.toast("Ficheiro inválido. Selecione uma cópia gerada por esta aplicação.", "err");
        }
      };
      reader.readAsText(file);
    };
    input.click();
  }

  function wipeAll() {
    UI.confirm({
      title: "Apagar todos os dados",
      message: "A aplicação fica vazia: sem clientes, vendas, stock ou despesas. As listas e a configuração são mantidas.",
      confirmLabel: "Apagar tudo", danger: true
    }).then(function (ok) {
      if (!ok) return;
      var fresh = window.SEED.build();
      ["clients", "suppliers", "catalog", "stock", "purchases", "movements", "sales", "payments", "expenses", "tasks", "carts"].forEach(function (k) { fresh[k] = []; });
      // mantém um administrador para poder continuar a operar
      fresh.employees = [{
        id: "FUN-001", name: (App.currentUser() || {}).name || "Administrador",
        roleId: null, departmentId: null, hireDate: Store.todayISO(), exitDate: "",
        baseSalary: 0, chargesPct: null, chargesDefault: true, email: "", phone: "",
        state: "Ativo", pin: "", permission: "admin", notes: "", salaryHistory: []
      }];
      fresh.counters = { client: 0, supplier: 0, catalog: 0, stock: 0, purchase: 0, movement: 0, sale: 0, payment: 0, expense: 0, employee: 1, task: 0, cart: 0 };
      Store.replaceAll(fresh);
      App.session = { employeeId: "FUN-001", since: new Date().toISOString() };
      App.saveSession();
      App.onData("Dados apagados. A aplicação está pronta a usar.");
      App.go("#/inicio");
    });
  }

  /* ------------------------------- ações --------------------------- */
  Actions["list-add"] = function (key) {
    if (!App.isAdmin()) { UI.toast("Apenas administradores editam listas.", "err"); return; }
    openListOptionForm(key, null);
  };
  Actions["list-edit"] = function (id) {
    if (!App.isAdmin()) { UI.toast("Apenas administradores editam listas.", "err"); return; }
    var it = Store.listItem(id); if (!it) return;
    openListOptionForm(it.key, id);
  };
  Actions["list-del"] = function (id) {
    if (!App.isAdmin()) { UI.toast("Apenas administradores editam listas.", "err"); return; }
    var db = Store.db();
    var it = Store.listItem(id); if (!it) return;
    var use = usageOf(it);
    if (use > 0) { UI.toast("Não é possível eliminar: a opção está em uso (" + use + ").", "err"); return; }
    UI.confirm({ title: "Eliminar opção", message: "\"" + it.name + "\" será removida desta lista.", confirmLabel: "Eliminar", danger: true })
      .then(function (ok) {
        if (!ok) return;
        db.lists = db.lists.filter(function (x) { return x.id !== id; });
        Store.save(); App.onData("Opção eliminada."); App.render();
      });
  };
  Actions["list-up"] = function (id) {
    if (!App.isAdmin()) return;
    var db = Store.db();
    var it = Store.listItem(id); if (!it) return;
    var arr = Store.listValues(it.key);
    var i = arr.findIndex(function (x) { return x.id === id; });
    if (i < 0) return;
    var target = i === 0 ? arr[arr.length - 1] : arr[i - 1];
    var tmp = it.order; it.order = target.order; target.order = tmp;
    // reordena sempre de forma estável
    Store.listValues(it.key).forEach(function (x, idx) { x.order = idx; });
    Store.save(); App.render();
  };

  Actions["cfg-save"] = function () {
    var cfg = Store.db().config;
    function val(name) { var el = document.querySelector('[name="' + name + '"]'); return el ? el.value : ""; }
    cfg.company = val("company") || cfg.company;
    cfg.slogan = val("slogan");
    cfg.nif = val("nif");
    cfg.sector = val("sector");
    cfg.address = val("address");
    cfg.city = val("city");
    cfg.country = val("country");
    cfg.email = val("email");
    cfg.phone = val("phone");
    cfg.website = val("website");
    cfg.currency = val("currency") || cfg.currency;
    cfg.vatDefault = Store.num(val("vatDefault")) / 100;
    cfg.paymentTerm = Store.num(val("paymentTerm"));
    cfg.refYear = Store.num(val("refYear")) || new Date().getFullYear();
    cfg.monthlyTarget = Store.num(val("monthlyTarget"));
    cfg.payrollPct = Store.num(val("payrollPct")) / 100;
    cfg.alertDays = Store.num(val("alertDays")) || 3;
    var credit = document.querySelector('[name="creditAuthorization"]');
    cfg.creditAuthorization = credit ? credit.checked : true;
    Store.save();
    UI.toast("Configuração guardada.");
    App.render();
  };

  Actions["backup-download"] = downloadBackup;
  Actions["backup-restore"] = restoreBackup;
  Actions["wipe"] = wipeAll;
  Actions["seed-reset"] = function () {
    UI.confirm({
      title: "Recarregar dados de exemplo",
      message: "Todos os dados atuais são substituídos pelos dados de demonstração da planilha.",
      confirmLabel: "Recarregar", danger: true
    }).then(function (ok) {
      if (!ok) return;
      Store.resetToSeed();
      App.session = App.loadSession();
      App.onData("Dados de exemplo restaurados.");
      App.go("#/inicio");
    });
  };

  window.Views.lists = lists;
  window.Views.settings = settings;
})();
