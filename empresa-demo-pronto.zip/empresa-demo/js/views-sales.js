/* ============================================================
   VIEWS — Vendas, cobranças, recibos e caixa (POS)
   ============================================================ */
(function () {
  "use strict";

  var money = Store.money;

  function clientName(id) {
    var c = Store.db().clients.find(function (x) { return x.id === id; });
    return c ? c.name : "Consumidor final";
  }
  function clientObj(id) { return Store.db().clients.find(function (x) { return x.id === id; }) || null; }
  function sellerName(id) {
    var e = Store.db().employees.find(function (x) { return x.id === id; });
    return e ? e.name : "—";
  }
  function methodName(id) { return Store.listName("paymentMethod", id, "—"); }

  /* ------------------------------------------------------------------
     LISTA DE VENDAS
  ------------------------------------------------------------------ */
  function sales() {
    var db = Store.db();
    var f = App.salesFilter || (App.salesFilter = { status: "Todas", q: "", clientId: "", period: "all", sort: "recent" });
    var list = db.sales.slice().map(function (s) { return { s: s, t: Engine.saleTotals(s) }; });

    if (f.status === "Pendentes") list = list.filter(function (x) { return x.t.status === "Pendente"; });
    else if (f.status === "Pagas") list = list.filter(function (x) { return x.t.status === "Paga"; });
    else if (f.status === "Em atraso") list = list.filter(function (x) { return x.t.status === "Pendente" && x.t.overdueDays > 0; });
    else if (f.status === "Canceladas") list = list.filter(function (x) { return x.t.status === "Cancelada"; });

    if (f.clientId) list = list.filter(function (x) { return x.s.clientId === f.clientId; });
    if (f.period === "month") {
      var now = new Date();
      var pre = now.getFullYear() + "-" + String(now.getMonth() + 1).padStart(2, "0");
      list = list.filter(function (x) { return x.s.date && x.s.date.slice(0, 7) === pre; });
    } else if (f.period === "year") {
      list = list.filter(function (x) { return x.s.date && x.s.date.slice(0, 4) === String(db.config.refYear); });
    }
    if (f.q) {
      var q = f.q.toLowerCase();
      list = list.filter(function (x) {
        return (x.s.id || "").toLowerCase().indexOf(q) >= 0 ||
          clientName(x.s.clientId).toLowerCase().indexOf(q) >= 0 ||
          (x.s.items || []).some(function (i) { return (i.name || "").toLowerCase().indexOf(q) >= 0; });
      });
    }
    list.sort(function (a, b) {
      if (f.sort === "amount") return b.t.total - a.t.total;
      if (f.sort === "oldest") return a.s.date < b.s.date ? -1 : 1;
      return a.s.date > b.s.date ? -1 : 1;
    });

    var totals = { net: 0, total: 0, balance: 0, count: 0 };
    list.forEach(function (x) {
      if (x.t.status === "Cancelada") return;
      totals.net += x.t.net; totals.total += x.t.total; totals.balance += x.t.balance; totals.count++;
    });

    var tabs = ["Todas", "Pendentes", "Em atraso", "Pagas", "Canceladas"].map(function (s) {
      return '<button data-act="sales-filter" data-id="' + s + '" aria-pressed="' + (f.status === s) + '">' + s + "</button>";
    }).join("");

    var head = V.head("Vendas", totals.count + " vendas · " + money(totals.net) + " faturado sem IVA",
      '<button class="btn ghost" data-nav="#/pdv">' + UI.icon("shopping-cart", 17) + " Caixa</button>" +
      '<button class="btn primary" data-act="sale-new">' + UI.icon("plus", 17) + " Nova venda</button>");

    var filters = '<div class="vstack" style="margin-bottom:12px"><div class="search">' + UI.icon("search", 18) +
      '<input placeholder="Pesquisar por nº, cliente ou item" value="' + UI.esc(f.q) + '" data-act="sales-search"></div>' +
      '<div class="hstack">' +
      '<select class="select" style="min-height:38px;font-size:12.5px;border-radius:999px;padding:8px 32px 8px 13px;width:auto" data-act="sales-client">' +
      '<option value="">Todos os clientes</option>' +
      db.clients.map(function (c) { return '<option value="' + c.id + '"' + (f.clientId === c.id ? " selected" : "") + ">" + UI.esc(c.name) + "</option>"; }).join("") +
      "</select>" +
      '<select class="select" style="min-height:38px;font-size:12.5px;border-radius:999px;padding:8px 32px 8px 13px;width:auto" data-act="sales-period">' +
      ["all:Todo o período", "month:Este mês", "year:Este ano"].map(function (o) {
        var p = o.split(":");
        return '<option value="' + p[0] + '"' + (f.period === p[0] ? " selected" : "") + ">" + p[1] + "</option>";
      }).join("") + "</select>" +
      '<select class="select" style="min-height:38px;font-size:12.5px;border-radius:999px;padding:8px 32px 8px 13px;width:auto" data-act="sales-sort">' +
      ["recent:Mais recentes", "oldest:Mais antigas", "amount:Maior valor"].map(function (o) {
        var p = o.split(":");
        return '<option value="' + p[0] + '"' + (f.sort === p[0] ? " selected" : "") + ">" + p[1] + "</option>";
      }).join("") + "</select></div>" +
      '<div class="tabs" style="padding-bottom:0">' + tabs + "</div></div>";

    var summary = '<div class="grid cols-3" style="margin-bottom:14px">' +
      V.kpi("Faturado s/IVA", money(totals.net), "accent-lime") +
      V.kpi("Total c/IVA", money(totals.total)) +
      V.kpi("Saldo em dívida", money(totals.balance), totals.balance > 0 ? "accent-orange" : "") + "</div>";

    var rowsHTML = list.length
      ? '<div class="group">' + list.map(function (x) { return V.saleRow(x.s); }).join("") + "</div>"
      : UI.emptyState("receipt", f.q ? "Nenhuma venda corresponde à pesquisa." : "Ainda não há vendas neste filtro.",
        '<button class="btn primary" data-act="sale-new">Registar venda</button>');

    App.afterRender = function () {
      var inp = document.querySelector('[data-act="sales-search"]');
      if (inp) {
        inp.addEventListener("input", UI.debounce(function () {
          f.q = inp.value;
          App.render();
          var again = document.querySelector('[data-act="sales-search"]');
          if (again) { again.focus(); again.setSelectionRange(again.value.length, again.value.length); }
        }, 260));
      }
    };

    return '<div class="view">' + head + filters + summary + rowsHTML + "</div>";
  }

  /* ------------------------------------------------------------------
     DETALHE DE VENDA
  ------------------------------------------------------------------ */
  function saleDetail(id) {
    var db = Store.db();
    var s = db.sales.find(function (x) { return x.id === id; });
    if (!s) return Views.notFound();
    var t = Engine.saleTotals(s);
    var c = clientObj(s.clientId);
    var pays = Engine.paymentsOf(s.id);

    var head = '<div class="page-head"><div class="titles">' +
      '<button class="pill-note" data-nav="#/vendas" style="margin-bottom:8px">' + UI.icon("chevron-left", 14) + " Vendas</button>" +
      '<div class="h1">' + s.id + '</div><div class="sub">' + Store.dateLong(s.date) + " · " + UI.esc(sellerName(s.sellerId)) + "</div></div>" +
      '<div class="btn-row">' +
      '<button class="btn ghost" data-act="sale-receipt" data-id="' + s.id + '">' + UI.icon("printer", 16) + " Recibo</button>" +
      '<button class="btn primary" data-act="sale-payment" data-id="' + s.id + '"' + (t.status === "Paga" || t.status === "Cancelada" ? " disabled" : "") + ">" +
      UI.icon("banknote", 16) + " Cobrar</button></div></div>";

    var hero = '<div class="detail-hero"><div class="top">' +
      '<div><div class="eyebrow">Total com IVA</div><div class="amt">' + money(t.total) + "</div>" +
      '<div class="hstack" style="margin-top:10px">' + V.saleStatus(t) +
      (t.overdueDays > 0 ? '<span class="chip red">' + t.overdueDays + " dias de atraso</span>" : "") + "</div></div>" +
      '<div class="right"><div class="eyebrow">Saldo</div><div class="amt" style="font-size:20px;color:' +
      (t.balance > 0 ? "var(--orange)" : "var(--green)") + '">' + money(t.balance) + "</div>" +
      '<div class="tiny muted">pago ' + money(t.paid) + "</div></div></div>" +
      '<div class="divider"></div><div class="kv">' +
      kv("Cliente", c ? '<a href="#/clientes/' + c.id + '" style="color:var(--lime)">' + UI.esc(c.name) + "</a>" : "Consumidor final") +
      kv("Vendedor", UI.esc(sellerName(s.sellerId))) +
      kv("Forma de pagamento", UI.esc(methodName(s.paymentMethod))) +
      kv("Vencimento", Store.dateLong(s.dueDate) + (t.overdueDays > 0 ? ' <span class="chip red">' + t.overdueDays + " dias</span>" : "")) +
      "</div></div>";

    var items = '<div class="card"><div class="card-head"><div class="title">Itens (' + (s.items || []).length + ")</div>" +
      '<span class="pill-note">' + t.qty + " un.</span></div>" +
      '<div class="rows">' + (s.items || []).map(function (ln) {
        var net = Store.num(ln.qty) * Store.num(ln.price) * (1 - Store.num(ln.discount));
        var vat = net * Store.num(ln.vatRate);
        return '<div class="row" style="align-items:flex-start">' +
          '<div class="tile">' + UI.icon("box", 18) + "</div>" +
          '<div class="body"><div class="name">' + UI.esc(ln.name) + "</div>" +
          '<div class="meta">' + ln.qty + " × " + money(ln.price) +
          (ln.discount ? " − " + Store.pct(ln.discount, 0) : "") + " · IVA " + Store.pct(ln.vatRate, 0) +
          " · custo " + money(ln.cost) + "</div></div>" +
          '<div class="end"><div class="amount">' + money(net + vat) + '</div><div class="tiny muted">' + money(net) + " s/IVA</div></div></div>";
      }).join("") + "</div>" +
      '<div class="divider"></div><div class="kv">' +
      kv("Subtotal sem IVA", money(t.net)) +
      kv("IVA", money(t.vat)) +
      kv("Total com IVA", "<b>" + money(t.total) + "</b>") +
      '<div class="it sep"><span class="k">Custo das vendas</span><span class="v">' + money(t.cost) + "</span></div>" +
      '<div class="it"><span class="k">Lucro bruto</span><span class="v" style="color:var(--green)">' + money(t.profit) +
      " · " + Store.pct(t.margin) + "</span></div></div></div>";

    var payments = '<div class="card"><div class="card-head"><div class="title">Cobranças</div>' +
      '<button class="btn sm soft" data-act="sale-payment" data-id="' + s.id + '"' +
      (t.status === "Paga" || t.status === "Cancelada" ? " disabled" : "") + ">+ Pagamento</button></div>" +
      (pays.length ? '<div class="rows">' + pays.map(function (p) {
        return '<div class="row"><div class="tile green">' + UI.icon("check-circle", 18) + "</div>" +
          '<div class="body"><div class="name">' + money(p.amount) + '</div><div class="meta">' +
          UI.esc(methodName(p.method)) + " · " + Store.dateShort(p.date) + (p.notes ? " · " + UI.esc(p.notes) : "") + "</div></div>" +
          '<div class="end"><button class="btn-icon" data-act="payment-delete" data-id="' + p.id + '" aria-label="Remover">' + UI.icon("trash", 15) + "</button></div></div>";
      }).join("") + "</div>" : '<p class="small muted">Sem pagamentos registados. A venda está ' + (t.status === "Cancelada" ? "cancelada." : "totalmente em dívida.") + "</p>") + "</div>";

    var notes = (s.notes ? '<div class="card"><div class="card-head"><div class="title">Notas</div></div><p class="small muted">' + UI.esc(s.notes) + "</p></div>" : "");

    var actions = '<div class="btn-row" style="margin-top:14px">' +
      (t.status !== "Cancelada" ?
        '<button class="btn ghost" data-act="sale-edit" data-id="' + s.id + '">' + UI.icon("edit", 16) + " Editar</button>" +
        '<button class="btn danger" data-act="sale-cancel" data-id="' + s.id + '">' + UI.icon("x", 16) + " Cancelar venda</button>"
        : '<button class="btn ghost" data-act="sale-reactivate" data-id="' + s.id + '">Reativar venda</button>') +
      '<button class="btn ghost" data-act="sale-duplicate" data-id="' + s.id + '">' + UI.icon("copy", 16) + " Duplicar</button></div>";

    return '<div class="view">' + head + hero + '<div class="two-col"><div class="col">' + items + notes + "</div>" +
      '<div class="col">' + payments + actions + "</div></div></div>";
  }

  function kv(k, v) { return '<div class="it"><span class="k">' + k + '</span><span class="v">' + v + "</span></div>"; }

  /* ------------------------------------------------------------------
     EDITOR DE VENDA
  ------------------------------------------------------------------ */
  function openSaleEditor(saleId, preset) {
    var db = Store.db();
    var editing = saleId ? db.sales.find(function (x) { return x.id === saleId; }) : null;
    var user = App.currentUser();
    var model;

    if (editing) {
      model = JSON.parse(JSON.stringify(editing));
    } else {
      model = {
        id: null, date: Store.todayISO(),
        clientId: (preset && preset.clientId) || "",
        sellerId: (user && user.id) || "",
        paymentMethod: "",
        dueDate: Store.addDays(Store.todayISO(), Store.num(db.config.paymentTerm, 30)),
        notes: "", items: (preset && preset.items) ? JSON.parse(JSON.stringify(preset.items)) : [],
        state: "Pendente"
      };
      if (!model.items.length) model.items.push(blankLine());
      if (preset && preset.cartId) model.cartId = preset.cartId;
    }

    function blankLine() {
      return { catalogId: "", name: "", qty: 1, price: 0, discount: 0, vatRate: Store.num(db.config.vatDefault), cost: 0, unitId: "", typeId: "" };
    }

    function lineNet(ln) { return Store.num(ln.qty) * Store.num(ln.price) * (1 - Store.num(ln.discount)); }
    function totals() {
      var net = 0, vat = 0, cost = 0;
      model.items.forEach(function (ln) { var n = lineNet(ln); net += n; vat += n * Store.num(ln.vatRate); cost += Store.num(ln.qty) * Store.num(ln.cost); });
      return { net: Store.round2(net), vat: Store.round2(vat), total: Store.round2(net + vat), cost: Store.round2(cost), profit: Store.round2(net - cost) };
    }

    var fields = [
      { k: "clientId", label: "Cliente", type: "select", options: V.clientOptions(), required: true, blankLabel: "— Selecione o cliente —" },
      { k: "date", label: "Data da venda", type: "date", required: true },
      { k: "sellerId", label: "Vendedor", type: "select", options: V.employeeOptions(true) },
      { k: "paymentMethod", label: "Forma de pagamento", type: "select", options: UI.optsFromList("paymentMethod", "— Definir depois —") },
      { k: "dueDate", label: "Vencimento", type: "date", help: "Sugerido: data + prazo padrão (" + db.config.paymentTerm + " dias)." },
      { k: "notes", label: "Notas", type: "textarea", full: true }
    ];

    var ov = UI.openSheet(
      '<div class="sheet-head"><div class="ttl"><h2>' + (editing ? "Editar venda " + editing.id : "Nova venda") + "</h2>" +
      "<p>Preços, custos e IVA são copiados no momento da venda.</p></div>" +
      '<button class="icon-btn ghost" data-x="1">' + UI.icon("x", 18) + "</button></div>" +
      '<div class="sheet-body"><div class="vstack" id="saleBody"></div></div>' +
      '<div class="sheet-foot"><button class="btn ghost" data-cancel="1">Cancelar</button>' +
      '<button class="btn primary" data-save="1">' + (editing ? "Guardar alterações" : "Registar venda") + "</button></div>",
      "wide");

    var body = ov.querySelector("#saleBody");

    function fieldHTML(f) { return UI.fieldHTML(f, model[f.k]); }

    function linesHTML() {
      return '<div class="card tight" style="background:var(--card-2)"><div class="card-head" style="margin-bottom:10px">' +
        '<div class="title">Itens da venda</div><span class="pill-note">' + model.items.length + " linha(s)</span></div>" +
        '<div class="lines">' + model.items.map(function (ln, i) {
          var ci = db.catalog.find(function (c) { return c.id === ln.catalogId; });
          var info = ci ? Engine.catalogInfo(ci) : null;
          var stockInfo = ci && ci.stockItemId ? Engine.stockOf(ci.stockItemId) : null;
          var net = lineNet(ln);
          return '<div class="line-card" data-line="' + i + '">' +
            '<div class="top"><span class="num">' + (i + 1) + "</span>" +
            '<div style="flex:1;min-width:0"><select class="select" data-l="' + i + '" data-k="catalogId">' +
            '<option value="">— Serviço / produto —</option>' +
            db.catalog.filter(function (c) { return c.active !== false; }).map(function (c) {
              return '<option value="' + c.id + '"' + (c.id === ln.catalogId ? " selected" : "") + ">" + UI.esc(c.name) + "</option>";
            }).join("") + "</select></div>" +
            '<button class="btn-icon" data-act="sale-line-remove" data-id="' + i + '" aria-label="Remover linha">' + UI.icon("trash", 15) + "</button></div>" +
            '<div class="gridl">' +
            '<div><div class="lbl">Qtd</div><input class="input" type="number" min="0" step="0.01" inputmode="decimal" value="' + ln.qty + '" data-l="' + i + '" data-k="qty"></div>' +
            '<div><div class="lbl">Preço s/IVA</div><input class="input" type="number" min="0" step="0.01" inputmode="decimal" value="' + ln.price + '" data-l="' + i + '" data-k="price"></div>' +
            '<div><div class="lbl">Desc. %</div><input class="input" type="number" min="0" max="100" step="1" inputmode="decimal" value="' + Store.round2(ln.discount * 100) + '" data-l="' + i + '" data-k="discount"></div>' +
            '<div><div class="lbl">IVA</div><select class="select" data-l="' + i + '" data-k="vatRate">' +
            '<option value="default"' + (ln.vatRate === "default" ? " selected" : "") + ">Padrão (" + Store.pct(db.config.vatDefault, 0) + ")</option>" +
            Store.listValues("vatRate").map(function (v) {
              return '<option value="' + v.meta.rate + '"' + (String(v.meta.rate) === String(ln.vatRate) ? " selected" : "") + ">" + v.name + "</option>";
            }).join("") + "</select></div></div>" +
            '<div class="line-total"><span>Subtotal <b data-subtotal="' + i + '">' + money(net) + "</b> · custo " + money(Store.num(ln.qty) * Store.num(ln.cost)) +
            " · lucro " + money(net - Store.num(ln.qty) * Store.num(ln.cost)) + "</span>" +
            (info ? '<span class="' + (stockInfo && stockInfo.qty < Store.num(ln.qty) * info.stockConsumption ? "chip red" : "chip") + '">' +
              (stockInfo ? "stock " + stockInfo.qty : "margem " + Store.pct(info.margin)) + "</span>" : "") +
            "</div></div>";
        }).join("") + "</div>" +
        '<button class="btn ghost sm" data-act="sale-line-add" style="margin-top:10px">' + UI.icon("plus", 15) + " Adicionar item</button></div>";
    }

    function totalsHTML() {
      var t = totals();
      return '<div class="card tight"><div class="kv">' +
        kv("Subtotal s/IVA", money(t.net)) +
        kv("IVA", money(t.vat)) +
        kv("Total c/IVA", "<b>" + money(t.total) + "</b>") +
        '<div class="it sep"><span class="k">Custo das vendas</span><span class="v">' + money(t.cost) + "</span></div>" +
        '<div class="it"><span class="k">Lucro bruto</span><span class="v" style="color:var(--green)">' + money(t.profit) +
        " · " + Store.pct(t.net ? t.profit / t.net : 0) + "</span></div></div>" +
        '<p class="tiny muted" style="margin-top:8px">A venda fica pendente até ser totalmente paga. Registe cobranças no detalhe da venda.</p></div>';
    }

    function paint(full) {
      if (full) {
        body.innerHTML = '<div class="card tight"><div class="form"><div class="grid2">' +
          fieldHTML(fields[0]) + fieldHTML(fields[1]) + fieldHTML(fields[2]) + fieldHTML(fields[3]) +
          fieldHTML(fields[4]) + "</div>" + fieldHTML(fields[5]) + "</div></div>" + linesHTML() + '<div id="saleTotals"></div>';
        body.querySelector("#saleTotals").innerHTML = totalsHTML();
        bind();
      } else {
        body.querySelector("#saleTotals").innerHTML = totalsHTML();
      }
    }

    function readLine(idx, key, el) {
      var ln = model.items[idx];
      if (key === "qty" || key === "price") ln[key] = Store.num(el.value);
      else if (key === "discount") ln[key] = Store.num(el.value) / 100;
      else if (key === "vatRate") ln[key] = el.value === "default" ? Store.num(db.config.vatDefault) : Store.num(el.value);
      else if (key === "catalogId") {
        var ci = db.catalog.find(function (c) { return c.id === el.value; });
        if (!ci) { model.items[idx] = blankLine(); return; }
        ln.catalogId = ci.id; ln.name = ci.name;
        ln.price = Store.num(ci.price);
        ln.cost = Engine.catalogEffectiveCost(ci);
        ln.vatRate = Engine.catalogVat(ci);
        ln.unitId = ci.unitId; ln.typeId = ci.typeId;
        if (!ln.qty) ln.qty = 1;
      }
    }

    var lastDate = model.date;
    function bind() {
      body.querySelectorAll("[data-l]").forEach(function (el) {
        el.addEventListener("change", function () {
          var idx = Number(el.getAttribute("data-l")), key = el.getAttribute("data-k");
          readLine(idx, key, el);
          if (key === "catalogId") { paint(true); }
          else {
            var ln = model.items[idx];
            var sub = body.querySelector('[data-subtotal="' + idx + '"]');
            if (sub) sub.textContent = money(lineNet(ln));
            paint(false);
          }
        });
        el.addEventListener("input", function () {
          if (el.tagName === "SELECT") return;
          var idx = Number(el.getAttribute("data-l")), key = el.getAttribute("data-k");
          readLine(idx, key, el);
          var ln = model.items[idx];
          var sub = body.querySelector('[data-subtotal="' + idx + '"]');
          if (sub) sub.textContent = money(lineNet(ln));
          paint(false);
        });
      });
      body.querySelectorAll(".form input,.form select,.form textarea").forEach(function (el) {
        var nm = el.getAttribute("name");
        if (!nm) return;
        var handler = function () {
          if (nm === "date" && el.value) {
            var prevDefault = Store.addDays(lastDate, Store.num(db.config.paymentTerm, 30));
            lastDate = el.value;
            model.date = el.value;
            var due = body.querySelector('[name="dueDate"]');
            if (due && (!model.dueDate || model.dueDate === prevDefault)) {
              model.dueDate = Store.addDays(el.value, Store.num(db.config.paymentTerm, 30));
              due.value = model.dueDate;
            }
            return;
          }
          model[nm] = el.value;
        };
        el.addEventListener("change", handler);
        el.addEventListener("input", handler);
      });
      body.querySelectorAll('[data-act="sale-line-remove"]').forEach(function (b) {
        b.onclick = function () {
          var i = Number(b.getAttribute("data-id"));
          if (model.items.length <= 1) { UI.toast("A venda precisa de pelo menos um item.", "err"); return; }
          model.items.splice(i, 1); paint(true);
        };
      });
      var add = body.querySelector('[data-act="sale-line-add"]');
      if (add) add.onclick = function () { model.items.push(blankLine()); paint(true); };
    }

    paint(true);

    ov.querySelector("[data-x]").onclick = function () { UI.closeSheet(); };
    ov.querySelector("[data-cancel]").onclick = function () { UI.closeSheet(); };
    ov.querySelector("[data-save]").onclick = function () {
      if (!model.clientId) { UI.toast("Escolha o cliente da venda.", "err"); return; }
      var valid = model.items.filter(function (l) { return l.catalogId && Store.num(l.qty) > 0; });
      if (!valid.length) { UI.toast("Adicione pelo menos um item com quantidade.", "err"); return; }
      model.items = valid;
      if (!model.date) { UI.toast("Indique a data da venda.", "err"); return; }
      if (!model.dueDate) model.dueDate = Store.addDays(model.date, Store.num(db.config.paymentTerm, 30));

      if (editing) {
        var alreadyPaid = Engine.saleTotals(editing).paid;
        if (t.total < alreadyPaid - 0.005) {
          UI.toast("O total (" + money(t.total) + ") é inferior ao já recebido (" + money(alreadyPaid) +
            "). Remova pagamentos antes de reduzir a venda.", "err");
          return;
        }
      }

      // stock: bloquear negativos sem autorização do administrador
      var problem = stockProblem(model);
      if (problem) {
        if (!App.isAdmin()) { UI.toast(problem + " Autorização de administrador necessária.", "err"); return; }
        UI.confirm({
          title: "Stock insuficiente",
          message: problem + " Pretende continuar? O stock ficará negativo até à regularização.",
          confirmLabel: "Continuar",
          danger: true
        }).then(function (ok) {
          if (ok) { UI.closeSheet(); persist(); }
        });
        return;
      }
      UI.closeSheet();
      persist();
    };

    function stockProblem(m) {
      var byItem = {};
      m.items.forEach(function (ln) {
        var ci = db.catalog.find(function (c) { return c.id === ln.catalogId; });
        if (!ci || !ci.stockItemId) return;
        var st = Engine.stockOf(ci.stockItemId);
        if (!st) return;
        byItem[ci.stockItemId] = (byItem[ci.stockItemId] || 0) + Store.num(ln.qty) * (Store.num(ci.stockConsumption) || 1);
      });
      var msg = null;
      Object.keys(byItem).forEach(function (sid) {
        var st = Engine.stockOf(sid);
        var item = db.stock.find(function (s) { return s.id === sid; });
        // se for edição, o valor anterior já está contabilizado — margem de tolerância
        if (msg) return;
        if (st && byItem[sid] > st.qty + 0.0001) {
          msg = "O item \"" + item.name + "\" só tem " + st.qty + " disponíveis (necessário " + byItem[sid] + ").";
        }
      });
      return msg;
    }

    function persist() {
      var t = totals();
      var sale;
      if (editing) {
        sale = editing;
        sale.date = model.date; sale.clientId = model.clientId; sale.sellerId = model.sellerId;
        sale.paymentMethod = model.paymentMethod; sale.dueDate = model.dueDate;
        sale.notes = model.notes; sale.items = model.items;
      } else {
        sale = {
          id: Store.nextId("sale", "VD-", 4),
          date: model.date, clientId: model.clientId, sellerId: model.sellerId,
          paymentMethod: model.paymentMethod, dueDate: model.dueDate,
          notes: model.notes, items: model.items, state: "Pendente",
          priceList: "Tabela padrão"
        };
        db.sales.push(sale);
        if (model.cartId) db.carts = db.carts.filter(function (c) { return c.id !== model.cartId; });
      }
      Store.save();
      App.onData(editing ? "Venda atualizada." : "Venda " + sale.id + " registada · " + money(t.total));
      App.go("#/vendas/" + sale.id);
    }
  }

  /* ------------------------------------------------------------------
     PAGAMENTO
  ------------------------------------------------------------------ */
  function openPayment(saleId) {
    var db = Store.db();
    var s = db.sales.find(function (x) { return x.id === saleId; });
    if (!s) return;
    var t = Engine.saleTotals(s);

    var fields = [
      { k: "date", label: "Data do pagamento", type: "date", required: true, value: Store.todayISO() },
      { k: "amount", label: "Valor recebido", type: "money", required: true, value: t.balance, help: "Saldo em dívida: " + money(t.balance) },
      { k: "method", label: "Forma de pagamento", type: "select", required: true, options: UI.optsFromList("paymentMethod"), value: s.paymentMethod || "" },
      { k: "notes", label: "Notas", type: "text", full: true, placeholder: "Opcional" },
      { k: "static", type: "static", html: "Pagamento total ou parcial. Pode registar vários pagamentos na mesma venda, com formas diferentes." }
    ];

    UI.form({
      title: "Registar cobrança",
      subtitle: s.id + " · " + clientName(s.clientId) + " · total " + money(t.total),
      fields: fields,
      values: { date: Store.todayISO(), amount: t.balance, method: s.paymentMethod || "" },
      submitLabel: "Registar pagamento",
      validate: function (v) {
        if (Store.num(v.amount) <= 0) return "O valor deve ser superior a zero.";
        if (Store.num(v.amount) > t.balance + 0.005) return "O valor excede o saldo em dívida (" + money(t.balance) + ").";
        return null;
      },
      onSubmit: function (v) {
        db.payments.push({
          id: Store.nextId("payment", "PG-", 4),
          saleId: s.id, date: v.date, amount: Store.round2(Store.num(v.amount)),
          method: v.method, notes: v.notes || ""
        });
        var nt = Engine.saleTotals(s);
        s.state = nt.balance <= 0 ? "Paga" : "Pendente";
        Store.save();
        App.onData("Pagamento registado · saldo " + money(nt.balance));
        App.render();
      }
    });
  }

  /* ------------------------------------------------------------------
     RECIBO
  ------------------------------------------------------------------ */
  function openReceipt(saleId) {
    var db = Store.db(), cfg = db.config;
    var s = db.sales.find(function (x) { return x.id === saleId; });
    if (!s) return;
    var t = Engine.saleTotals(s);
    var c = clientObj(s.clientId);
    var pays = Engine.paymentsOf(s.id);

    var html = '<div class="receipt" id="receiptBody">' +
      "<h3>" + UI.esc(cfg.company) + "</h3>" +
      '<div style="font-size:11px;color:#5d6875">' + UI.esc(cfg.address) + " · " + UI.esc(cfg.city) + "<br>NUIT " + UI.esc(cfg.nif) +
      (cfg.phone ? " · " + UI.esc(cfg.phone) : "") + "</div>" +
      '<div class="sep"></div>' +
      '<div class="tr"><span>Recibo da venda</span><b>' + s.id + "</b></div>" +
      '<div class="tr"><span>Data</span><span>' + Store.dateLong(s.date) + "</span></div>" +
      '<div class="tr"><span>Cliente</span><span>' + UI.esc(c ? c.name : "Consumidor final") + "</span></div>" +
      (c && c.nuit ? '<div class="tr"><span>NUIT</span><span>' + UI.esc(c.nuit) + "</span></div>" : "") +
      '<div class="tr"><span>Vendedor</span><span>' + UI.esc(sellerName(s.sellerId)) + "</span></div>" +
      '<div class="sep"></div>' +
      '<table><thead><tr><th>Descrição</th><th style="text-align:center">Qtd</th><th style="text-align:right">Preço</th><th style="text-align:right">Total</th></tr></thead><tbody>' +
      (s.items || []).map(function (ln) {
        var net = Store.num(ln.qty) * Store.num(ln.price) * (1 - Store.num(ln.discount));
        return "<tr><td>" + UI.esc(ln.name) + (ln.discount ? " (-" + Store.pct(ln.discount, 0) + ")" : "") +
          "<br><span style=\"font-size:9.5px;color:#6b7683\">IVA " + Store.pct(ln.vatRate, 0) + "</span></td>" +
          '<td style="text-align:center">' + ln.qty + "</td>" +
          '<td style="text-align:right">' + money(ln.price) + "</td>" +
          '<td style="text-align:right">' + money(net) + "</td></tr>";
      }).join("") + "</tbody></table>" +
      '<div class="sep"></div>' +
      '<div class="tr"><span>Subtotal s/IVA</span><span>' + money(t.net) + "</span></div>" +
      '<div class="tr"><span>IVA</span><span>' + money(t.vat) + "</span></div>" +
      '<div class="tr big"><span>Total</span><span>' + money(t.total) + "</span></div>" +
      '<div class="sep"></div>' +
      '<div class="tr"><span>Pago</span><span>' + money(t.paid) + "</span></div>" +
      '<div class="tr"><span>Saldo</span><span>' + money(t.balance) + "</span></div>" +
      (pays.length ? '<div style="margin-top:8px;font-size:10.5px;color:#5d6875">' + pays.map(function (p) {
        return UI.esc(methodName(p.method)) + " · " + Store.dateShort(p.date) + " · " + money(p.amount);
      }).join("<br>") + "</div>" : "") +
      '<div class="sep"></div>' +
      '<div style="text-align:center;font-size:10px;color:#6b7683">Obrigado pela sua preferência.<br>' +
      UI.esc(cfg.company) + " · " + UI.esc(cfg.website) + "</div></div>";

    var ov = UI.openSheet('<div class="sheet-head"><div class="ttl"><h2>Recibo ' + s.id + "</h2><p>Pronto para imprimir ou guardar em PDF.</p></div>" +
      '<button class="icon-btn ghost" data-x="1">' + UI.icon("x", 18) + "</button></div>" +
      '<div class="sheet-body">' + html + "</div>" +
      '<div class="sheet-foot"><button class="btn ghost" data-cancel="1">Fechar</button>' +
      '<button class="btn primary" data-print="1">' + UI.icon("printer", 16) + " Imprimir</button></div>", "");
    ov.querySelector("[data-x]").onclick = UI.closeSheet;
    ov.querySelector("[data-cancel]").onclick = UI.closeSheet;
    ov.querySelector("[data-print]").onclick = function () {
      var w = window.open("", "_blank");
      if (!w) { UI.toast("Permita janelas pop-up para imprimir.", "err"); return; }
      w.document.write('<!doctype html><html><head><title>Recibo ' + s.id + '</title><style>@page{margin:14mm}' +
        'body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;max-width:520px;margin:0 auto;padding:10px}' +
        '.receipt h3{margin:0 0 2px}.sep{border-top:1px dashed #b9c0c8;margin:12px 0}.tr{display:flex;justify-content:space-between;margin-top:4px;font-size:12.5px}' +
        '.tr.big{font-size:15px;font-weight:800;margin-top:8px}table{width:100%;border-collapse:collapse;font-size:11.5px}' +
        'table th{text-align:left;font-size:9.5px;text-transform:uppercase;color:#6b7683;padding-bottom:6px}table td{padding:4px 0;border-top:1px solid #eef1f4}' +
        "</style></head><body>" + html + "</body></html>");
      w.document.close();
      setTimeout(function () { w.print(); }, 250);
    };
  }

  /* ------------------------------------------------------------------
     CAIXA / POS
  ------------------------------------------------------------------ */
  function pos() {
    var db = Store.db();
    var st = App.pos || (App.pos = { cart: [], q: "", clientId: "", method: "", received: "", second: "", secondAmount: "", discount: 0 });
    var cat = db.catalog.filter(function (c) { return c.active !== false; });

    var filtered = cat;
    if (st.q) {
      var q = st.q.toLowerCase();
      filtered = cat.filter(function (c) { return c.name.toLowerCase().indexOf(q) >= 0; });
    }

    function lineTotal(ln) { return Store.num(ln.qty) * Store.num(ln.price) * (1 - Store.num(ln.discount)); }
    var net = st.cart.reduce(function (a, l) { return a + lineTotal(l); }, 0);
    net = Store.round2(net * (1 - Store.num(st.discount) / 100));
    var vat = 0;
    if (st.cart.length) {
      var grossVat = st.cart.reduce(function (a, l) { return a + lineTotal(l) * Store.num(l.vatRate); }, 0);
      vat = Store.round2(grossVat * (1 - Store.num(st.discount) / 100));
    }
    var total = Store.round2(net + vat);
    var received = Store.num(st.received);
    var secondAmt = Store.num(st.secondAmount);
    var paid = received + secondAmt;
    var change = Math.max(0, Store.round2(paid - total));
    var balance = Math.max(0, Store.round2(total - paid));

    var head = V.head("Caixa", "Venda rápida integrada com o catálogo e o stock",
      '<button class="btn ghost" data-act="pos-save-cart">' + UI.icon("save", 16) + " Guardar</button>" +
      '<button class="btn ghost" data-act="pos-carts">' + UI.icon("shopping-bag", 16) + " Carrinhos</button>", "#/vendas");

    /* catálogo */
    var catalogCard = '<div class="card"><div class="search" style="margin-bottom:12px">' + UI.icon("search", 18) +
      '<input placeholder="Pesquisar serviço ou produto" data-act="pos-search" value="' + UI.esc(st.q) + '"></div>' +
      '<div class="rows">' + (filtered.length ? filtered.map(function (c) {
        var info = Engine.catalogInfo(c);
        var stockTxt = c.stockItemId ? "stock " + (info.stockQty === null ? "—" : info.stockQty) : Store.listName("itemType", c.typeId);
        return '<button class="row" data-act="pos-add" data-id="' + c.id + '">' +
          '<div class="tile">' + UI.icon(c.stockItemId ? "package" : "file-text", 18) + "</div>" +
          '<div class="body"><div class="name">' + UI.esc(c.name) + "</div>" +
          '<div class="meta">' + UI.esc(stockTxt) + " · IVA " + Store.pct(info.vat, 0) + "</div></div>" +
          '<div class="end"><div class="amount">' + money(info.priceWithVat) + '</div><div class="tiny muted">' + money(c.price) + " s/IVA</div></div></button>";
      }).join("") : UI.emptyState("search", "Nenhum item encontrado.")) + "</div></div>";

    /* carrinho */
    var cartCard = '<div class="pos-cart"><div class="card-head"><div class="title">Carrinho</div>' +
      '<span class="pill-note">' + st.cart.length + " itens</span></div>" +
      (st.cart.length ? '<div class="rows">' + st.cart.map(function (ln, i) {
        return '<div class="cart-line">' +
          '<div style="flex:1;min-width:0"><div class="nm">' + UI.esc(ln.name) + '</div><div class="sb">' + money(ln.price) + " · IVA " + Store.pct(ln.vatRate, 0) + "</div></div>" +
          '<div class="qty-ctrl"><button data-act="pos-dec" data-id="' + i + '">−</button><span>' + ln.qty + "</span>" +
          '<button data-act="pos-inc" data-id="' + i + '">+</button></div>' +
          '<div class="amount sm" style="min-width:74px;text-align:right">' + money(lineTotal(ln)) + "</div>" +
          '<button class="btn-icon" data-act="pos-remove" data-id="' + i + '" aria-label="Remover">' + UI.icon("x", 14) + "</button></div>";
      }).join("") + "</div>" : UI.emptyState("shopping-cart", "Carrinho vazio. Toque num item do catálogo.")) +
      '<div class="pos-total"><div class="kv"><div class="it"><span class="k">Subtotal s/IVA</span><span class="v">' + money(net) + "</span></div>" +
      '<div class="it"><span class="k">IVA</span><span class="v">' + money(vat) + "</span></div>" +
      '<div class="it"><span class="k">Total c/IVA</span><span class="v big">' + money(total) + "</span></div></div></div>" +
      '<div style="margin-top:14px" class="form">' +
      '<div class="field"><label>Cliente</label><select class="select" data-act="pos-client">' +
      '<option value="">Consumidor final</option>' +
      db.clients.filter(function (c) { return c.state !== "Inativo"; }).map(function (c) {
        return '<option value="' + c.id + '"' + (st.clientId === c.id ? " selected" : "") + ">" + UI.esc(c.name) + "</option>";
      }).join("") + "</select></div>" +
      '<div class="grid2"><div class="field"><label>Desconto global %</label><input class="input" type="number" min="0" max="100" step="1" inputmode="decimal" data-act="pos-discount" value="' + st.discount + '"></div>' +
      '<div class="field"><label>Método principal</label><select class="select" data-act="pos-method">' +
      '<option value="">— Selecione —</option>' + UI.optsFromList("paymentMethod", null).map(function (o) {
        return '<option value="' + o.id + '"' + (st.method === o.id ? " selected" : "") + ">" + UI.esc(o.name) + "</option>";
      }).join("") + "</select></div></div>" +
      '<div class="grid2"><div class="field"><label>Valor recebido</label><input class="input" type="number" min="0" step="0.01" inputmode="decimal" data-act="pos-received" value="' + (st.received === "" ? "" : st.received) + '" placeholder="' + total.toFixed(2) + '"></div>' +
      '<div class="field"><label>2º método</label><select class="select" data-act="pos-second">' +
      '<option value="">— Nenhum —</option>' + UI.optsFromList("paymentMethod", null).map(function (o) {
        return '<option value="' + o.id + '"' + (st.second === o.id ? " selected" : "") + ">" + UI.esc(o.name) + "</option>";
      }).join("") + "</select></div></div>" +
      (st.second ? '<div class="field"><label>Valor no 2º método</label><input class="input" type="number" min="0" step="0.01" inputmode="decimal" data-act="pos-second-amount" value="' + st.secondAmount + '"></div>' : "") +
      "</div>" +
      '<div class="kv" style="margin-top:14px">' +
      '<div class="it"><span class="k">Recebido</span><span class="v" id="posPaid">' + money(paid) + "</span></div>" +
      '<div class="it"><span class="k">Troco</span><span class="v" id="posChange" style="color:var(--green)">' + money(change) + "</span></div>" +
      '<div class="it"><span class="k">Saldo pendente</span><span class="v" id="posBalance" style="color:' + (balance > 0 ? "var(--orange)" : "var(--text)") + '">' + money(balance) + "</span></div></div>" +
      (balance > 0 && !st.clientId ? '<div class="alert warn" style="margin-top:12px">' + UI.icon("alert-triangle", 17) +
        '<div class="txt">Para deixar <b>saldo em dívida</b> é obrigatório identificar o cliente e ter autorização de crédito.</div></div>' : "") +
      '<button class="btn primary lg block" style="margin-top:14px" data-act="pos-checkout"' + (st.cart.length ? "" : " disabled") + ">" +
      UI.icon("check-circle", 18) + ' <span id="posFinal">Finalizar venda · ' + money(total) + "</span></button>" +
      '<button class="btn ghost block sm" style="margin-top:8px" data-act="pos-clear">Limpar carrinho</button></div>';

    App.afterRender = function () {
      var inp = document.querySelector('[data-act="pos-search"]');
      if (inp) {
        inp.addEventListener("input", UI.debounce(function () {
          st.q = inp.value; App.render();
          var a = document.querySelector('[data-act="pos-search"]');
          if (a) { a.focus(); a.setSelectionRange(a.value.length, a.value.length); }
        }, 220));
      }
      function refreshTotals() {
        var netT = Store.round2(st.cart.reduce(function (a, l) { return a + l.qty * l.price * (1 - l.discount); }, 0) * (1 - Store.num(st.discount) / 100));
        var vatT = Store.round2(st.cart.reduce(function (a, l) { return a + l.qty * l.price * (1 - l.discount) * l.vatRate; }, 0) * (1 - Store.num(st.discount) / 100));
        var totalT = Store.round2(netT + vatT);
        var paidT = Store.round2(Store.num(st.received) + Store.num(st.secondAmount));
        var changeT = Math.max(0, Store.round2(paidT - totalT));
        var balT = Math.max(0, Store.round2(totalT - paidT));
        var set = function (id, txt) { var el2 = document.getElementById(id); if (el2) el2.textContent = txt; };
        set("posPaid", money(paidT));
        set("posChange", money(changeT));
        set("posBalance", money(balT));
        var pb = document.getElementById("posBalance"); if (pb) pb.style.color = balT > 0 ? "var(--orange)" : "var(--text)";
        set("posFinal", "Finalizar venda · " + money(totalT));
      }
      document.querySelectorAll('[data-act="pos-received"],[data-act="pos-second-amount"],[data-act="pos-discount"]').forEach(function (el) {
        el.addEventListener("input", function () {
          var act = el.getAttribute("data-act");
          if (act === "pos-received") st.received = el.value;
          if (act === "pos-second-amount") st.secondAmount = el.value;
          if (act === "pos-discount") st.discount = el.value;
          refreshTotals();
        });
      });
    };

    return '<div class="view">' + head + '<div class="pos-layout"><div class="col">' + catalogCard + "</div><div class=\"col\">" + cartCard + "</div></div></div>";
  }

  /* ------------------------------------------------------------------
     AÇÕES
  ------------------------------------------------------------------ */
  Actions["sale-new"] = function () { openSaleEditor(null); };
  Actions["sale-edit"] = function (id) { openSaleEditor(id); };
  Actions["sale-payment"] = function (id) { openPayment(id); };
  Actions["sale-receipt"] = function (id) { openReceipt(id); };
  Actions["sale-duplicate"] = function (id) {
    var s = Store.db().sales.find(function (x) { return x.id === id; });
    if (!s) return;
    openSaleEditor(null, { clientId: s.clientId, items: JSON.parse(JSON.stringify(s.items)) });
  };
  Actions["sale-cancel"] = function (id) {
    var db = Store.db();
    var s = db.sales.find(function (x) { return x.id === id; });
    if (!s) return;
    var t = Engine.saleTotals(s);
    UI.confirm({
      title: "Cancelar venda " + s.id,
      message: "A venda deixa de contar para os totais, stock e indicadores. Os pagamentos registados serão removidos." +
        (t.paid > 0 ? " Já foram recebidos " + money(t.paid) + "." : ""),
      confirmLabel: "Cancelar venda", danger: true
    }).then(function (ok) {
      if (!ok) return;
      s.state = "Cancelada";
      db.payments = db.payments.filter(function (p) { return p.saleId !== s.id; });
      Store.save();
      App.onData("Venda cancelada.");
      App.render();
    });
  };
  Actions["sale-reactivate"] = function (id) {
    var s = Store.db().sales.find(function (x) { return x.id === id; });
    if (!s) return;
    s.state = "Pendente";
    Store.save(); App.onData("Venda reativada como pendente."); App.render();
  };
  Actions["payment-delete"] = function (id) {
    var db = Store.db();
    var p = db.payments.find(function (x) { return x.id === id; });
    if (!p) return;
    UI.confirm({ title: "Remover pagamento", message: "O saldo da venda volta a aumentar.", confirmLabel: "Remover", danger: true })
      .then(function (ok) {
        if (!ok) return;
        db.payments = db.payments.filter(function (x) { return x.id !== id; });
        var s = db.sales.find(function (x) { return x.id === p.saleId; });
        if (s) { var t = Engine.saleTotals(s); s.state = t.balance <= 0 ? "Paga" : "Pendente"; }
        Store.save(); App.onData("Pagamento removido."); App.render();
      });
  };
  Actions["sales-filter"] = function (id) { App.salesFilter.status = id; App.render(); };

  document.addEventListener("change", function (e) {
    var f = App.salesFilter;
    if (!f || !e.target) return;
    if (e.target.getAttribute("data-act") === "sales-client") { f.clientId = e.target.value; App.render(); }
    if (e.target.getAttribute("data-act") === "sales-period") { f.period = e.target.value; App.render(); }
    if (e.target.getAttribute("data-act") === "sales-sort") { f.sort = e.target.value; App.render(); }
  });

  /* POS actions */
  Actions["pos-add"] = function (id) {
    var db = Store.db();
    var c = db.catalog.find(function (x) { return x.id === id; });
    if (!c) return;
    var st = App.pos;
    var existing = st.cart.find(function (l) { return l.catalogId === id; });
    if (!c.stockItemId) {
      // serviços podem repetir; produtos ligados a stock controlam quantidade
      if (existing && Store.listName("itemType", c.typeId) === "Produto") existing.qty += 1;
      else if (existing) existing.qty += 1;
      else st.cart.push({
        catalogId: c.id, name: c.name, qty: 1, price: Store.num(c.price), discount: 0,
        vatRate: Engine.catalogVat(c), cost: Engine.catalogEffectiveCost(c),
        unitId: c.unitId, typeId: c.typeId
      });
    } else {
      if (existing) existing.qty += 1;
      else st.cart.push({
        catalogId: c.id, name: c.name, qty: 1, price: Store.num(c.price), discount: 0,
        vatRate: Engine.catalogVat(c), cost: Engine.catalogEffectiveCost(c),
        unitId: c.unitId, typeId: c.typeId
      });
    }
    App.render();
  };
  Actions["pos-inc"] = function (i) { App.pos.cart[Number(i)].qty += 1; App.render(); };
  Actions["pos-dec"] = function (i) {
    var l = App.pos.cart[Number(i)];
    l.qty = Math.max(0, Store.round2(l.qty - 1));
    if (l.qty === 0) App.pos.cart.splice(Number(i), 1);
    App.render();
  };
  Actions["pos-remove"] = function (i) { App.pos.cart.splice(Number(i), 1); App.render(); };
  Actions["pos-clear"] = function () { App.pos.cart = []; App.pos.received = ""; App.pos.discount = 0; App.render(); };

  document.addEventListener("change", function (e) {
    if (!App.pos || !e.target) return;
    var a = e.target.getAttribute("data-act");
    if (a === "pos-client") { App.pos.clientId = e.target.value; App.render(); }
    if (a === "pos-method") { App.pos.method = e.target.value; App.render(); }
    if (a === "pos-second") { App.pos.second = e.target.value; App.render(); }
  });

  Actions["pos-checkout"] = function () {
    var db = Store.db(), st = App.pos;
    if (!st.cart.length) return;
    var net = Store.round2(st.cart.reduce(function (a, l) { return a + l.qty * l.price * (1 - l.discount); }, 0) * (1 - Store.num(st.discount) / 100));
    var vat = Store.round2(st.cart.reduce(function (a, l) { return a + l.qty * l.price * (1 - l.discount) * l.vatRate; }, 0) * (1 - Store.num(st.discount) / 100));
    var total = Store.round2(net + vat);
    var paid = Store.round2(Store.num(st.received) + Store.num(st.secondAmount));
    var change = Math.max(0, Store.round2(paid - total));
    var balance = Math.max(0, Store.round2(total - paid));

    if (!st.method) { UI.toast("Escolha a forma de pagamento principal.", "err"); return; }
    if (balance > 0 && !st.clientId) {
      UI.toast("Para vender a crédito, identifique o cliente.", "err"); return;
    }
    if (balance > 0 && !db.config.creditAuthorization) {
      UI.toast("A autorização de crédito está desativada na configuração.", "err"); return;
    }

    // stock
    var problem = null;
    st.cart.forEach(function (ln) {
      if (problem) return;
      var ci = db.catalog.find(function (c) { return c.id === ln.catalogId; });
      if (!ci || !ci.stockItemId) return;
      var s = Engine.stockOf(ci.stockItemId);
      var need = ln.qty * (Store.num(ci.stockConsumption) || 1);
      if (s && need > s.qty) {
        var it = db.stock.find(function (x) { return x.id === ci.stockItemId; });
        problem = "Stock insuficiente de " + it.name + " (" + s.qty + " disponíveis).";
      }
    });
    if (problem && !App.isAdmin()) { UI.toast(problem, "err"); return; }

    function finish() {
      var sale = {
        id: Store.nextId("sale", "VD-", 4),
        date: Store.todayISO(),
        clientId: st.clientId || null,
        sellerId: (App.currentUser() || {}).id || null,
        paymentMethod: st.method,
        dueDate: Store.addDays(Store.todayISO(), Store.num(db.config.paymentTerm, 30)),
        notes: st.discount ? "Desconto global de " + st.discount + "%" : "",
        items: st.cart, state: "Pendente", priceList: "Caixa"
      };
      if (st.discount) {
        sale.items = sale.items.map(function (l) {
          return Object.assign({}, l, { discount: l.discount + (1 - l.discount) * (Store.num(st.discount) / 100) });
        });
      }
      db.sales.push(sale);
      var t = Engine.saleTotals(sale);
      var paidT = Math.min(paid, t.total);
      if (paidT > 0.004) {
        db.payments.push({
          id: Store.nextId("payment", "PG-", 4),
          saleId: sale.id, date: Store.todayISO(), amount: paidT,
          method: st.method, notes: change > 0 ? "Troco " + money(change) : ""
        });
      }
      t = Engine.saleTotals(sale);
      sale.state = t.balance <= 0 ? "Paga" : "Pendente";
      Store.save();
      openReceipt(sale.id);
      UI.toast("Venda " + sale.id + " registada" + (change > 0 ? " · troco " + money(change) : "") + (t.balance > 0 ? " · saldo " + money(t.balance) : ""));
      App.pos = { cart: [], q: "", clientId: "", method: "", received: "", second: "", secondAmount: "", discount: 0 };
      App.render();
    }

    if (problem) {
      UI.confirm({ title: "Stock insuficiente", message: problem + " Continuar mesmo assim?", confirmLabel: "Continuar", danger: true })
        .then(function (ok) { if (ok) finish(); });
      return;
    }
    finish();
  };

  Actions["pos-save-cart"] = function () {
    var st = App.pos;
    if (!st.cart.length) { UI.toast("O carrinho está vazio.", "err"); return; }
    UI.form({
      title: "Guardar carrinho",
      subtitle: "Fica disponível para retomar mais tarde.",
      fields: [{ k: "name", label: "Nome do pedido", type: "text", required: true, placeholder: "Ex.: Orçamento — Clínica Vida Nova" }],
      submitLabel: "Guardar",
      onSubmit: function (v) {
        var db = Store.db();
        db.carts.push({
          id: "CART-" + String((db.counters.cart || 0) + 1).padStart(4, "0"),
          name: v.name, createdAt: Store.todayISO(), clientId: st.clientId || null,
          items: st.cart
        });
        db.counters.cart = (db.counters.cart || 0) + 1;
        Store.save();
        App.pos = { cart: [], q: "", clientId: "", method: "", received: "", second: "", secondAmount: "", discount: 0 };
        App.onData("Carrinho guardado.");
      }
    });
  };

  Actions["pos-carts"] = function () {
    var db = Store.db();
    var body = db.carts.length ? '<div class="vstack">' + db.carts.map(function (c) {
      var total = Store.round2(c.items.reduce(function (a, l) {
        return a + l.qty * l.price * (1 - l.discount) * (1 + l.vatRate);
      }, 0));
      var cname = c.clientId ? clientName(c.clientId) : "Consumidor final";
      return '<div class="card tight"><div class="hstack"><div class="tile" style="width:38px;height:38px;border-radius:12px;background:var(--surface);display:grid;place-items:center;color:var(--lime)">' +
        UI.icon("shopping-bag", 17) + '</div><div style="flex:1;min-width:0"><div class="name">' + UI.esc(c.name) + '</div><div class="meta tiny muted">' +
        UI.esc(cname) + " · " + Store.dateShort(c.createdAt) + " · " + c.items.length + " itens</div></div>" +
        '<div class="amount sm">' + money(total) + "</div></div>" +
        '<div class="btn-row" style="margin-top:10px"><button class="btn primary sm" data-cart="resume" data-id="' + c.id + '">Retomar</button>' +
        '<button class="btn ghost sm" data-cart="new" data-id="' + c.id + '">Converter em venda</button>' +
        '<button class="btn danger sm" data-cart="del" data-id="' + c.id + '">Eliminar</button></div></div>';
    }).join("") + "</div>" : UI.emptyState("shopping-bag", "Não há carrinhos guardados.");

    var ov = UI.openSheet('<div class="sheet-head"><div class="ttl"><h2>Carrinhos guardados</h2><p>Pedidos temporários.</p></div>' +
      '<button class="icon-btn ghost" data-x="1">' + UI.icon("x", 18) + "</button></div><div class=\"sheet-body\">" + body + "</div>", "");
    ov.querySelector("[data-x]").onclick = UI.closeSheet;
    ov.querySelectorAll("[data-cart]").forEach(function (b) {
      b.onclick = function () {
        var id = b.getAttribute("data-id");
        var act = b.getAttribute("data-cart");
        var cart = db.carts.find(function (c) { return c.id === id; });
        if (!cart) return;
        if (act === "del") {
          db.carts = db.carts.filter(function (c) { return c.id !== id; });
          Store.save(); UI.closeSheet(); App.onData("Carrinho eliminado."); return;
        }
        UI.closeSheet();
        if (act === "resume") {
          App.pos = {
            cart: JSON.parse(JSON.stringify(cart.items)), q: "",
            clientId: cart.clientId || "", method: "", received: "", second: "", secondAmount: "", discount: 0
          };
          App.render(); UI.toast("Carrinho retomado.");
        } else {
          App.go("#/pdv");
          setTimeout(function () {
            openSaleEditor(null, { clientId: cart.clientId, items: cart.items, cartId: cart.id });
          }, 30);
        }
      };
    });
  };

  window.Views.sales = sales;
  window.Views.saleDetail = saleDetail;
  window.Views.pos = pos;
  window.openSaleEditor = openSaleEditor;
  window.openPayment = openPayment;
  window.openReceipt = openReceipt;
})();
