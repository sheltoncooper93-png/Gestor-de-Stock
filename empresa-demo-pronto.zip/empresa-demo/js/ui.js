/* ============================================================
   UI — ícones, componentes e interações partilhadas
   ============================================================ */
(function () {
  "use strict";

  var ICONS = {
    home: '<path d="m3 10 9-7 9 7v9a2 2 0 0 1-2 2h-4v-7H9v7H5a2 2 0 0 1-2-2z"/>',
    receipt: '<path d="M4 2h16v20l-3-2-3 2-3-2-3 2-3-2z"/><path d="M8 7h8M8 11h8M8 15h5"/>',
    package: '<path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5M12 22V12"/>',
    wallet: '<path d="M19 7V5a2 2 0 0 0-2-2H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3v3a1 1 0 0 1-1 1H5a2 2 0 0 1-2-2V5"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    bell: '<path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/><path d="M4 17h16l-1.5-2.2A2 2 0 0 1 18 13.7V10a6 6 0 1 0-12 0v3.7a2 2 0 0 1-.5 1.1z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    "chevron-right": '<path d="m9 6 6 6-6 6"/>',
    "chevron-left": '<path d="m15 6-6 6 6 6"/>',
    "chevron-down": '<path d="m6 9 6 6 6-6"/>',
    "arrow-left": '<path d="M19 12H5m7-7-7 7 7 7"/>',
    "arrow-right": '<path d="M5 12h14m-7-7 7 7-7 7"/>',
    "arrow-up-right": '<path d="M7 17 17 7M8 7h9v9"/>',
    "arrow-down-left": '<path d="M17 7 7 17m9 0H7V8"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    user: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    tag: '<path d="M12.6 2.6a2 2 0 0 0-1.4-.6H4a2 2 0 0 0-2 2v7.2a2 2 0 0 0 .6 1.4l8.2 8.2a2 2 0 0 0 2.8 0l7.2-7.2a2 2 0 0 0 0-2.8z"/><circle cx="7.5" cy="7.5" r="1.2"/>',
    settings: '<path d="M12.2 2h-.4a2 2 0 0 0-2 2v.2a2 2 0 0 1-1 1.7l-.3.2a2 2 0 0 1-2 0l-.2-.1a2 2 0 0 0-2.7.7l-.2.4a2 2 0 0 0 .7 2.7l.2.1a2 2 0 0 1 1 1.8v.5a2 2 0 0 1-1 1.7l-.2.1a2 2 0 0 0-.7 2.7l.2.4a2 2 0 0 0 2.7.7l.2-.1a2 2 0 0 1 2 0l.3.2a2 2 0 0 1 1 1.7v.2a2 2 0 0 0 2 2h.4a2 2 0 0 0 2-2v-.2a2 2 0 0 1 1-1.7l.3-.2a2 2 0 0 1 2 0l.2.1a2 2 0 0 0 2.7-.7l.2-.4a2 2 0 0 0-.7-2.7l-.2-.1a2 2 0 0 1-1-1.7v-.5a2 2 0 0 1 1-1.8l.2-.1a2 2 0 0 0 .7-2.7l-.2-.4a2 2 0 0 0-2.7-.7l-.2.1a2 2 0 0 1-2 0l-.3-.2a2 2 0 0 1-1-1.7V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
    upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
    trash: '<path d="M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6"/>',
    "alert-triangle": '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    "check-circle": '<path d="M21.8 10A10 10 0 1 1 17 3.3"/><path d="m9 11 3 3L22 4"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    "trending-up": '<path d="m3 17 6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
    "trending-down": '<path d="m3 7 6 6 4-4 8 8"/><path d="M15 17h6v-6"/>',
    building: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4M8 6h.01M16 6h.01M8 10h.01M16 10h.01M8 14h.01M16 14h.01"/>',
    truck: '<path d="M14 18V6a1 1 0 0 0-1-1H2v13h2"/><path d="M14 9h4l4 4v5h-2"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
    "shopping-cart": '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h2.5l2.6 12.4a2 2 0 0 0 2 1.6h8.8a2 2 0 0 0 2-1.6L21.5 7H5.5"/>',
    layers: '<path d="m12 2 9 5-9 5-9-5z"/><path d="m3 12 9 5 9-5M3 17l9 5 9-5"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
    database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5M3 12c0 1.7 4 3 9 3s9-1.3 9-3"/>',
    printer: '<path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8" rx="1"/>',
    "credit-card": '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/>',
    banknote: '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 12h.01M18 12h.01"/>',
    box: '<path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5M12 22V12"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    filter: '<path d="M22 3H2l8 9.5V19l4 2v-8.5z"/>',
    edit: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4z"/>',
    "more-horizontal": '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
    refresh: '<path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/>',
    lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
    "pie-chart": '<path d="M21.2 15.9A10 10 0 1 1 8 2.8"/><path d="M22 12A10 10 0 0 0 12 2v10z"/>',
    "bar-chart": '<path d="M3 3v18h18"/><rect x="7" y="12" width="3" height="6"/><rect x="12" y="8" width="3" height="10"/><rect x="17" y="4" width="3" height="14"/>',
    "file-text": '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h5"/>',
    save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8M7 3v5h8"/>',
    copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    "external-link": '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6M10 14 21 3"/>',
    "wifi-off": '<path d="m2 2 20 20M8.5 8.5a11 11 0 0 1 11 2M5 12.5a15 15 0 0 1 3.5-1.7M12 20h.01M2 8.8a20 20 0 0 1 2-1.4M19 11.4a20 20 0 0 0 3-1.9"/>',
    "shopping-bag": '<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><path d="M3 6h18M16 10a4 4 0 0 1-8 0"/>',
    "arrow-down-circle": '<circle cx="12" cy="12" r="9"/><path d="M12 8v8m-4-4 4 4 4-4"/>',
    "arrow-up-circle": '<circle cx="12" cy="12" r="9"/><path d="M12 16V8m-4 4 4-4 4 4"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6v.4M12 17h.01"/>',
    star: '<path d="m12 2 3 6.6 7 .9-5.2 4.8 1.4 7-6.2-3.5L5.8 21l1.4-7L2 9.5l7-.9z"/>',
    "user-plus": '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/>',
    percent: '<path d="m19 5-14 14"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>',
    "clipboard-list": '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M9 11h6M9 15h4"/>',
    coins: '<circle cx="8" cy="8" r="6"/><path d="M18.1 10.4A6 6 0 1 1 10.4 18"/><path d="M7 6h1v4"/>'
  };

  function icon(name, size, extra) {
    var p = ICONS[name] || ICONS["help"];
    return '<svg viewBox="0 0 24 24" width="' + (size || 20) + '" height="' + (size || 20) +
      '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" ' +
      (extra || "") + '>' + p + "</svg>";
  }

  function esc(v) {
    if (v === null || v === undefined) return "";
    return String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function money(v, opts) { return Store.money(v, opts); }

  /* ---------------------------------- toast ------------------------ */
  function toast(msg, kind) {
    var wrap = document.querySelector(".toasts");
    if (!wrap) {
      wrap = document.createElement("div");
      wrap.className = "toasts";
      document.body.appendChild(wrap);
    }
    var t = document.createElement("div");
    t.className = "toast " + (kind === "err" ? "err" : "ok");
    t.innerHTML = icon(kind === "err" ? "alert-triangle" : "check-circle", 17) + "<span>" + esc(msg) + "</span>";
    wrap.appendChild(t);
    setTimeout(function () {
      t.style.transition = "opacity .2s, transform .2s";
      t.style.opacity = "0";
      t.style.transform = "translateY(6px)";
      setTimeout(function () { t.remove(); }, 220);
    }, 2600);
  }

  /* ---------------------------------- overlays --------------------- */
  var modalStack = [];

  function openSheet(html, cls) {
    var ov = document.createElement("div");
    ov.className = "overlay";
    ov.innerHTML = '<div class="sheet ' + (cls || "") + '" role="dialog" aria-modal="true">' + html + "</div>";
    document.body.appendChild(ov);
    ov.addEventListener("mousedown", function (e) {
      if (e.target === ov) closeSheet();
    });
    modalStack.push(ov);
    document.body.style.overflow = "hidden";
    var first = ov.querySelector("input,select,textarea,button.primary");
    if (first && window.innerWidth > 720) setTimeout(function () { first.focus(); }, 60);
    return ov;
  }

  function closeSheet() {
    var ov = modalStack.pop();
    if (ov) ov.remove();
    if (!modalStack.length) document.body.style.overflow = "";
    var onClose = closeSheet._cb;
    closeSheet._cb = null;
    if (onClose) onClose();
  }

  function closeAllSheets() {
    while (modalStack.length) { modalStack.pop().remove(); }
    document.body.style.overflow = "";
  }

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && modalStack.length) closeSheet();
  });

  /* ---------------------------------- confirmação ------------------ */
  function confirmAction(opts) {
    return new Promise(function (resolve) {
      var ov = openSheet(
        '<div class="sheet-head"><div class="ttl"><h2>' + esc(opts.title || "Confirmar") + "</h2>" +
        (opts.message ? "<p>" + esc(opts.message) + "</p>" : "") + "</div>" +
        '<button class="icon-btn ghost" data-x="1">' + icon("x", 18) + "</button></div>" +
        '<div class="sheet-body">' + (opts.body || "") + "</div>" +
        '<div class="sheet-foot"><button class="btn ghost" data-cancel="1">Cancelar</button>' +
        '<button class="btn ' + (opts.danger ? "danger" : "primary") + '" data-ok="1">' +
        esc(opts.confirmLabel || "Confirmar") + "</button></div>"
      , "confirm");
      function done(v) { closeSheet(); resolve(v); }
      ov.querySelector("[data-ok]").onclick = function () { done(true); };
      ov.querySelector("[data-cancel]").onclick = function () { done(false); };
      ov.querySelector("[data-x]").onclick = function () { done(false); };
    });
  }

  /* ---------------------------------- formulário genérico ---------- */
  /**
   * fields: [{k,label,type,value,options:[{id,name}]|strings,required,step,min,max,help,placeholder,full,readonly}]
   */
  function fieldHTML(f, value) {
    var v = value === undefined ? (f.value === undefined ? "" : f.value) : value;
    var id = "f_" + f.k;
    var req = f.required ? " required" : "";
    var full = f.full || f.type === "textarea" ? " full" : "";
    var lbl = f.label ? '<label for="' + id + '">' + esc(f.label) + (f.required ? " *" : "") + "</label>" : "";
    var help = f.help ? '<div class="help">' + f.help + "</div>" : "";
    var input;
    if (f.type === "select") {
      var rawOpts = f.options || [];
      var hasBlank = rawOpts.some(function (o) { return (typeof o === "string" ? o : o.id) === ""; });
      var opts = rawOpts.map(function (o) {
        var oid = typeof o === "string" ? o : o.id;
        var onm = typeof o === "string" ? o : o.name;
        return '<option value="' + esc(oid) + '"' + (String(oid) === String(v) ? " selected" : "") + ">" + esc(onm) + "</option>";
      }).join("");
      input = '<select class="select" id="' + id + '" name="' + f.k + '"' + req + ">" +
        (f.blank === false || hasBlank ? "" : '<option value=""' + (v === "" || v === null || v === undefined ? " selected" : "") + ">" + esc(f.blankLabel || "— Selecione —") + "</option>") + opts + "</select>";
    } else if (f.type === "textarea") {
      input = '<textarea class="textarea" id="' + id + '" name="' + f.k + '" placeholder="' + esc(f.placeholder || "") + '"' + req + ">" + esc(v) + "</textarea>";
    } else if (f.type === "checkbox") {
      return '<div class="field' + full + '"><label class="inline-check"><input type="checkbox" id="' + id + '" name="' + f.k + '"' +
        (v ? " checked" : "") + "> " + esc(f.label || "") + "</label>" + help + "</div>";
    } else if (f.type === "static") {
      return '<div class="field' + full + '"><div class="form-note">' + (f.html || esc(v)) + "</div></div>";
    } else {
      var attrs = "";
      if (f.type === "number" || f.type === "money" || f.type === "pct") attrs += ' inputmode="decimal" step="' + (f.step || (f.type === "pct" ? "1" : "0.01")) + '"';
      if (f.type === "money") attrs += ' inputmode="decimal" step="0.01"';
      if (f.min !== undefined) attrs += ' min="' + f.min + '"';
      if (f.max !== undefined) attrs += ' max="' + f.max + '"';
      if (f.readonly) attrs += " readonly";
      input = '<input class="input" id="' + id + '" name="' + f.k + '" type="' +
        (f.type === "date" ? "date" : (f.type === "money" || f.type === "pct" || f.type === "number") ? "number" : f.type === "email" ? "email" : f.type === "tel" ? "tel" : "text") +
        '" value="' + esc(v) + '" placeholder="' + esc(f.placeholder || "") + '"' + attrs + req + ">";
    }
    return '<div class="field' + full + '">' + lbl + input + help + "</div>";
  }

  function formHTML(fields, values, opts) {
    values = values || {};
    opts = opts || {};
    var groups = [], current = [];
    fields.forEach(function (f, i) {
      if (f.type === "group" || f.type === "section") {
        if (current.length) { groups.push('<div class="grid2">' + current.join("") + "</div>"); current = []; }
        groups.push('<div class="eyebrow" style="margin-top:6px">' + esc(f.label) + "</div>");
        return;
      }
      current.push(fieldHTML(f, values[f.k]));
      if (f.full || f.type === "textarea" || f.type === "checkbox" || f.type === "static") {
        groups.push('<div class="grid2">' + current.join("") + "</div>"); current = [];
      }
    });
    if (current.length) groups.push('<div class="grid2">' + current.join("") + "</div>");
    return '<form class="form" novalidate>' + groups.join("") + "</form>";
  }

  function readForm(formEl, fields) {
    var out = {};
    fields.forEach(function (f) {
      if (f.type === "group" || f.type === "section" || f.type === "static") return;
      var el = formEl.querySelector('[name="' + f.k + '"]');
      if (!el) return;
      if (f.type === "checkbox") out[f.k] = el.checked;
      else if (f.type === "money" || f.type === "pct" || f.type === "number") {
        var n = Number(String(el.value).replace(",", "."));
        out[f.k] = isFinite(n) ? n : 0;
      } else out[f.k] = el.value;
    });
    return out;
  }

  /**
   * Abre um formulário modal.
   * opts: {title, subtitle, fields, values, submitLabel, wide, onChange, validate, onSubmit, extraBody, onMount, footerExtra}
   */
  function form(opts) {
    var ov = openSheet(
      '<div class="sheet-head"><div class="ttl"><h2>' + esc(opts.title) + "</h2>" +
      (opts.subtitle ? "<p>" + esc(opts.subtitle) + "</p>" : "") + "</div>" +
      '<button class="icon-btn ghost" data-x="1" type="button">' + icon("x", 18) + "</button></div>" +
      '<div class="sheet-body">' + (opts.extraBody || "") + formHTML(opts.fields, opts.values) + "</div>" +
      '<div class="sheet-foot">' + (opts.footerExtra || "") +
      '<button class="btn ghost" data-cancel="1" type="button">Cancelar</button>' +
      '<button class="btn primary" data-save="1" type="button">' + esc(opts.submitLabel || "Guardar") + "</button></div>",
      opts.wide ? "wide" : ""
    );
    var formEl = ov.querySelector("form");
    if (opts.onMount) opts.onMount(ov, formEl);
    if (opts.onChange) {
      formEl.addEventListener("input", function (e) { opts.onChange(readForm(formEl, opts.fields), ov, e.target); });
      formEl.addEventListener("change", function (e) { opts.onChange(readForm(formEl, opts.fields), ov, e.target); });
    }
    ov.querySelector("[data-x]").onclick = function () { closeSheet(); };
    ov.querySelector("[data-cancel]").onclick = function () { closeSheet(); };
    ov.querySelector("[data-save]").onclick = function () {
      var values = readForm(formEl, opts.fields);
      var missing = null;
      opts.fields.forEach(function (f) {
        if (missing || !f.required) return;
        var v = values[f.k];
        if (v === "" || v === null || v === undefined) missing = f;
      });
      if (missing) { toast("Preencha: " + (missing.label || missing.k), "err"); return; }
      if (opts.validate) {
        var err = opts.validate(values, formEl);
        if (err) { toast(err, "err"); return; }
      }
      var res = opts.onSubmit ? opts.onSubmit(values, ov, formEl) : true;
      if (res !== false) closeSheet();
    };
    return ov;
  }

  /* ---------------------------------- pequenos componentes -------- */
  function statusChip(status, extra) {
    var cls = "chip ";
    if (status === "Paga" || status === "OK" || status === "Ativo" || status === "Concluída") cls += "green";
    else if (status === "Pendente" || status === "REPOR" || status === "Potencial" || status === "Em curso" || status === "Férias") cls += "orange";
    else if (status === "Cancelada" || status === "SEM STOCK" || status === "Inativo" || status === "ATRASADA") cls += "red";
    else cls += "blue";
    return '<span class="' + cls + '">' + esc(status) + (extra ? " " + esc(extra) : "") + "</span>";
  }

  function emptyState(ic, text, actionHTML) {
    return '<div class="empty"><div class="ic">' + icon(ic, 24) + "</div><p>" + esc(text) + "</p>" + (actionHTML || "") + "</div>";
  }

  function statMini(label, value, cls, sub) {
    return '<div class="stat ' + (cls || "") + '"><div class="k">' + esc(label) + "</div><div class=\"v\">" +
      (typeof value === "string" ? value : esc(value)) + "</div>" + (sub ? '<div class="d">' + esc(sub) + "</div>" : "") + "</div>";
  }

  function donut(items, total, centerLabel, centerValue) {
    // items: [{name,value,color}]
    var R = 52, C = 2 * Math.PI * R, off = 0;
    var segs = items.filter(function (i) { return i.value > 0; }).map(function (i) {
      var frac = total > 0 ? i.value / total : 0;
      var len = frac * C;
      var s = '<circle cx="70" cy="70" r="' + R + '" fill="none" stroke="' + i.color +
        '" stroke-width="18" stroke-linecap="butt" stroke-dasharray="' + len + " " + (C - len) +
        '" stroke-dashoffset="' + (-off) + '" transform="rotate(-90 70 70)"/>';
      off += len;
      return s;
    }).join("");
    return '<div class="donut-wrap"><div class="donut-center">' +
      '<svg width="140" height="140" viewBox="0 0 140 140">' +
      '<circle cx="70" cy="70" r="' + R + '" fill="none" stroke="rgba(243,246,248,.06)" stroke-width="18"/>' + segs + "</svg>" +
      '<div class="lbl"><b>' + esc(centerValue) + "</b><span>" + esc(centerLabel) + "</span></div></div></div>";
  }

  function barChart(rows, opts) {
    opts = opts || {};
    var measure = opts.measure || function (r) { return r.value; };
    var max = Math.max.apply(null, rows.map(measure).concat([1]));
    var w = 100 / Math.max(rows.length, 1);
    var bars = rows.map(function (r, i) {
      var v = measure(r);
      var h = Math.max(2, (v / max) * 100);
      return '<div class="col" title="' + esc(opts.label ? opts.label(r) : v) + '">' +
        '<div class="pair"><i class="r" style="height:' + h + '%"></i></div>' +
        '<div class="cap">' + esc(r.label || r.month || "") + "</div></div>";
    }).join("");
    return '<div class="bars">' + bars + "</div>";
  }

  function sparkBars(rows) {
    var max = Math.max.apply(null, rows.map(function (r) { return Math.max(r.revenue, r.expenses); }).concat([1]));
    return '<div class="bars">' + rows.map(function (r) {
      var hr = Math.max(2, (r.revenue / max) * 100);
      var he = Math.max(2, (r.expenses / max) * 100);
      return '<div class="col"><div class="pair"><i class="r" style="height:' + hr + '%"></i><i class="d" style="height:' + he + '%"></i></div>' +
        '<div class="cap">' + esc(r.cap || r.label) + "</div></div>";
    }).join("") + "</div>";
  }

  function optsFromList(key, blankLabel) {
    var arr = Store.listValues(key).map(function (l) { return { id: l.id, name: l.name }; });
    if (blankLabel !== null && blankLabel !== undefined) arr.unshift({ id: "", name: blankLabel });
    return arr;
  }

  function todayForInput() { return Store.todayISO(); }

  function debounce(fn, ms) {
    var t;
    return function () {
      var args = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(self, args); }, ms || 220);
    };
  }

  window.UI = {
    icon: icon, esc: esc, money: money,
    toast: toast,
    openSheet: openSheet, closeSheet: closeSheet, closeAllSheets: closeAllSheets,
    confirm: confirmAction,
    form: form, readForm: readForm, fieldHTML: fieldHTML,
    statusChip: statusChip, emptyState: emptyState, statMini: statMini,
    donut: donut, barChart: barChart, sparkBars: sparkBars,
    optsFromList: optsFromList, debounce: debounce,
    todayForInput: todayForInput
  };
})();
